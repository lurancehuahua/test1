--
--
--					Test code
--
--

local cto = require "luci.Ctontab"

local function match( left, right )
    if left == '*' then return true end
 
    --单整数的情况
    if 'number' == type(left) and left == right then
        return true
    end
 
    --范围的情况 形如 1-12/5,算了,先不支持这种每隔几分钟的这种特性吧
    _,_,a,b = string.find(left, "(%d+)-(%d+)")
    if a and b then
        return (right >= tonumber(a) and right <= tonumber(b))
    end
 
    --多选项的情况 形如 1,2,3,4,5
    --哎,luajit不支持gfind,
    --for d in string.gfind(left, "%d+") do
    --其实也可以for i in string.gmatch(left,'(%d+)') do
    local pos = 0
    for st,sp in function() return string.find(left, ',', pos, true) end do
        if tonumber(string.sub(left, pos, st - 1)) == right then
            return true
        end
        pos = sp + 1
    end
    return tonumber(string.sub(left, pos)) == right
end

--传说中的测试代码
local function RunTests()
    --the following calls are equivalent:
    local function printMessage(a)
      print('Hello',a)
    end
 
 	--local cron = crontab.new()
    local cron = cto.new()
 
    local c1 = cron:after( 15, printMessage)
    local c2 = cron:after( 15, print, {'Hello'})
 
    c1:update(2) -- will print nothing, the action is not done yet
    c1:update(5) -- will print 'Hello' once
 
    c1:reset() -- reset the counter to 0
 
    -- prints 'hey' 5 times and then prints 'hello'
    while not c1:update(1) do
      print('hey')
    end
 
    -- Create a periodical clock:
    local c3 = cron:every( 10, printMessage)
 
    c3:update(5) -- nothing (total time: 5)
    c3:update(4) -- nothing (total time: 9)
    c3:update(12) -- prints 'Hello' twice (total time is now 21)
 
    -------------------------------------
    c1.deleted = true
    c2.deleted = true
    c3.deleted = true
 
    ------------------------------
    --测试一下match
    print('----------------------------------')
    assert(match('12-15',14) == true)
    assert(match('18-21',14) == false)
    assert(match('18,21',14) == false)
    assert(match('18,21,14',14) == true)
 
    --加一个定时器1分钟后执行
    cron:update(1000*1000*100)
 
    --加入一个定时器每分钟执行
    cron:addCron('每秒执行', '45 13 * * *', print, {'.......... cron'})
 
    cron:update((60-os.time()%60)*1000)
    cron:update(30*1000)
    cron:update(31*1000)
    cron:update(1)
    cron:update(60*1000)        --打印两次
end

RunTests()