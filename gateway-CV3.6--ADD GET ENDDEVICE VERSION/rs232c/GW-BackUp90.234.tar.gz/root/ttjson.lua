local db = require "ttdb"
local serial  = require "ttserial"

module ("ttjson", package.seeall)

function _dbg(...)
	print(...)
end

function _decodeURI(s)
    s = string.gsub(s, '%%(%x%x)', function(h) return string.char(tonumber(h, 16)) end)
    return s
end

local sta = "{\""
local en = "\"}"
local nen = "}"
local mop = "\":\""
local dop = "\",\""
local nmop = "\":"
local ndop = ",\""

function loadRoom(self)
	-- txt = sta.."roomMsg".."\":["
	-- txt = txt..sta.."GN"..nmop.."1"..ndop.."IC"..nmop.."1"..ndop.."NA"..mop.."Bigroom"..dop.."MO"..mop.."sleeping"..dop.."SW"..nmop.."1"..ndop.."LE"..nmop.."100"..nen
	-- txt = txt..","..sta.."GN"..nmop.."2"..ndop.."IC"..nmop.."2"..ndop.."NA"..mop.."Childroom"..dop.."MO"..mop.."Reading"..dop.."SW"..nmop.."1"..ndop.."LE"..nmop.."150"..nen
	-- txt = txt..","..sta.."GN"..nmop.."3"..ndop.."IC"..nmop.."3"..ndop.."NA"..mop.."Guestroom"..dop.."MO"..mop.."sleeping"..dop.."SW"..nmop.."0"..ndop.."LE"..nmop.."200"..nen
	-- txt = txt..","..sta.."GN"..nmop.."4"..ndop.."IC"..nmop.."5"..ndop.."NA"..mop.."Hall"..dop.."MO"..mop.."Party"..dop.."SW"..nmop.."0"..ndop.."LE"..nmop.."50"..nen
	-- txt = txt..","..sta.."GN"..nmop.."5"..ndop.."IC"..nmop.."1"..ndop.."NA"..mop.."Kitchen"..dop.."MO"..mop.."Cooking"..dop.."SW"..nmop.."0"..ndop.."LE"..nmop.."180"..nen
	-- txt = txt..","..sta.."GN"..nmop.."6"..ndop.."IC"..nmop.."4"..ndop.."NA"..mop.."Toilet"..dop.."MO"..mop.."Washing"..dop.."SW"..nmop.."0"..ndop.."LE"..nmop.."230"..nen
	-- txt = txt..","..sta.."GN"..nmop.."7"..ndop.."IC"..nmop.."1"..ndop.."NA"..mop.."Balcony"..dop.."MO"..mop.."Lowlight"..dop.."SW"..nmop.."0"..ndop.."LE"..nmop.."30"..nen
	-- txt = txt.."]}"

	local txt, i
	local array, gid, tag, name, s_name, onoff, level

	txt = sta.."roomMsg".."\":["
	-- array: id, tag, name, sid, onoff, lum
	array = db:grooms_load()
	if array ~= nil then
		i = 1
		while (array[i] ~= nil) do
			gid = array[i]
			tag = array[i+1]
			name = array[i+2]
			s_name = array[i+3]
			onoff = array[i+4]
			level = array[i+5]
			_dbg(s_name)
		
			if i == 1 then
				txt = txt..sta.."GN"..nmop..gid..ndop.."IC"..nmop..tag..ndop.."NA"..mop..name..dop.."MO"..mop..s_name..dop.."SW"..nmop..onoff..ndop.."LE"..nmop..level..nen
			else
				txt = txt..","..sta.."GN"..nmop..gid..ndop.."IC"..nmop..tag..ndop.."NA"..mop..name..dop.."MO"..mop..s_name..dop.."SW"..nmop..onoff..ndop.."LE"..nmop..level..nen
			end
			i = i + 6
		end
	end
	txt = txt.."]}"

	_dbg(txt)
	return txt
end

-- loadRoom()

function allRoom(self, onoff)
	local txt
	serial:setonoff(onoff)
	db:groups_setonoffall(onoff, 0)
	txt = "allRoom:"..onoff
	_dbg(txt)
	return txt
end

-- allRoom(self, 0)

function roomSwitch(self, gid, onoff)
	local txt
	serial:g_setonoff(gid, onoff)
	db:groups_setonoff(gid, onoff, 0)
	txt = "groupNum:"..gid.."roomSwitch:"..onoff
	_dbg(txt)
	return txt
end

-- roomSwitch(self, 888, 1)

function roomLevel(self, gid, level)
	local txt
	serial:g_setlum(gid, level)
	db:groups_setlum(gid, level, 0)
	txt = "groupNum:"..gid.."slideLevel:"..level
	_dbg(txt)
	return txt
end

function roomModeName(self, gid, modeName)
	local sid, txt, lum, cct, hue
	sid = db:gscenes_getidbyname(modeName)
	if sid ~= nil then
		lum = db:groups_getlum(sid)
		cct = db:groups_getcct(sid)
		hue = db:groups_gethue(sid)
		if lum ~= nil then serial:g_setlum(gid, tonumber(lum)) end
		if cct ~= nil then serial:g_setcct(gid, tonumber(cct)) end
		if hue ~= nil then serial:g_sethue(gid, tonumber(hue)) end
		db:groups_setsid(gid, sid)
	end
	txt = "groupNum:"..gid.."roomModeName:"..modeName
	_dbg(txt)
	return txt
end

-- roomModeName(self, 8, "Wake up")

function deviceSwitch(self, addr, onoff)
	local txt, did
	serial:d_setonoff(addr, onoff)
	did = db:devices_getidbyaddr(addr)
	if did ~= nil then db:devices_setonoff(did, onoff, 0) end
	txt = "deviceAddress:"..addr.."deviceSwitch:"..onoff
	_dbg(txt)
	return txt
end

function deviceLevel(self, addr, level)
	local txt, did
	serial:d_setlum(addr, level)
	did = db:devices_getidbyaddr(addr)
	if did ~= nil then db:devices_setlum(did, level, 0) end
	txt = "deviceAddress:"..addr.."deviceLevel:"..level
	_dbg(txt)
	return txt
end

function deviceTemp(self, addr, temp)
	local txt, did
	serial:d_setcct(addr, temp)
	did = db:devices_getidbyaddr(addr)
	if did ~= nil then db:devices_setcct(did, temp, 0) end
	txt = "deviceAddress:"..addr.."deviceTemp:"..temp
	_dbg(txt)
	return txt
end

function deviceColor(self, addr, color)
	local txt, did
	serial:d_sethue(addr, color)
	did = db:devices_getidbyaddr(addr)
	if did ~= nil then db:devices_sethue(did, color, 0, 0) end
	txt = "deviceAddress:"..addr.."deviceColor:"..color
	_dbg(txt)
	return txt
end

function deviceIdentify(self, addr, identify)
	local txt
	serial:d_setidentify(addr, identify)
	txt = "deviceAddress:"..addr.."deviceIdentify:"..identify
	_dbg(txt)
	return txt
end

function addSceneSave(self, save, gids, gid, name, onoff, level, temp, color, nameorg)
	local txt, splitlist

	if gids ~= nil then 
		splitlist = {}
		string.gsub(gids, '[^,]+', function(w) table.insert(splitlist, w) end )   
	end

	-- do db ops only when save is not nil
	if (save ~= nil) then
		-- 200:add new scene
		if save == 200 then
			if (name ~= nil) and (gids ~= nil) and (level ~= nil) and (temp ~= nil) and (color ~= nil) then
				-- do not save scenes' ic, so set tag to default 1
				db:gscenes_add(16,name,gids,level,temp,color)
			end
		-- 201:modify exist scene
		elseif save == 201 then
			if (nameorg ~= nil) and (name ~= nil) and (gids ~= nil) and (level ~= nil) and (temp ~= nil) and (color ~= nil) then
				db:gscenes_modify(nameorg,16,name,gids,level,temp,color)
			end
		end
	elseif (onoff ~= nil) then
		if (gids ~= nil) then
			for i,v in ipairs(splitlist) do
				serial:g_setonoff(tonumber(v), onoff)
			end
		end
	elseif (gid ~= nil) then
		serial:g_setonoff(gid, 1)
		if level ~= nil then serial:g_setlum(gid, level) end
		if temp ~= nil then serial:g_setcct(gid, temp) end
		if color ~= nil then serial:g_sethue(gid, color) end
	elseif (gids ~= nil) then
		for i,v in ipairs(splitlist) do
			if level ~= nil then serial:g_setlum(tonumber(v), level) end
			if temp ~= nil then serial:g_setcct(tonumber(v), temp) end
			if color ~= nil then serial:g_sethue(tonumber(v), color) end
		end
	else
		_dbg("do nothing")
	end

	-- prepare response txt, only for debug
	txt = ""
	--	addSceneSave 
	if (save ~= nil) then txt = txt..save end
	-- add scene page select room list number
	if (gids ~= nil) then
		for i,v in ipairs(splitlist) do
			txt = txt.." "..v
		end
	end
	-- add scene page select room number
	if (gid ~= nil) then txt = txt.." gpNum:"..gid end
	-- add scene page save scene name
	if (name ~= nil) then txt = txt.." Name:"..name end
	-- add scene switch
	if (onoff ~= nil) then txt = txt.." sceneSwitch:"..onoff end
	-- add scene three slide value
	if (level ~= nil) then txt = txt.." slideLevel:"..level end
	if (temp ~= nil) then txt = txt.." slideTemp:"..temp end
	if (color ~= nil) then txt = txt.." slideColor:"..color end

	_dbg(txt)
	return txt
end

-- eg:loadRoomChild(self, "9")
function loadRoomChild(self, id)
	-- Nest is JSON response comment :
	-- {"DEVICE":[
	-- {"AD":"0x1234", "TY":3, "NA":"readTable", "SW":1, "LE":200, "TE":180},
	-- {"AD":"0x5678", "TY":4, "NA":"Hallsofe",  "SW":1, "LE":150, "CO":200}],
	-- "MODE":[
	-- {"NA":"reading", "IC":2, "MV":1},
	-- {"NA":"wake up", "IC":1, "MV":0}
	-- ]}
	-- txt = txt..sta.."AD"..mop.."0x1234"..dop.."TY"..nmop.."61"..ndop.."NA"..mop.."readTable"..dop.."SW"..nmop.."1"..nen
	-- txt = txt..","..sta.."AD"..mop.."0x5678"..dop.."TY"..nmop.."62"..ndop.."NA"..mop.."Hallsofe"..dop.."SW"..nmop.."1"..ndop.."LE"..nmop.."150"..nen
	-- txt = txt..","..sta.."AD"..mop.."0x1111"..dop.."TY"..nmop.."63"..ndop.."NA"..mop.."TV-CCT"..dop.."SW"..nmop.."1"..ndop.."LE"..nmop.."50"..ndop.."TE"..nmop.."30"..nen
	-- txt = txt..","..sta.."AD"..mop.."0xffff"..dop.."TY"..nmop.."64"..ndop.."NA"..mop.."TV-RGB"..dop.."SW"..nmop.."1"..ndop.."LE"..nmop.."90"..ndop.."CO"..nmop.."130"..nen
	-- Nest is JSON response comment :
	-- {"DEVICE":[
	-- {"AD":"0x1234", "TY":3, "NA":"readTable", "SW":1, "LE":200, "TE":180},
	-- {"AD":"0x5678", "TY":4, "NA":"Hallsofe",  "SW":1, "LE":150, "CO":200}],
	-- "MODE":[
	-- {"NA":"reading", "IC":2, "MV":1},
	-- {"NA":"wake up", "IC":1, "MV":0}
	-- ]}

	-- txt = txt..sta.."NA"..mop.."reading"..dop.."IC"..nmop.."2"..nen
	-- txt = txt..","..sta.."NA"..mop.."wakeUp"..dop.."IC"..nmop.."1"..nen
	-- txt = txt..","..sta.."NA"..mop.."washing"..dop.."IC"..nmop.."3"..nen

	-- ONOFF 61 dim 62 cct 63 rdb 64, RC:65
	local txt, devices, scenes, s_name, i, addr, tag, name, onoff, lum, ct, hue
	local dimflag, cctflag, hueflag = 62, 63, 64

	-- prepare response data
	devices, scenes, s_name = db:grooms_loadchild(id)

	-- prepare response txt
	txt = sta.."DEVICE".."\":["

	if devices ~= nil then
		i = 1
		while (devices[i] ~= nil) do
			addr = devices[i]
			tag = devices[i+1]
			name = devices[i+2]
			onoff = devices[i+3]
			lum = devices[i+4]
			ct = devices[i+5]
			hue = devices[i+6]

			if i == 1 then 
				txt = txt..sta.."AD"..mop..addr..dop.."TY"..nmop..tag..ndop.."NA"..mop..name..dop.."SW"..nmop..onoff
			else 
				txt = txt..","..sta.."AD"..mop..addr..dop.."TY"..nmop..tag..ndop.."NA"..mop..name..dop.."SW"..nmop..onoff
			end
			if tonumber(tag) == dimflag then
				txt = txt..ndop.."LE"..nmop..lum
			elseif tonumber(tag) == cctflag then
				txt = txt..ndop.."LE"..nmop..lum..ndop.."TE"..nmop..ct
			elseif tonumber(tag) == hueflag then
				txt = txt..ndop.."LE"..nmop..lum..ndop.."TE"..nmop..ct..ndop.."CO"..nmop..hue
			else
				_dbg("This device is not a light")
			end
			txt = txt..nen
			i = i + 7
		end
	end

	txt = txt.."]," 
	txt = txt.."\"MODE\":["
	if scenes ~= nil then
		i = 1
		while (scenes[i] ~= nil) do
			-- id = scenes[i]
			tag = scenes[i+1]
			name = scenes[i+2]
			if i == 1 then
				txt = txt..sta.."NA"..mop..name..dop.."IC"..nmop..tag..nen
			else
				txt = txt..","..sta.."NA"..mop..name..dop.."IC"..nmop..tag..nen
			end
			i = i + 3
		end
	end
	txt = txt.."],"

	s_name = s_name or ""
	txt = txt.."\"CURRENT\":".."\""..s_name.."\"}"

	_dbg(txt)
	return txt
end

-- loadRoomChild(self, 10)

function loadScene(self)
	-- txt = txt..sta.."NA"..mop.."watching movie"..dop.."IC"..nmop.."1"..nen
	-- txt = txt..","..sta.."NA"..mop.."Meet vistor"..dop.."IC"..nmop.."3"..nen
	-- txt = txt..","..sta.."NA"..mop.."Reading book"..dop.."IC"..nmop.."1"..nen
	-- txt = txt..","..sta.."NA"..mop.."Normal"..dop.."IC"..nmop.."5"..nen
	-- txt = txt..","..sta.."NA"..mop.."Cleaning"..dop.."IC"..nmop.."2"..nen
	-- txt = txt..","..sta.."NA"..mop.."Wake up"..dop.."IC"..nmop.."4"..nen
	-- txt = txt..","..sta.."NA"..mop.."KTV"..dop.."IC"..nmop.."2"..nen

	-- update 20171128
	-- txt = txt..sta.."NA"..mop.."watchingmovie"..en
	-- txt = txt..","..sta.."NA"..mop.."Readingbook"..en
	local txt, array, i

	-- prepare response data
	array = db:gscenes_load()

	-- prepare response txt
	txt = sta.."sceneList".."\":["
	if array ~= nil then
		i = 1
		while array[i] ~= nil do
			if i == 1 then
				txt = txt..sta.."NA"..mop..array[i]..en
			else
				txt = txt..","..sta.."NA"..mop..array[i]..en
			end
			i = i + 2
		end
	end
	txt = txt.."]}"

	_dbg(txt)
	return txt
end

-- loadScene(self)

function loadAddScene(self)
	-- {"addScene":[
	-- {"GN":2, "IC":2, "NA":"Hall"},
	-- {"GN":3, "IC":3, "NA":"Bigroom"},
	-- {"GN":1, "IC":1, "NA":"Childroom"}
	-- ]}
	-- txt = txt..sta.."GN"..nmop.."2"..ndop.."IC"..nmop.."2"..ndop.."NA"..mop.."Hall"..en
	-- txt = txt..","..sta.."GN"..nmop.."3"..ndop.."IC"..nmop.."3"..ndop.."NA"..mop.."Bigroom"..en
	-- txt = txt..","..sta.."GN"..nmop.."1"..ndop.."IC"..nmop.."1"..ndop.."NA"..mop.."Childroom"..en
	local txt, array, i, id, tag, name

	-- prepare response data, array = {id, tag, name} * n
	array = db:grooms_loadtagname()

	-- prepare response txt
	txt = sta.."addScene\":["
	if array ~= nil then
		i = 1
		while (array[i] ~= nil) do
			id = array[i]
			tag = array[i+1]
			name = array[i+2]
			if i == 1 then
				txt = txt..sta.."GN"..nmop..id..ndop.."IC"..nmop..tag..ndop.."NA"..mop..name..en
			else 
				txt = txt..","..sta.."GN"..nmop..id..ndop.."IC"..nmop..tag..ndop.."NA"..mop..name..en
			end
			i = i + 3
		end
	end
	txt = txt.."]}"

	_dbg(txt)
	return txt
end

-- loadAddScene(self)

function loadModeAdjust(self, s_name)
	-- {"SW":1,
	--  "SLIDE":[150, 200, 60],
	--  "RM":[
	--    {"GN":1, "NA":"Bigroom", "IC":2, "SA":0} ,
	--    {"GN":2, "NA":"Childroom", "IC":4, "SA":1} ,
	--    {"GN":3, "NA":"Readroom", "IC":1, "SA":0} 
	--  ] ,
	--  "SGN":[1, 2]
	-- }
	-- txt = ""
	-- txt = sta.."SW".."\":".."1"..","
	-- txt = txt.."\"SLIDE\":[".."150"..",".."200"..",".."60".."],"
	-- txt = txt.."\"RM\":["
	-- txt = txt..sta.."GN"..nmop.."1"..ndop.."NA"..mop.."Bigroom"..dop.."IC"..nmop.."2"..ndop.."SA"..nmop.."0"..nen
	-- txt = txt..","..sta.."GN"..nmop.."2"..ndop.."NA"..mop.."Childroom"..dop.."IC"..nmop.."4"..ndop.."SA"..nmop.."1"..nen
	-- txt = txt..","..sta.."GN"..nmop.."3"..ndop.."NA"..mop.."Readroom"..dop.."IC"..nmop.."1"..ndop.."SA"..nmop.."0"..nen
	-- txt = txt.."],".."\"SGN\":[".."1"..",".."2".."]"
	-- txt = txt.."}"
	local txt, sid, onoff, level, temp, color, array, i, id, tag, name, gids, splitlist

	-- prepare response data
	sid = db:gscenes_getidbyname(s_name)
	splitlist = {}
	if (sid ~= nil) then 
		-- get scenes' details
		onoff, level, temp, color = db:gscenes_loadmore(sid)
		-- get all rooms list, array = {id, tag, name} * n
		array = db:grooms_loadtagname() 
		-- get selected rooms list, need to check the room is still available by id case it's been deleted
		gids = db:groups_getdids(sid) 
		if gids ~= nil then
			string.gsub(gids, '[^,]+', function(w) table.insert(splitlist, w) end) 
		end
	end

	-- prepare response txt
	txt = ""
	if sid ~= nil then
		txt = sta.."SW".."\":"..onoff..","
		txt = txt.."\"SLIDE\":["..level..","..temp..","..color.."],"
		txt = txt.."\"RM\":["
		if array ~= nil then
			i = 1
			while (array[i] ~= nil) do
				id = array[i]
				tag = array[i+1]
				name = array[i+2]
				if i == 1 then
					txt = txt..sta.."GN"..nmop..id..ndop.."NA"..mop..name..dop.."IC"..nmop..tag..nen
				else
					txt = txt..","..sta.."GN"..nmop..id..ndop.."NA"..mop..name..dop.."IC"..nmop..tag..nen
				end
				i = i + 3
			end
		end

		-- txt = txt.."],".."\"SGN\":[".."1"..",".."2".."]"
		txt = txt.."],".."\"SGN\":["
		if (splitlist[1] ~= nil) then
			i = 1
			for k,v in ipairs(splitlist) do
				-- check the room is still available by id case it's been deleted
				flag = db:grooms_checkid(v)
				if flag == 1 then 
					if i == 1 then txt = txt..v else txt = txt..","..v end
					i = i + 1
				end			
			end
		end
		txt = txt.."]}"
	end

	_dbg(txt)
	return txt
end

-- loadModeAdjust(self, 'Cleaning')

function delUserMode(self, name)
	local txt
	db:gscenes_deluserdef(name)
	txt = "delete "..name.." OK!"
	_dbg(txt)
	return txt
end

-- delUserMode(self, "Normal")

function checkAddSceneName(self, name)
	local txt, flag
	txt = ""
	flag = db:gscenes_checkname(name)
	txt = txt..flag
	_dbg(txt)
	return txt
end

-- checkAddSceneName(self, "Meet visitor")

function delDevice(self, addr)
	local txt, did, mac, rids, i
	did = db:devices_getidbyaddr(addr)
	if did ~= nil then
		gids = db:grooms_loadbydid(tonumber(did))
		if rids ~= nil then
			i = 1
			while gids[i] ~= nil do
				serial:d_removegroup(addr, tonumber(gids[i]))
			end
		end
		mac = db:devices_getmac(did)
		serial:d_leavenet(addr, tonumber(mac))
		db:devices_del(did)
		-- db:devices_delbyaddr(addr)
		txt = "delete device Addr:"..addr
	else
		txt = "failed of delete device Addr: "..addr
	end

	_dbg(txt)
	return txt
end

function delRoom(self, id)
	local txt
	db:grooms_del(id)
	txt = "delete room GN:"..id
	_dbg(txt)
	return txt
end

function devRename(self, devAddrList, devNameList)
	local txt, addrList, nameList, i

	txt = "rename: "
	if (devAddrList ~= nil) and (devNameList ~= nil) then
		addrList = {}
		nameList = {}
		string.gsub(devAddrList, '[^,]+', function(w) table.insert(addrList, w) end ) 
		string.gsub(devNameList, '[^,]+', function(w) table.insert(nameList, w) end )    
		for i=1, table.getn(addrList) do
			txt = txt..addrList[i]..":"..nameList[i];
			db:devices_setnamebyaddr(addrList[i], nameList[i])
		end
	end

	_dbg(txt)
	return txt
end

-- devRename(self, ",36120", ",RGBOne")

function addRoomSwitch(self, onoff, devList)
	local txt, addRoomDevList, i, v

	txt = "SW:"..onoff.." "
	if (devList ~= nil) then
		addRoomDevList = {}
		string.gsub(devList, '[^,]+', function(w) table.insert(addRoomDevList, w) end )   
		for i,v in ipairs(addRoomDevList) do
			txt = txt.." "..v
			serial:d_setonoff(tonumber(v), onoff)
		end
	end

	_dbg(txt)
	return txt
end

-- addRoomSwitch(self, 0, ",36120,49220")

function addRoomSlideFlag(self, level, temp, color, devList)
	local txt, addRoomDevList, i, v

	if (devList ~= nil) then
		addRoomDevList = {}
		string.gsub(devList, '[^,]+', function(w) table.insert(addRoomDevList, w) end )  

		if (level ~= nil) then
			txt = "Level"..level
			for i,v in ipairs(addRoomDevList) do
				txt = txt.." "..v
				serial:d_setlum(tonumber(v), level)
			end
		elseif (temp ~= nil) then
			txt = "Temp"..temp
			for i,v in ipairs(addRoomDevList) do
				txt = txt.." "..v
				serial:d_setcct(tonumber(v), temp)
			end
		elseif (color ~= nil) then
			txt = "Color"..color
			for i,v in ipairs(addRoomDevList) do
				txt = txt.." "..v
				serial:d_sethue(tonumber(v), color)
			end
		end
	end

	_dbg(txt)
	return txt
end

-- addRoomSlideFlag(self, 200, nil, nil, ",1234,5678")

function selectDeviceFlag(self, flag, addr, onoff, level, temp, color)
	local txt = "select:"..flag

	if (addr ~= nil) then
		txt = txt.." "..addr
		if (onoff ~= nil) then 
			txt = txt.." "..onoff
			serial:d_setonoff(addr, onoff)
		end

		if (level ~= nil) then
			txt = txt.." "..level
			serial:d_setlum(addr, level)
		end

		if (temp ~= nil) then
			txt = txt.." "..temp
			serial:d_setcct(addr, temp)
		end

		if (color ~= nil) then
			txt = txt.." "..color
			serial:d_sethue(addr, color)
		end
	end

	_dbg(txt)
	return txt
end

-- devList is devices' addr list
function saveRoomDateFlag(self, flag, name, icon, devList, nameorg)
	local txt, id, did, dids, splitlist, k, v, addr, i

	splitlist = {}
	if devList ~= nil then 
		string.gsub(devList, '[^,]+', function(w) table.insert(splitlist, w) end ) 
	end

	txt = "sa:"..flag
	if (name ~= nil) and (icon ~= nil) then
		txt = txt.." "..name.." "..icon
		if flag == 200 then
			db:grooms_add(icon, name)
		elseif flag == 201 then
			if nameorg ~= nil then db:grooms_modify(nameorg, icon, name) end
		end

		if (devList ~= nil) then
			txt = txt.." "..devList
			id = db:grooms_getidbyname(name)
			serial:g_removegroup(tonumber(id))
			if (id ~= nil) then 
				i = 1
				dids = "\'"
				for k, v in ipairs(splitlist) do
					did = db:devices_getidbyaddr(tonumber(v))
					if did ~= nil then
						serial:d_addgroup(tonumber(v),tonumber(id))
						if i == 1 then
							dids = dids..did
						else
							dids = dids..","..did
						end
						i = i + 1
					end
				end
				if i == 1 then dids = dids..0 end
				dids = dids.."\'"
				db:groups_setdids(id, dids) 
			end
		end
	end

	_dbg(txt)
	return txt
end

-- saveRoomDateFlag(self, 1, "Kitchen", 1, ",59468,60837")

function addRoomNameCheck(self, name)
	local txt, flag
	txt = ""
	flag = db:grooms_checkname(name)
	txt = txt..flag
	_dbg(txt)
	return txt
end

function loadDeviceList(self)
	-- {"DEVL":[
	--     {"NA":"HallCCT", "TY":63, "AD":"0x1234"},
	--     {"NA":"HallRGB", "TY":664, "AD":"0x5678"},
	--     {"NA":"RoomDIM", "TY":62, "AD":"0x1111"},
	--     {"NA":"Kitchen", "TY":61, "AD":"0x2222"}
	-- ]}
	-- txt = ""
	-- txt = sta.."DEVL\":["
	-- txt = txt..sta.."NA"..mop.."HallCCT"..dop.."TY"..nmop.."63"..ndop.."AD"..mop.."0x1234"..en
	-- txt = txt..","..sta.."NA"..mop.."HallCCT"..dop.."TY"..nmop.."64"..ndop.."AD"..mop.."0x5678"..en
	-- txt = txt..","..sta.."NA"..mop.."RoomDIM"..dop.."TY"..nmop.."62"..ndop.."AD"..mop.."0x1111"..en
	-- txt = txt..","..sta.."NA"..mop.."Kitchen"..dop.."TY"..nmop.."61"..ndop.."AD"..mop.."0x2222"..en
	-- txt = txt.."]}"

	local txt, array, i, name, ty, addr

	-- prepare response data, array = {id, type, name, addr} * n
	array = db:devices_load()
	-- array = {}
	-- array[1] = 4
	-- array[2] = 65535
	-- array[3] = "unknown"
	-- array[4] = 17717

	-- prepare response txt
	txt = ""
	txt = sta.."DEVL\":["
	if array ~= nil then
		i = 1
		while (array[i] ~= nil) do
			ty =  array[i+1]
			name = array[i+2]
			addr = array[i+3]
			if i == 1 then txt = txt..sta.."NA"..mop..name..dop.."TY"..nmop..ty..ndop.."AD"..mop..addr..en 
			else txt = txt..","..sta.."NA"..mop..name..dop.."TY"..nmop..ty..ndop.."AD"..mop..addr..en end
			i = i + 4
		end
	end
	txt = txt.."]}"

	-- txt = "{\"DEVL\":[{\"NA\":\"Kitchen\",\"TY\":62,\"AD\":\"17717\"}]}"

	_dbg(txt)
	return txt
end

-- loadDeviceList(self)

function ctlNetStatus(self, openclose)
	local txt
	if (openclose == 0) then 
		serial:permitjoin(0) 
	elseif (openclose == 1) then 
		serial:permitjoin(180) 
	end
	txt = "open or close net: "..openclose.."(0-close net, 1-open net)"
	_dbg(txt)
	return txt
end

-- ctlNetStatus(self, 0)

function settingRoomList(self)
	-- txt = ""
	-- txt = sta.."SETR\":["
	-- txt = txt..sta.."NA"..mop.."Bigroom"..dop.."IC"..nmop.."15"..ndop.."GN"..nmop.."1"..ndop.."SW"..nmop.."1"..nen
	-- txt = txt..","..sta.."NA"..mop.."Childroom"..dop.."IC"..nmop.."5"..ndop.."GN"..nmop.."2"..ndop.."SW"..nmop.."0"..nen
	-- txt = txt..","..sta.."NA"..mop.."Guestroom"..dop.."IC"..nmop.."7"..ndop.."GN"..nmop.."3"..ndop.."SW"..nmop.."1"..nen
	-- txt = txt..","..sta.."NA"..mop.."Kitchen"..dop.."IC"..nmop.."3"..ndop.."GN"..nmop.."4"..ndop.."SW"..nmop.."0"..nen
	-- txt = txt.."]}"

	local txt, i
	local array, gid, tag, name, s_name, onoff, level

	-- prepare response data, array: id, tag, name, sid, onoff, lum
	array = db:grooms_load()

	-- prepare response txt
	txt = ""
	txt = sta.."SETR\":["
	if array ~= nil then
		i = 1
		while (array[i] ~= nil) do
			gid = array[i]
			tag = array[i+1]
			name = array[i+2]
			s_name = array[i+3]
			onoff = array[i+4]
			level = array[i+5]
			if i == 1 then
				txt = txt..sta.."NA"..mop..name..dop.."IC"..nmop..tag..ndop.."GN"..nmop..gid..ndop.."SW"..nmop..onoff..nen
			else
				txt = txt..","..sta.."NA"..mop..name..dop.."IC"..nmop..tag..ndop.."GN"..nmop..gid..ndop.."SW"..nmop..onoff..nen
			end
			i = i + 6
		end
	end
	txt = txt.."]}"

	_dbg(txt)
	return txt
end

-- settingRoomList(self)

function loadAddRoom(self, rid)
	-- txt = ""
	-- txt = sta.."DEV\":["
	-- txt = txt..sta.."NA"..mop.."CCT1"..dop.."AD"..mop.."0x1234"..dop.."TY"..nmop.."63"..nen
	-- txt = txt..","..sta.."NA"..mop.."RGB1"..dop.."AD"..mop.."0x5678"..dop.."TY"..nmop.."64"..nen
	-- txt = txt..","..sta.."NA"..mop.."DIM1"..dop.."AD"..mop.."0x1111"..dop.."TY"..nmop.."62"..nen
	-- txt = txt.."]"
	-- if (loadRoomAdjust ~= nil) then
	-- 	txt = txt..","
	-- 	txt = txt.."\"SDEV\":[\"".."0x1234"..dop.."0x5678".."\"]"
	-- end
	-- txt = txt.."}"
	local txt, array, i, name, ty, addr, dids, splitlist, k, v

	-- prepare response data
	-- get devices list, array = {id, type, name, addr} * n
	array = db:devices_load()
	splitlist = {}
	-- get selected devices list(dids), need to check if each did is available in case the did has been deleted
	if (rid ~= nil) then 
		dids = db:groups_getdids(rid) 
		if (dids ~= nil) then
			string.gsub(dids, '[^,]+', function(w) table.insert(splitlist, w) end) 
		end
	end

	-- prepare response txt
	txt = sta.."DEV\":["
	if array ~= nil then
		i = 1
		while (array[i] ~= nil) do
			ty = array[i+1]
			name = array[i+2]
			addr = array[i+3]
			if i == 1 then 
				txt = txt..sta.."NA"..mop..name..dop.."AD"..mop..addr..dop.."TY"..nmop..ty..nen
			else 
				txt = txt..","..sta.."NA"..mop..name..dop.."AD"..mop..addr..dop.."TY"..nmop..ty..nen
			end
			i = i + 4
		end
	end
	txt = txt.."]"
	if (splitlist[1] ~= nil) then
		i = 1
		for k,v in ipairs(splitlist) do
			-- check if each did is available in case the did has been deleted
			flag = db:devices_checkid(v)
			if flag == 1 then 
				addr = db:devices_getaddr(v)
				if i == 1 then txt = txt..",\"SDEV\":[\""..addr else txt = txt..dop..addr end
				i = i + 1
			end			
		end
		if i > 1 then txt = txt.."\"]" end
	end
	txt = txt.."}"

	_dbg(txt)
	return txt
end

-- loadAddRoom(self, nil)

function newDeviceList(self)
	-- txt = ""
	-- txt = sta.."NDEV\":["
	-- txt = txt..sta.."NA"..mop.."newCCT1"..dop.."TY"..nmop.."63"..nen
	-- txt = txt..","..sta.."NA"..mop.."newRGB1"..dop.."TY"..nmop.."64"..nen
	-- txt = txt..","..sta.."NA"..mop.."newDIM1"..dop.."TY"..nmop.."62"..nen
	-- txt = txt..","..sta.."NA"..mop.."newONF1"..dop.."TY"..nmop.."61"..nen
	-- txt = txt.."]}"
	local txt, dids, gdids, ndids, splitlist, k, v, i, ni, name, tag, addr, flag

	-- prepare response data 
	-- get devices not exist in any room, that is 1. get the all devices; 2. get the devices already in rooms; 3. 1-2
	ni = 1
	ndids = {}
	dids = db:devices_getavailableids()
	gdids = db:grooms_loaddids()

	if (dids ~= nil) then
		if (gdids ~= nil) then
			splitlist = {}
			string.gsub(gdids, '[^,]+', function(w) table.insert(splitlist, w) end) 
			for k,v in ipairs(dids) do
				flag = 0
				for k1,v1 in ipairs(splitlist) do
					if v == v1 then flag = 1 end
				end
				if flag == 0 then 
					_dbg("ndid["..ni.."] = "..v)
					ndids[ni] = v
					ni = ni + 1
				end
			end
		else
			ndids = dids
		end
	end

	-- prepare response txt
	txt = ""
	txt = sta.."NDEV\":["
	if ndids ~= nil then 
		ni = 1
		for k,v in ipairs(ndids) do
			name, tag, addr = db:devices_getdetail(v)
			if ni == 1 then
				txt = txt..sta.."NA"..mop..name..dop.."TY"..nmop..tag..nen
			else
				txt = txt..","..sta.."NA"..mop..name..dop.."TY"..nmop..tag..nen
			end
			ni = ni + 1
		end
	end
	txt = txt.."]}"

	_dbg(txt)
	return txt
end

-- newDeviceList(self)
function loadSceneSchedule(self)
	-- if (loadSceneSchedule ~= nil) then
	-- 	txt = ""
	-- 	txt = sta.."SCHE\":["
	-- 	txt = txt..sta.."SID"..nmop.."1"..ndop.."LN"..mop.."Start work"..dop.."TM"..mop.."08:00"..dop.."RP"..mop..",1,2,3,4,5"..dop.."ONF"..nmop.."1"..nen
	-- 	txt = txt..","..sta.."SID"..nmop.."2"..ndop.."LN"..mop.."Rest"..dop.."TM"..mop.."12:00"..dop.."RP"..mop..",1"..dop.."ONF"..nmop.."1"..nen
	-- 	txt = txt..","..sta.."SID"..nmop.."3"..ndop.."LN"..mop.."Start work"..dop.."TM"..mop.."13:00"..dop.."RP"..mop..",6,7"..dop.."ONF"..nmop.."0"..nen
	-- 	txt = txt..","..sta.."SID"..nmop.."4"..ndop.."LN"..mop.."Offwork"..dop.."TM"..mop.."19:00"..dop.."RP"..mop..",1,2,3,4,5,6,7"..dop.."ONF"..nmop.."1"..nen
	-- 	txt = txt..","..sta.."SID"..nmop.."5"..ndop.."LN"..mop.."Gohome"..dop.."TM"..mop.."22:00"..dop.."RP"..mop..",1,2,3,4,5,6"..dop.."ONF"..nmop.."1"..nen
	-- 	txt = txt..","..sta.."SID"..nmop.."6"..ndop.."LN"..mop.."Gohome"..dop.."TM"..mop.."23:00"..dop.."RP"..mop..""..dop.."ONF"..nmop.."1"..nen
	-- 	txt = txt.."]}"
	-- end

	local txt, sid, name, time, rp, onoff, array, i

	-- prepare response data, array = {id, type, name, addr} * n
	array = db:timers_loadschedule()

	-- prepare response txt
	txt = sta.."SCHE\":["
	if array ~= nil then
		i = 1
		while (array[i] ~= nil) do
			sid = array[i]
			name = array[i+1]
			time = array[i+2]
			rp = array[i+3]
			onoff = array[i+4]
			if i == 1 then 
				txt = txt..sta.."SID"..nmop..sid..ndop.."LN"..mop..name..dop.."TM"..mop..time..dop.."RP"..mop..rp..dop.."ONF"..nmop..onoff..nen
			else 
				txt = txt..","..sta.."SID"..nmop..sid..ndop.."LN"..mop..name..dop.."TM"..mop..time..dop.."RP"..mop..rp..dop.."ONF"..nmop..onoff..nen 
			end
			i = i + 5
		end
	end
	txt = txt.."]}"

	_dbg(txt)
	return txt
end

-- loadSceneSchedule(self)

function controllScheduleONF(self, scheduleId, switchONF)
	local txt
	db:timers_setonf(scheduleId, switchONF)
	txt = "id:"..scheduleId.." on/off: "..switchONF
	_dbg(txt)
	return txt
end

-- controllScheduleONF(self, 2, 1)

function loadAddSchedulePage(self)
	-- {"RMS":[
	--    {"GN":1, "NA":"Child room", "SE":["Watching movie", "Reading", "Cleaning"]} ,
	--    {"GN":2, "NA":"Hall", "SE":["Reading", "Cleaning"]} ,
	--    {"GN":3, "NA":"Kitchen", "SE":["Wake up", "Reading", "Cleaning"]}
	--   ]
	-- }
	-- txt = sta.."RMS\":["
	-- txt = txt..sta.."GN"..nmop.."1"..ndop.."NA"..mop.."Child room"..dop.."SE\":[\"".."Watching movie"..dop.."Reading"..dop.."Cleaning".."\"]}"
	-- txt = txt..","..sta.."GN"..nmop.."2"..ndop.."NA"..mop.."Hall"..dop.."SE\":[\"".."Reading"..dop.."Cleaning".."\"]}"
	-- txt = txt..","..sta.."GN"..nmop.."3"..ndop.."NA"..mop.."Kitchen"..dop.."SE\":[\"".."Wake up"..dop.."Reading"..dop.."Cleaning".."\"]}"
	-- txt = txt.."]}"

	local txt, array, i, gn, na, se

	-- prepare response data, array = {id, type, name, addr} * n
	array = db:timers_loadaddschedule()
	-- prepare response txt
	txt = sta.."RMS\":["
	if array ~= nil then
		i = 1
		while (array[i] ~= nil) do
			gn = array[i]
			na = array[i+1]
			se = array[i+2]
			if i == 1 then 
				txt = txt..sta.."GN"..nmop..gn..ndop.."NA"..mop..na..dop.."SE\":["..se.."]}"
			else 
				txt = txt..","..sta.."GN"..nmop..gn..ndop.."NA"..mop..na..dop.."SE\":["..se.."]}"
			end
			i = i + 4
		end
	end
	txt = txt.."]}"

	_dbg(txt)
	return txt
end
-- loadAddSchedulePage(self)

function loadModificationSchedulePage(self, id)
	-- {
	--   "RMS":[
	--    {"GN":1, "NA":"Child room", "SE":["Watching movie", "Reading", "Cleaning"]?ASE":"Watching movie"} ,
	--    {"GN":2, "NA":"Hall", "SE":["Reading", "Cleaning"]?ASE":""} ,
	--    {"GN":3, "NA":"Kitchen", "SE":["Wake up", "Reading", "Cleaning"],"ASE":"Reading"}
	--   ]
	-- }
	-- txt = sta.."RMS\":["
	-- txt = txt..sta.."GN"..nmop.."1"..ndop.."NA"..mop.."Child room"..dop.."SE\":[\"".."Watching movie"..dop.."Reading"..dop.."Cleaning".."\"]"..ndop.."ASE"..mop.."Watching movie".."\"}"
	-- txt = txt..","..sta.."GN"..nmop.."2"..ndop.."NA"..mop.."Hall"..dop.."SE\":[\"".."Reading"..dop.."Cleaning".."\"]"..ndop.."ASE"..mop.."".."\"}"
	-- txt = txt..","..sta.."GN"..nmop.."3"..ndop.."NA"..mop.."Kitchen"..dop.."SE\":[\"".."Wake up"..dop.."Reading"..dop.."Cleaning".."\"]"..ndop.."ASE"..mop.."Wake up".."\"}"
	-- txt = txt.."]}"

	local txt, array, i, gn, na, se, ase
	-- prepare response data, array = {id, type, name, addr} * n
	array = db:timers_loadaddschedule(id)
	-- prepare response txt
	txt = sta.."RMS\":["
	if array ~= nil then
		i = 1
		while (array[i] ~= nil) do
			gn = array[i]
			na = array[i+1]
			se = array[i+2]
			ase = array[i+3]
			if i == 1 then 
				txt = txt..sta.."GN"..nmop..gn..ndop.."NA"..mop..na..dop.."SE\":["..se.."]"..ndop.."ASE"..mop..ase.."\"}"
			else 
				txt = txt..","..sta.."GN"..nmop..gn..ndop.."NA"..mop..na..dop.."SE\":["..se.."]"..ndop.."ASE"..mop..ase.."\"}"
			end
			i = i + 4
		end
	end
	txt = txt.."]}"

	_dbg(txt)
	return txt
end
-- loadModificationSchedulePage(self, 10)

function saveSchedule(self, scheID, scheTime, LabelName, scheRepeat, roomGNList, sceneList)
	local txt
	LabelName = _decodeURI(LabelName)
	sceneList = _decodeURI(sceneList)

	if (scheRepeat == nil) then 
		scheRepeat = "" 
	end
	
	db:timers_addschedule(scheID, LabelName, scheTime, scheRepeat, roomGNList, sceneList)
	if (scheID ~= nil) then
		txt = "Alert id:"..scheID.." "          -- Alert schedule save
	else
		txt = "Add "            -- add schedule save
	end

	txt = txt.."time: "..scheTime.." LabelName:"..LabelName
	if (scheRepeat ~= nil) then
		txt = txt.." RP:"..scheRepeat
	end

	txt = txt.." RGN:"..roomGNList.." SCL:"..sceneList

	-- txt = txt.."time: "..scheTime.." LabelName:"..LabelName.." RP:"..scheRepeat.." RGN:"..roomGNList.." SCL:"..sceneList
	_dbg(txt)
	return txt
end
-- saveSchedule(self, nil, "test_timer4-new", "19:10", nil, ",74", ",2")

function deleteSchedule(self, scheID)
	local txt
	db:timers_deleteschedule(scheID)
	txt = "delschedule:"..scheID.." OK!"
	return txt;
end

-- deleteSchedule(self, 3)

function loadAccessories(self)
	-- {"DEV":[
	--   {"AD":"0x1234", "TY":71, "NA":"High-endControll", "SA":1} ,
	--   {"AD":"0x5678", "TY":72, "NA":"RGBWControll", "SA":0} ,
	--   {"AD":"0x1122", "TY":73, "NA":"CCTControll", "SA":0}
	-- ]}

	-- txt = ""
	-- txt = sta.."DEV".."\":["
	-- txt = txt..sta.."AD"..mop.."0x1234"..dop.."TY"..nmop.."71"..ndop.."NA"..mop.."High-endControll"..dop.."SA"..nmop.."1"..nen
	-- txt = txt..","..sta.."AD"..mop.."0x5678"..dop.."TY"..nmop.."72"..ndop.."NA"..mop.."RGBControll"..dop.."SA"..nmop.."0"..nen
	-- txt = txt..","..sta.."AD"..mop.."0x1122"..dop.."TY"..nmop.."73"..ndop.."NA"..mop.."CCTControll"..dop.."SA"..nmop.."0"..nen
	-- txt = txt.."]}"

	local txt, array, i, j, name, ty, addr

	-- prepare response data, array = {id, type, name, addr} * n
	array = db:devices_load()

	-- prepare response txt
	txt = ""
	txt = sta.."DEV".."\":["
	if array ~= nil then
		i, j = 1, 1
		while (array[i] ~= nil) do
			ty =  array[i+1]
			name = array[i+2]
			addr = array[i+3]
			if ty == 71 or ty == 72 or ty == 73 then
				if j == 1 then txt = txt..sta.."AD"..mop..addr..dop.."TY"..nmop..ty..ndop.."NA"..mop..name..dop.."SA"..nmop.."1"..nen
				else txt = txt..","..sta.."AD"..mop..addr..dop.."TY"..nmop..ty..ndop.."NA"..mop..name..dop.."SA"..nmop.."0"..nen end
				j = j + 1
			end
			i = i + 4
		end
	end
	txt = txt.."]}"

	_dbg(txt)
	return txt
end

function loadAccessoriesPage(self, loadControll)
	--  {"RM":[
	--     {"NA":"Hall", "GN":1, "IC":2},
	--     {"NA":"Bigroom", "GN":2, "IC":3},
	--     {"NA":"Childroom","GN":3, "IC":1}
	--     ] ,
	--   "SGN":[
	--     {"BN":"0x1234", "RL":[1,2]},
	--     {"BN":"0x2345", "RL":[1]},
	--     {"BN":"0x4576", "RL":[2]}
	--   ]
	-- }
    txt = ""
	txt = sta.."RM\":["
	txt = txt..sta.."NA"..mop.."Hall"..dop.."GN"..nmop.."1"..ndop.."IC"..nmop.."2"..nen
	txt = txt..","..sta.."NA"..mop.."Bigroom"..dop.."GN"..nmop.."2"..ndop.."IC"..nmop.."3"..nen
	txt = txt..","..sta.."NA"..mop.."Childroom"..dop.."GN"..nmop.."3"..ndop.."IC"..nmop.."1"..nen
	txt = txt.."],"

	if (loadControll == "0x1234") then         -- if this device address is hige-end controll    	
	    txt = txt.."\"SGN\":["
		txt = txt..sta.."BN"..mop.."0x1234"..dop.."RL".."\":[".."1"..",".."2".."]}"
		txt = txt..","..sta.."BN"..mop.."0x5678"..dop.."RL".."\":[".."1".."]}"
		txt = txt..","..sta.."BN"..mop.."0x1122"..dop.."RL".."\":[".."2".."]}"
		txt = txt..","..sta.."BN"..mop.."0x2222"..dop.."RL".."\":[".."3".."]}"
		txt = txt..","..sta.."BN"..mop.."0x3333"..dop.."RL".."\":[".."2"..",".."3".."]}"
		txt = txt..","..sta.."BN"..mop.."0x4444"..dop.."RL".."\":[".."1"..",".."2"..",".."3".."]}"
		txt = txt.."]}"
	else 
		txt = txt.."\"SGN\":["
		txt = txt..sta.."BN"..mop.."0x1234"..dop.."RL".."\":[".."1"..",".."2".."]}"
		txt = txt..","..sta.."BN"..mop.."0x5678"..dop.."RL".."\":[".."1".."]}"
		txt = txt..","..sta.."BN"..mop.."0x1122"..dop.."RL".."\":[".."2".."]}"
		txt = txt.."]}"
	end
end

function saveControllDate(self)
	txt = "AD:"..devAddr
	groupList = {CTL1, CTL2, CTL3, CTL4, CTL5, CTL6}

	for i=1,6 do
		RoomList = {}
		if (groupList[i] ~= nil) then
			string.gsub(groupList[i], '[^,]+', function(w) table.insert(RoomList, w) end )   
			txt = txt.." G"..i..":"
			for i,v in ipairs(RoomList) do 
				txt = txt.." "..v
			end
		end
	end
end

function loadDeviceSoftwareUpdatePage(self)
	--   {"UDEV":[
	--    {"NA":"CCTLight", "AD":"0x1111", "ORG":"1.1.1", "NORG":"1.1.2"} ,
	--    {"NA":"RGBLight", "AD":"0x2222", "ORG":"1.2.1", "NORG":"1.2.5"} ,
	--    {"NA":"MyDimLight", "AD":"0x3333", "ORG":"1.3.2", "NORG":"1.3.3"}
	-- ],		 
	-- "CDEV":60
	-- }

   	txt = ""
   	txt = sta.."UDEV\":["
   	txt = txt..sta.."NA"..mop.."CCTLight"..dop.."AD"..mop.."0x1111"..dop.."ORG"..mop.."1.1.1"..dop.."NORG"..mop.."1.1.2"..en
   	txt = txt..","..sta.."NA"..mop.."RGBLight"..dop.."AD"..mop.."0x2222"..dop.."ORG"..mop.."1.3.1"..dop.."NORG"..mop.."1.3.5"..en
   	txt = txt..","..sta.."NA"..mop.."MyDimLight"..dop.."AD"..mop.."0x3333"..dop.."ORG"..mop.."1.5.1"..dop.."NORG"..mop.."1.5.2"..en
   	txt = txt..","..sta.."NA"..mop.."Gateway1"..dop.."AD"..mop.."0x4444"..dop.."ORG"..mop.."1.4.1"..dop.."NORG"..mop.."1.4.5"..en
   	txt = txt..","..sta.."NA"..mop.."HdControll"..dop.."AD"..mop.."0x5555"..dop.."ORG"..mop.."2.1.1"..dop.."NORG"..mop.."2.1.2"..en
   	txt = txt.."],"
   	txt = txt.."\"CDEV\":".."60"
   	txt = txt.."}"
end

function updateDevice(self, updateDevList)
	txt = "update: "
	splitlist = {}
	string.gsub(updateDevList, '[^,]+', function(w) table.insert(splitlist, w) end )	
	for i,v in ipairs(splitlist) do txt = txt.." "..v end
end

function devAddr(self, devAddr)
if (devAddr ~= nil) then
		txt = "AD:"..devAddr
		groupList = {CTL1, CTL2, CTL3, CTL4, CTL5, CTL6}

		for i=1,6
			do

			RoomList = {}
			if (groupList[i] ~= nil) then
				string.gsub(groupList[i], '[^,]+', function(w) table.insert(RoomList, w) end )   
		  
				txt = txt.." G"..i..":"
				for i,v in ipairs(RoomList)
					do txt = txt.." "..v
				end
			end
		end
	end
end


function loadControll(self, loadControll)
    -- if (loadControll ~= nil) then
    -- 	txt = ""
	   --  txt = sta.."RM\":["
	   --  txt = txt..sta.."NA"..mop.."Hall"..dop.."GN"..nmop.."1"..ndop.."IC"..nmop.."2"..nen
	   --  txt = txt..","..sta.."NA"..mop.."Bigroom"..dop.."GN"..nmop.."2"..ndop.."IC"..nmop.."3"..nen
	   --  txt = txt..","..sta.."NA"..mop.."Childroom"..dop.."GN"..nmop.."3"..ndop.."IC"..nmop.."1"..nen
	   --  txt = txt.."],"

    -- 	if (loadControll == "0x1234") then
    -- 		txt = txt.."\"SGN\":["
	   --  	txt = txt..sta.."BN"..mop.."0x1234"..dop.."RL".."\":[".."1"..",".."2".."]}"
	   --  	txt = txt..","..sta.."BN"..mop.."0x5678"..dop.."RL".."\":[".."1".."]}"
	   --  	txt = txt..","..sta.."BN"..mop.."0x1122"..dop.."RL".."\":[".."2".."]}"
	   --  	txt = txt..","..sta.."BN"..mop.."0x2222"..dop.."RL".."\":[".."3".."]}"
	   --  	txt = txt..","..sta.."BN"..mop.."0x3333"..dop.."RL".."\":[".."2"..",".."3".."]}"
	   --  	txt = txt..","..sta.."BN"..mop.."0x4444"..dop.."RL".."\":[".."1"..",".."2"..",".."3".."]}"
	   --  	txt = txt.."]}"
    -- 	else 
	   --  	txt = txt.."\"SGN\":["
	   --  	txt = txt..sta.."BN"..mop.."0x1234"..dop.."RL".."\":[".."1"..",".."2".."]}"
	   --  	txt = txt..","..sta.."BN"..mop.."0x5678"..dop.."RL".."\":[".."1".."]}"
	   --  	txt = txt..","..sta.."BN"..mop.."0x1122"..dop.."RL".."\":[".."2".."]}"
	   --  	txt = txt.."]}"
    --     end
    -- end

	local txt, array, i, gid, tag, name

	if loadControll ~= nil then
		-- array: id, tag, name, sid, onoff, lum
		array = db:grooms_load()
		if array ~= nil then
			i = 1
			txt = sta.."RM\":["
			while (array[i] ~= nil) do
				gid = array[i]
				tag = array[i+1]
				name = array[i+2]
				if i == 1 then txt = txt..sta.."NA"..mop..name..dop.."GN"..nmop..gid..ndop.."IC"..nmop..tag..nen
				else txt = txt..","..sta.."NA"..mop..name..dop.."GN"..nmop..gid..ndop.."IC"..nmop..tag..nen end
				i = i + 6
			end
			txt = txt.."]"
		end

		txt = txt..",\"SGN\":["
		if loadControll == "0x1234" then
			txt = txt..sta.."BN"..mop.."0x1234"..dop.."RL".."\":[".."1"..",".."2".."]}"
	    	txt = txt..","..sta.."BN"..mop.."0x5678"..dop.."RL".."\":[".."1".."]}"
		else
			txt = txt..sta.."BN"..mop.."0x1234"..dop.."RL".."\":[".."1"..",".."2".."]}"
	    	txt = txt..","..sta.."BN"..mop.."0x5678"..dop.."RL".."\":[".."1".."]}"
		end
		txt = txt.."]}"
	end

	_dbg(txt)
	return txt
end

function loadUpdateDev(self)

	--   {"UDEV":[
		  --    {"NA":"CCTLight", "AD":"0x1111", "ORG":"1.1.1", "NORG":"1.1.2"} ,
		  --    {"NA":"RGBLight", "AD":"0x2222", "ORG":"1.2.1", "NORG":"1.2.5"} ,
		  --    {"NA":"MyDimLight", "AD":"0x3333", "ORG":"1.3.2", "NORG":"1.3.3"}
		  -- ]ï¼?		  -- "CDEV":60
	   -- }

	   if (loadUpdateDev ~= nil) then
	   		txt = ""
	   		txt = sta.."UDEV\":["
	   		txt = txt..sta.."NA"..mop.."CCTLight"..dop.."AD"..mop.."0x1111"..dop.."ORG"..mop.."1.1.1"..dop.."NORG"..mop.."1.1.2"..en
	   		txt = txt..","..sta.."NA"..mop.."RGBLight"..dop.."AD"..mop.."0x2222"..dop.."ORG"..mop.."1.3.1"..dop.."NORG"..mop.."1.3.5"..en
	   		txt = txt..","..sta.."NA"..mop.."MyDimLight"..dop.."AD"..mop.."0x3333"..dop.."ORG"..mop.."1.5.1"..dop.."NORG"..mop.."1.5.2"..en
	   		txt = txt..","..sta.."NA"..mop.."Gateway1"..dop.."AD"..mop.."0x4444"..dop.."ORG"..mop.."1.4.1"..dop.."NORG"..mop.."1.4.5"..en
	   		txt = txt..","..sta.."NA"..mop.."HdControll"..dop.."AD"..mop.."0x5555"..dop.."ORG"..mop.."2.1.1"..dop.."NORG"..mop.."2.1.2"..en
	   		txt = txt.."],"
	   		txt = txt.."\"CDEV\":".."60"
	   		txt = txt.."}"
	   end
end

function loadElectrityAnalyze(self)
	-- {"EDC":[
	--    {"AD":"0x1234", "NA":"CCT Light", "WT":35, "UT":50} ,
	--    {"AD":"0X5678", "NA":"RGB Light", "WT":25, "UT":20} ,
	--    {"AD":"0x1111", "NA":"Room RGB", "WT":15, "UT":70} ,
	--    {"AD":"0X2222", "NA":"Dim Light", "WT":12, "UT":90} ,
	--    {"AD":"0X3333", "NA":"Big Light", "WT":45, "UT":150} 
	-- ]}
	-- txt = ""
	-- txt = sta.."EDC\":["
	-- txt = txt..sta.."AD"..mop.."0x1234"..dop.."NA"..mop.."CCT Light"..dop.."WT"..nmop.."35"..ndop.."UT"..nmop.."50"..nen
	-- txt = txt..","..sta.."AD"..mop.."0x5678"..dop.."NA"..mop.."RGB Light"..dop.."WT"..nmop.."25"..ndop.."UT"..nmop.."28"..nen
	-- txt = txt..","..sta.."AD"..mop.."0x1111"..dop.."NA"..mop.."CCT 1"..dop.."WT"..nmop.."15"..ndop.."UT"..nmop.."70"..nen
	-- txt = txt..","..sta.."AD"..mop.."0x2222"..dop.."NA"..mop.."CCT 2"..dop.."WT"..nmop.."20"..ndop.."UT"..nmop.."90"..nen
	-- txt = txt..","..sta.."AD"..mop.."0x3333"..dop.."NA"..mop.."Dim Light"..dop.."WT"..nmop.."10"..ndop.."UT"..nmop.."33"..nen
	-- txt = txt..","..sta.."AD"..mop.."0x4444"..dop.."NA"..mop.."Big Light"..dop.."WT"..nmop.."45"..ndop.."UT"..nmop.."152"..nen
	-- txt = txt.."]}"

	local txt, array, i, name, addr, wt, ut, lum, onoff
	local minW, maxW, wplevle = 8, 330, 330/254

	-- prepare response data, array = {id, name, addr, onh, uen} * n
	array = db:devices_loadelectrityanalyze()

	-- prepare response txt
	txt = sta.."EDC\":["
	if array ~= nil then
		i = 1
		while (array[i] ~= nil) do
			name = array[i+1]
			addr = array[i+2]
			ut = array[i+3]
			wt = math.floor(array[i+7] / 10)
			lum = array[i+4]
			onoff = array[i+5]
			-- wt = math.floor(lum * wplevle + minW)
			-- if onoff == 0 then wt = 0 end
			if i == 1 then txt = txt..sta.."AD"..mop..addr..dop.."NA"..mop..name..dop.."WT"..nmop..wt..ndop.."UT"..nmop..ut..nen
			else txt = txt..","..sta.."AD"..mop..addr..dop.."NA"..mop..name..dop.."WT"..nmop..wt..ndop.."UT"..nmop..ut..nen end
			i = i + 8
		end
	end
	txt = txt.."]}"

	_dbg(txt)
	return txt
end

-- loadElectrityAnalyze(self)

function setSystemTime(self, clientSystemTime)
	local txt, systemtime
	systemtime = _decodeURI(clientSystemTime)
	serial:t_setsystemtime(systemtime)
	txt = "clientSystemTime:"..systemtime
	_dbg(txt)
	return txt
end
-- setSystemTime(self, "2018-1-2 15:20:40")

function b_setLum( self, lum )
	serial:setlum(lum)
	return "lum:"..lum
end

function b_setCct( self, cct )
	serial:setcct(cct)
	return "cct:"..cct
end

function b_setHue( self, hue )
	serial:sethue(hue)
	return "hue:"..hue
end

function testrgbw(self, hue, saturation, colortemp, color)
	serial:testrgbw_sethue(hue)
	serial:testrgbw_setsaturation(saturation)
	serial:testrgbw_setcolortemp(colortemp)
	serial:testrgbw_setcolor(color)
end