-- Copyright 2008 Steven Barth <steven@midlink.org>
-- Copyright 2011-2015 Jo-Philipp Wich <jow@openwrt.org>
-- Licensed to the public under the Apache License 2.0.
module("luci.controller.admin.zigbee", package.seeall)

function index()
	local fs = require "nixio.fs"

	entry({"admin", "zigbee"}, alias("admin", "zigbee", "room"), _("ZBweb"), 30).index = true

	entry({"admin", "zigbee", "room"}, template("admin_zigbee/room"), _("room"), 1)
	entry({"admin", "zigbee", "room_a"}, template("admin_zigbee/room_a"),nil)
	entry({"admin", "zigbee", "room", "jsonresponse"}, call("jsonresponse"), nil)

	-- scene label page --
	entry({"admin", "zigbee", "scene"}, template("admin_zigbee/scene"),nil)
	entry({"admin", "zigbee", "scene_modesetting"}, template("admin_zigbee/scene_modesetting"),nil)
	entry({"admin", "zigbee", "scene_objmodelist"}, template("admin_zigbee/scene_objmodelist"),nil)
	entry({"admin", "zigbee", "scene_objmodeadjust"}, template("admin_zigbee/scene_objmodeadjust"),nil)
	entry({"admin", "zigbee", "scene_objaddmode"}, template("admin_zigbee/scene_objaddmode"),nil)
	entry({"admin", "zigbee", "scene_schedule"}, template("admin_zigbee/scene_schedule"),nil)
	entry({"admin", "zigbee", "scene_adjustschedule"}, template("admin_zigbee/scene_adjustschedule"),nil)

	-- analyze label page --
	entry({"admin", "zigbee", "analyze"}, template("admin_zigbee/analyze"), nil)
	entry({"admin", "zigbee", "analysis_electricity"}, template("admin_zigbee/analysis_electricity"), nil)
	entry({"admin", "zigbee", "analysis_baddevice"}, template("admin_zigbee/analysis_baddevice"), nil)
	entry({"admin", "zigbee", "analysis_usedtime"}, template("admin_zigbee/analysis_usedtime"), nil)
	
	-- setting child : device setting --
	entry({"admin", "zigbee", "setting"}, template("admin_zigbee/setting"), nil)
	entry({"admin", "zigbee", "setting_gatewaylist"}, template("admin_zigbee/setting_gatewaylist"), nil)
	entry({"admin", "zigbee", "setting_addgateway"}, template("admin_zigbee/setting_addgateway"), nil)
	entry({"admin", "zigbee", "setting_devicelist"}, template("admin_zigbee/setting_devicelist"), nil)
	entry({"admin", "zigbee", "setting_adddevice"}, template("admin_zigbee/setting_adddevice"), nil)

	-- setting child: group setting --
	entry({"admin", "zigbee", "setting_grouplist"}, template("admin_zigbee/setting_grouplist"), nil)
	entry({"admin", "zigbee", "setting_addgroup"}, template("admin_zigbee/setting_addgroup"), nil)
	entry({"admin", "zigbee", "setting_objgroup"}, template("admin_zigbee/setting_objgroup"), nil)

	-- setting child: room setting
	entry({"admin", "zigbee", "setting_roomlist"}, template("admin_zigbee/setting_roomlist"), nil)
	entry({"admin", "zigbee", "setting_addroom"}, template("admin_zigbee/setting_addroom"), nil)
	entry({"admin", "zigbee", "setting_objroom"}, template("admin_zigbee/setting_objroom"), nil)
	entry({"admin", "zigbee", "setting_roomicon"}, template("admin_zigbee/setting_roomicon"), nil)

	-- setting child: room accessories
	entry({"admin", "zigbee", "setting_accessories"}, template("admin_zigbee/setting_accessories"), nil)
	entry({"admin", "zigbee", "setting_controll"}, template("admin_zigbee/setting_controll"), nil)
	entry({"admin", "zigbee", "setting_controllsix"}, template("admin_zigbee/setting_controllsix"), nil)

	-- setting child: room device update
	entry({"admin", "zigbee", "setting_deviceupdate"}, template("admin_zigbee/setting_deviceupdate"), nil)

	-- setting child: room about
	entry({"admin", "zigbee", "setting_about"}, template("admin_zigbee/setting_about"), nil)
	entry({"admin", "zigbee", "setting_aboutfunction"}, template("admin_zigbee/setting_aboutfunction"), nil)
	entry({"admin", "zigbee", "setting_aboutcopyright"}, template("admin_zigbee/setting_aboutcopyright"), nil)
	entry({"admin", "zigbee", "setting_aboutupdate"}, template("admin_zigbee/setting_aboutupdate"), nil)

	entry({"admin", "zigbee", "setting", "setjump"}, call("setjump"), nil)
	entry({"admin", "zigbee", "setting", "devctlone"}, template("admin_zigbee/devctlone"), nil)
end


function snd2client(...)
	print("Content-Type: text/plain\n")
	print(...)
end


function jsonresponse()
	local http = require "luci.http"
	local jres = require "luci.model.jsonresponse"

	txt = nil
	sta = "{\""
	en = "\"}"
	nen = "}"
	mop = "\":\""
	dop = "\",\""
	nmop = "\":"
	ndop = ",\""

	-- response JSON Date
	local loadRoom = tonumber(http.formvalue("loadRoom"))
	-------------------------    response to client message     -----------------------------------
	local allRoom = tonumber(http.formvalue("allRoom"))

	local groupNum = tonumber(http.formvalue("groupNum"))
	local roomSwitch = tonumber(http.formvalue("roomSwitch"))
	local roomLight = tonumber(http.formvalue("roomLight"))
	local roomModeName = http.formvalue("roomModeName")

	local deviceAddress = http.formvalue("deviceAddress")
	local deviceSwitch = tonumber(http.formvalue("deviceSwitch"))
	local deviceIdentify = tonumber(http.formvalue("deviceIdentify"))
	
	local slideLevel = tonumber(http.formvalue("slideLevel"))
	local slideTemp = tonumber(http.formvalue("slideTemp"))
	local slideColor = tonumber(http.formvalue("slideColor"))

	local groupNumList = http.formvalue("groupNumList")
	local sceneSwitch = tonumber(http.formvalue("sceneSwitch"))
	local sceneGroupNum = tonumber(http.formvalue("sceneGroupNum"))
	local addSceneName = http.formvalue("addSceneName")
	local addSceneSave = tonumber(http.formvalue("addSceneSave"))
	local addSceneNameOrg = http.formvalue("addSceneNameOrg")

	local delDevice = http.formvalue("delDevice")
	local settingRoomList = tonumber(http.formvalue("settingRoomList"))
	local settingRoomGN = tonumber(http.formvalue("settingRoomGN"))
	local delRoom = http.formvalue("delRoom")
	local delUserMode = http.formvalue("delUserMode")

	local addRoomSwitch = tonumber(http.formvalue("addRoomSwitch"))
	local devList = http.formvalue("devList")
	local addRoomSlideFlag = tonumber(http.formvalue("addRoomSlideFlag"))
	local selectDeviceFlag = tonumber(http.formvalue("selectDeviceFlag"))
	local saveRoomDateFlag = tonumber(http.formvalue("saveRoomDateFlag"))
	local devAddr = http.formvalue("devAddr")
	local addRoomName = http.formvalue("addRoomName")
	local addRoomIcon = tonumber(http.formvalue("addRoomIcon"))
	local roomOrgName = http.formvalue("roomOrgName")

	local loadUpdateDev = tonumber(http.formvalue("loadUpdateDev"))
	local updateDevList = http.formvalue("updateDevList")
	
	local checkAddSceneName = http.formvalue("checkAddSceneName")

	local devRename = tonumber(http.formvalue("devRename"))
	local devAddrList = http.formvalue("devAddrList")
	local devNameList = http.formvalue("devNameList")

	local addRoomNameCheck = http.formvalue("addRoomNameCheck")
	local CTL1 = http.formvalue("CTL1")
	local CTL2 = http.formvalue("CTL2")
	local CTL3 = http.formvalue("CTL3")
	local CTL4 = http.formvalue("CTL4")
	local CTL5 = http.formvalue("CTL5")
	local CTL6 = http.formvalue("CTL6")
	local loadRoomChild = tonumber(http.formvalue("loadRoomChild"))
	local loadScene = tonumber(http.formvalue("loadScene"))
	local loadModeAdjust = http.formvalue("loadModeAdjust")
	local loadAddScene = tonumber(http.formvalue("loadAddScene"))
	local loadDeviceList  = tonumber(http.formvalue("loadDeviceList"))
	local ctlNetStatus  = tonumber(http.formvalue("ctlNetStatus"))
	local newDeviceList = tonumber(http.formvalue("newDeviceList"))
	local loadAddRoom = tonumber(http.formvalue("loadAddRoom"))
	local loadRoomAdjust = tonumber(http.formvalue("loadRoomAdjust"))
	local loadAccessories = tonumber(http.formvalue("loadAccessories"))
	local loadControll = http.formvalue("loadControll")

	local threeSlideFlag = tonumber(http.formvalue("threeSlideFlag"))

	if (loadRoom ~= nil) then txt = jres:loadRoom() end

	--设备更新
	if (updateDevList ~= nil) then
		txt = "update: "
		splitlist = {}
		
		string.gsub(updateDevList, '[^,]+', function(w) table.insert(splitlist, w) end )   
		  
		-- 循环取出 splitlist 数组的元素�?		for i,v in ipairs(splitlist)
			do txt = txt.." "..v
		end
	end



	--删除用户新增的场�?	if (delUserMode ~= nil) then txt = jres:delUserMode(delUserMode) end

	-- 检查新增场景名是否重复
	if (checkAddSceneName ~= nil) then txt = jres:checkAddSceneName(checkAddSceneName) end
	
	if (allRoom ~= nil) then txt = jres:allRoom(allRoom) end

	if (groupNum ~= nil) then                     -- room page
		if (roomSwitch ~= nil) then txt = jres:roomSwitch(groupNum, roomSwitch)
		elseif (slideLevel ~= nil) then txt = jres:roomLevel(groupNum, slideLevel)
		elseif (roomModeName ~= nil) then 
			roomModeName = decodeURI(roomModeName)
			txt = jres:roomModeName(groupNum, roomModeName) 
		end
	elseif (deviceAddress ~= nil) then            -- room_a page
		if (deviceSwitch ~= nil) then txt = jres:deviceSwitch(deviceAddress, deviceSwitch)
		elseif (slideLevel ~= nil) then txt = jres:deviceLevel(deviceAddress, slideLevel)
		elseif (slideTemp ~= nil) then txt = jres:deviceTemp(deviceAddress, slideTemp)
		elseif (slideColor ~= nil) then txt = jres:deviceColor(deviceAddress, slideColor)
		elseif (deviceIdentify ~= nil) then txt = jres:deviceIdentify(deviceAddress, deviceIdentify) end
	-- elseif (sceneSwitch ~= nil or threeSlideFlag ~= nil) then    -- add scene page
	elseif (addSceneSave ~= nil) then
		if (addSceneNameOrg ~= nil) then
			addSceneNameOrg = decodeURI(addSceneNameOrg)
		end
		if (addSceneName ~= nil) then
			addSceneName = decodeURI(addSceneName)
		end

		txt = jres:addSceneSave(addSceneSave, groupNumList, sceneGroupNum, addSceneName, sceneSwitch, slideLevel, slideTemp, slideColor, addSceneNameOrg)
	end

	-- three slide or switch controll
	if (threeSlideFlag ~= nil) then 
		txt = jres:addSceneSave(addSceneSave, groupNumList, sceneGroupNum, addSceneName, sceneSwitch, slideLevel, slideTemp, slideColor, addSceneNameOrg)
	end


	if (delDevice ~= nil) then txt = jres:delDevice(delDevice) end
	-- room setting page controll response
	if (settingRoomGN ~= nil) and (roomSwitch ~= nil) then txt = jres:roomSwitch(settingRoomGN, roomSwitch) end
    -- 删除房间
	if (delRoom ~= nil) then txt = jres:delRoom(delRoom) end
	if (devRename ~= nil)     then 
		if (devNameList ~= nil) then
			devNameList = decodeURI(devNameList)
		end
		txt = jres:devRename(devAddrList, devNameList) 
	end
	if (addRoomSwitch ~= nil) then txt = jres:addRoomSwitch(addRoomSwitch, devList) end

	-- if (addRoomSlideFlag ~= nil) then txt = jres:addRoomSlideFlag(addRoomSlideFlag, slideLevel, slideTemp, slideColor, devList) end
	if (addRoomSlideFlag ~= nil) then txt = jres:addRoomSlideFlag(slideLevel, slideTemp, slideColor, devList) end
	-- test add room slide, only change slide can send date to here
	-- if (addRoomSlideFlag ~= nil) then 
	-- 	-- txt = "addroom: devL "..devList
	-- 	if (slideLevel ~= nil) then
	-- 		-- txt = txt.."LE:"..slideLevel
	-- 		-- txt = jres:addRoomSlideFlag(slideLevel, nil, nil, devList)
	-- 		txt = jres:addRoomlevel(slideLevel, devList)
	-- 	elseif (slideTemp ~= nil) then
	-- 		-- txt = txt.."TE:"..slideTemp
	-- 		txt = jres:addRoomSlideFlag(nil, slideTemp, nil, devList)
	-- 	elseif (slideColor ~= nil) then
	-- 		-- txt = txt.."CO"..slideColor 
	-- 		txt = jres:addRoomSlideFlag(nil, nil, slideColor, devList)
	-- 	end
	-- end

	--新增房间选择设备
	if (selectDeviceFlag ~= nil) then txt = jres:selectDeviceFlag(selectDeviceFlag, devAddr, switchONF, slideLevel, slideTemp, slideColor) end
	--保存房间数据
	if (saveRoomDateFlag ~= nil) then 
		if (addRoomName ~= nil) then
			addRoomName = decodeURI(addRoomName)
		end
		if (roomOrgName ~= nil) then
			roomOrgName = decodeURI(roomOrgName)
		end

		txt = jres:saveRoomDateFlag(saveRoomDateFlag, addRoomName, addRoomIcon, devList, roomOrgName) 
	end	
	if (addRoomNameCheck ~= nil) then 
		addRoomNameCheck = decodeURI(addRoomNameCheck)
		txt = jres:addRoomNameCheck(addRoomNameCheck) 
	end	

	-- 保存遥控器数�?
	if (devAddr ~= nil) then
		txt = "AD:"..devAddr
		groupList = {CTL1, CTL2, CTL3, CTL4, CTL5, CTL6}

		for i=1,6
			do

			RoomList = {}
			if (groupList[i] ~= nil) then
				string.gsub(groupList[i], '[^,]+', function(w) table.insert(RoomList, w) end )   
		  
				txt = txt.." G"..i..":"
				for i,v in ipairs(RoomList)
					do txt = txt.." "..v
				end
			end
		end


	end

	-------------------------    room child page comment     ---------------------------------
	if (loadRoomChild ~= nil) then txt = jres:loadRoomChild(loadRoomChild) end

	-------------------------     scene list comment     ----------------------------------------------
	if (loadScene ~= nil) then txt = jres:loadScene() end

	------------------------       scene adjust  comment    ------------------------------------------------
	-- txt = decodeURI(loadModeAdjust)    -- 需要解�?	if (loadModeAdjust ~= nil) then txt = jres:loadModeAdjust(loadModeAdjust) end

	------------------------    add scene comment    ------------------------------------------------------
	if (loadAddScene ~= nil) then txt = jres:loadAddScene() end

	----------------------     setting device list page   --------------------------------
	if (loadDeviceList ~= nil) then txt = jres:loadDeviceList() end

	-----------------------     setting open net page   --------------------------------------
	if (ctlNetStatus ~= nil) then txt = jres:ctlNetStatus(ctlNetStatus) end
	if (newDeviceList ~= nil) then txt = jres:newDeviceList() end

	---------------------    setting room list page     ---------------------------
	if (settingRoomList ~= nil) then txt = jres:settingRoomList() end

	---------------------    load  addroom page     ---------------------------
	if (loadAddRoom ~= nil or loadRoomAdjust ~= nil) then txt = jres:loadAddRoom(loadRoomAdjust) end


	---------------------    load accessories page     ------------------------------
	 -- {"DEV":[
	 --   {"AD":"0x1234", "TY":71, "NA":"High-endControll", "SA":1} ,
	 --   {"AD":"0x5678", "TY":72, "NA":"RGBWControll", "SA":0} ,
	 --   {"AD":"0x1122", "TY":73, "NA":"CCTControll", "SA":0}
	 -- ]}

	 if (loadAccessories ~= nil) then
	 	txt = ""
	 	txt = sta.."DEV".."\":["
	 	txt = txt..sta.."AD"..mop.."0x1234"..dop.."TY"..nmop.."71"..ndop.."NA"..mop.."High-endControll"..dop.."SA"..nmop.."1"..nen
	 	txt = txt..","..sta.."AD"..mop.."0x5678"..dop.."TY"..nmop.."72"..ndop.."NA"..mop.."RGBControll"..dop.."SA"..nmop.."0"..nen
	 	txt = txt..","..sta.."AD"..mop.."0x1122"..dop.."TY"..nmop.."73"..ndop.."NA"..mop.."CCTControll"..dop.."SA"..nmop.."0"..nen
	 	txt = txt.."]}"
	 end

	 ---------------------      load accessories page   ------------------------------
	--  {"RM":[
	--     {"NA":"Hall", "GN":1, "IC":2},
	--     {"NA":"Bigroom", "GN":2, "IC":3},
	--     {"NA":"Childroom","GN":3, "IC":1}
	--     ] ,
	--   "SGN":[
	--     {"BN":"0x1234"�?RL":[1�?]},
	--     {"BN":"0x2345", "RL":[1]},
	--     {"BN":"0x4576", "RL":[2]}
	--   ]
	-- }
    
    if (loadControll ~= nil) then
    		txt = ""
	    	txt = sta.."RM\":["
	    	txt = txt..sta.."NA"..mop.."Hall"..dop.."GN"..nmop.."1"..ndop.."IC"..nmop.."2"..nen
	    	txt = txt..","..sta.."NA"..mop.."Bigroom"..dop.."GN"..nmop.."2"..ndop.."IC"..nmop.."3"..nen
	    	txt = txt..","..sta.."NA"..mop.."Childroom"..dop.."GN"..nmop.."3"..ndop.."IC"..nmop.."1"..nen
	    	txt = txt.."],"

    	if (loadControll == "0x1234") then         --  这里仅做一个实例，实际需根据该设备是什么类型返回响应组�?	    	txt = txt.."\"SGN\":["
	    	txt = txt..sta.."BN"..mop.."0x1234"..dop.."RL".."\":[".."1"..",".."2".."]}"
	    	txt = txt..","..sta.."BN"..mop.."0x5678"..dop.."RL".."\":[".."1".."]}"
	    	txt = txt..","..sta.."BN"..mop.."0x1122"..dop.."RL".."\":[".."2".."]}"
	    	txt = txt..","..sta.."BN"..mop.."0x2222"..dop.."RL".."\":[".."3".."]}"
	    	txt = txt..","..sta.."BN"..mop.."0x3333"..dop.."RL".."\":[".."2"..",".."3".."]}"
	    	txt = txt..","..sta.."BN"..mop.."0x4444"..dop.."RL".."\":[".."1"..",".."2"..",".."3".."]}"
	    	txt = txt.."]}"
    	else 
	    	txt = txt.."\"SGN\":["
	    	txt = txt..sta.."BN"..mop.."0x1234"..dop.."RL".."\":[".."1"..",".."2".."]}"
	    	txt = txt..","..sta.."BN"..mop.."0x5678"..dop.."RL".."\":[".."1".."]}"
	    	txt = txt..","..sta.."BN"..mop.."0x1122"..dop.."RL".."\":[".."2".."]}"
	    	txt = txt.."]}"
        end
    end

      --------------------     load device sofe update page    -----------------------
    --   {"UDEV":[
		  --    {"NA":"CCTLight", "AD":"0x1111", "ORG":"1.1.1", "NORG":"1.1.2"} ,
		  --    {"NA":"RGBLight", "AD":"0x2222", "ORG":"1.2.1", "NORG":"1.2.5"} ,
		  --    {"NA":"MyDimLight", "AD":"0x3333", "ORG":"1.3.2", "NORG":"1.3.3"}
		  -- ]�?		  -- "CDEV":60
	   -- }

	   if (loadUpdateDev ~= nil) then
	   		txt = ""
	   		txt = sta.."UDEV\":["
	   		txt = txt..sta.."NA"..mop.."CCTLight"..dop.."AD"..mop.."0x1111"..dop.."ORG"..mop.."1.1.1"..dop.."NORG"..mop.."1.1.2"..en
	   		txt = txt..","..sta.."NA"..mop.."RGBLight"..dop.."AD"..mop.."0x2222"..dop.."ORG"..mop.."1.3.1"..dop.."NORG"..mop.."1.3.5"..en
	   		txt = txt..","..sta.."NA"..mop.."MyDimLight"..dop.."AD"..mop.."0x3333"..dop.."ORG"..mop.."1.5.1"..dop.."NORG"..mop.."1.5.2"..en
	   		txt = txt..","..sta.."NA"..mop.."Gateway1"..dop.."AD"..mop.."0x4444"..dop.."ORG"..mop.."1.4.1"..dop.."NORG"..mop.."1.4.5"..en
	   		txt = txt..","..sta.."NA"..mop.."HdControll"..dop.."AD"..mop.."0x5555"..dop.."ORG"..mop.."2.1.1"..dop.."NORG"..mop.."2.1.2"..en
	   		txt = txt.."],"
	   		txt = txt.."\"CDEV\":".."60"
	   		txt = txt.."}"
	   end

	snd2client(txt)
end

function decodeURI(s)
    s = string.gsub(s, '%%(%x%x)', function(h) return string.char(tonumber(h, 16)) end)
    return s
end