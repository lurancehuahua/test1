-- Copyright 2017-11-14 N Lottie

local require = require

local rs232 = require "luars232"
local math = require("math")
local string = require("string")

module ("luci.model.serial", package.seeall)

local serialPort = "/dev/ttyS1"

local WRITE_TIMEOUT = 200

local S_CMD_HEADER = '\255\204'

local S_NET_START = S_CMD_HEADER..'\201'
local S_NET_PERMITJOIN = S_CMD_HEADER..'\202'
local S_NET_RESET = S_CMD_HEADER..'\203'
local S_NET_ERASEPD = S_CMD_HEADER..'\204'
local S_ALL_ONOFF = S_CMD_HEADER..'\205'

-- use broadcast addr
local S_GROUP_ADD = S_CMD_HEADER..'\210'
local S_GROUP_ONOFF = S_CMD_HEADER..'\211'
local S_GROUP_LUM = S_CMD_HEADER..'\212'
local S_GROUP_CCT = S_CMD_HEADER..'\213'
local S_GROUP_COLOR = S_CMD_HEADER..'\214'
-- use group addr
local S_GROUP_ADDX = S_CMD_HEADER..'\215'
local S_GROUP_REMOVE = S_CMD_HEADER..'\216'

local S_DEV_ONOFF = S_CMD_HEADER..'\220'
local S_DEV_LUM = S_CMD_HEADER..'\221'
local S_DEV_CCT = S_CMD_HEADER..'\222'
local S_DEV_COLOR = S_CMD_HEADER..'\223'
local S_DEV_ADDGROUP = S_CMD_HEADER..'\224'
local S_DEV_IDENTIFY = S_CMD_HEADER..'\225'
local S_DEV_REMOVEGROUP = S_CMD_HEADER..'\226'
local S_DEV_LEAVENET = S_CMD_HEADER..'\227'

function _dbg(...)
	-- print(...)
end

function _u16tobyte(u16n)
	local hbyte = math.floor((u16n/256)%256)
	local lbyte = math.mod(u16n, 256)
	return hbyte, lbyte
end

function _u64tobyte(u64n)
	local temp, byte1, byte2, byte3, byte4, byte5, byte6, byte7, byte8
	temp = u64n
	byte1 = math.mod(temp, 256)
	temp = math.floor(temp/256)
	byte2 = math.mod(temp, 256)
	temp = math.floor(temp/256)
	byte3 = math.mod(temp, 256)
	temp = math.floor(temp/256)
	byte4 = math.mod(temp, 256)
	temp = math.floor(temp/256)
	byte5 = math.mod(temp, 256)
	temp = math.floor(temp/256)
	byte6 = math.mod(temp, 256)
	temp = math.floor(temp/256)
	byte7 = math.mod(temp, 256)
	temp = math.floor(temp/256)
	byte8 = math.mod(temp, 256)
	return byte8, byte7, byte6, byte5, byte4, byte3, byte2, byte1
end

function _sendcmd(...)
	local e, p = rs232.open(serialPort)
	p:set_baud_rate(rs232.RS232_BAUD_115200)
	p:set_data_bits(rs232.RS232_DATA_8)
	p:set_parity(rs232.RS232_PARITY_NONE)
	p:set_stop_bits(rs232.RS232_STOP_1)
	p:set_flow_control(rs232.RS232_FLOW_OFF)
	p:write(...)
	p:close()
end

function _recvcmd(...)
	local e, p = rs232.open(serialPort)
	p:set_baud_rate(rs232.RS232_BAUD_115200)
	p:set_data_bits(rs232.RS232_DATA_8)
	p:set_parity(rs232.RS232_PARITY_NONE)
	p:set_stop_bits(rs232.RS232_STOP_1)
	p:set_flow_control(rs232.RS232_FLOW_OFF)
	p:read(...)
	p:close()
end

function sendcmd(self, ...)
	_sendcmd(...)
end

function recvcmd(self, ...)
	_recvcmd(...)
end

function t_setsystemtime(self, dt)
	_dbg("set system time: "..dt)
	local e = rs232.set_system_time(dt)
end

-- t_setsystemtime(self, "2018-1-4 11:30:00")

function setdevicetype(self)
	local msg = '\0\35\0\1\255\1'
	_dbg("set device type(0=Coordinator, 1=Router, 2=Legacy Router)")
	_sendcmd(msg, WRITE_TIMEOUT)
end

function startnet(self)
	_dbg("start network")
	_sendcmd(S_NET_START, WRITE_TIMEOUT)
end

function permitjoin(self, seconds)
	_dbg("open network "..seconds.."s")
	_sendcmd(S_NET_PERMITJOIN..string.char(seconds), WRITE_TIMEOUT)
end

function resetnet(self)
	_dbg("reset network")
	_sendcmd(S_NET_RESET, WRITE_TIMEOUT)
end

function erasepd(self)
	_dbg("erase PD")
	_sendcmd(S_NET_ERASEPD, WRITE_TIMEOUT)
end

function setonoff(self, onoff)
	-- local msg = S_ALL_ONOFF..string.char(onoff)
	local msg = '\0\146\0\6\255\4\255\255\1\255'..string.char(onoff)
	_dbg("switch is(0:OFF, 1:ON): "..onoff)
	_sendcmd(msg, WRITE_TIMEOUT)
end

function setlum(self, lum)
	local msg = '\0\129\0\9\255\4\255\255\1\255\0'..string.char(lum)..'\0\5'
	_dbg("change global lum is : "..lum)
	_sendcmd(msg, WRITE_TIMEOUT)
end

function setcct(self, cct)
	local hcct, lccd = _u16tobyte(371 - cct)
	local msg = '\0\192\0\9\255\4\255\255\1\255'..string.char(hcct)..string.char(lccd)..'\0\0'
	_dbg("change global cct is : "..cct)
	_sendcmd(msg, WRITE_TIMEOUT)
end

function sethue(self, hue)
	local hhue, lhue = _u16tobyte(257 * hue)
	local msg = '\0\189\0\10\255\4\255\255\1\255\254'..string.char(hhue)..string.char(lhue)..'\0\0'
	_dbg("change global hue is : "..hue)
	_sendcmd(msg, WRITE_TIMEOUT)
end

function g_setonoff(self, gid, onoff)
	local hgid, lgid = _u16tobyte(gid)
	-- local msg = S_GROUP_ONOFF..string.char(hgid)..string.char(lgid)..string.char(onoff)
	local msg = '\0\146\0\6\255\1'..string.char(hgid)..string.char(lgid)..'\1\255'..string.char(onoff)
	_dbg("change group on-off : "..gid..onoff)
	_sendcmd(msg, WRITE_TIMEOUT)
end


function g_setlum(self, gid, lum)
	local hgid, lgid = _u16tobyte(gid)
	-- local msg = S_GROUP_LUM..string.char(hgid)..string.char(lgid)..string.char(lum)
	local msg = '\0\129\0\9\255\1'..string.char(hgid)..string.char(lgid)..'\1\255\0'..string.char(lum)..'\0\5'
	_dbg("change group lum is : "..gid..lum)
	_sendcmd(msg, WRITE_TIMEOUT)
end

function g_setcct(self, gid, cct)
	local hgid, lgid = _u16tobyte(gid)
	local hcct, lccd = _u16tobyte(371 - cct)
	-- local msg = S_GROUP_CCT..string.char(hgid)..string.char(lgid)..string.char(cct)
	local msg = '\0\192\0\9\255\1'..string.char(hgid)..string.char(lgid)..'\1\255'..string.char(hcct)..string.char(lccd)..'\0\0'
	_dbg("change group cct is : "..gid..cct)
	_sendcmd(msg, WRITE_TIMEOUT)
end

function g_sethue(self, gid, hue)
	local hgid, lgid = _u16tobyte(gid)
	local hhue, lhue = _u16tobyte(257 * hue)
	-- local msg = S_GROUP_COLOR..string.char(hgid)..string.char(lgid)..string.char(hue)
	local msg = '\0\189\0\10\255\1'..string.char(hgid)..string.char(lgid)..'\1\255\254'..string.char(hhue)..string.char(lhue)..'\0\0'
	_dbg("change group hue is : "..gid..hue)
	_sendcmd(msg, WRITE_TIMEOUT)
end

function g_addgroup(self, gid)
	local hgid, lgid = _u16tobyte(gid)
	-- local msg = S_GROUP_ADD..string.char(hgid)..string.char(lgid)
	local msg = '\0\96\0\7\255\4\255\255\1\255'..string.char(hgid)..string.char(lgid)
	_dbg("add to group "..gid)
	_sendcmd(msg, WRITE_TIMEOUT)
end

-- for remote control group remove
function g_removegroup(self, gid)
	local hgid, lgid = _u16tobyte(gid)
	-- local msg = S_GROUP_REMOVE..string.char(hgid)..string.char(lgid)
	local msg = '\0\99\0\7\255\4\255\255\1\255'..string.char(hgid)..string.char(lgid)
	_dbg("remove from group "..gid)
	_sendcmd(msg, WRITE_TIMEOUT)
end

-- for remote control group add
function g_addgroupx(self, gid, ngid)
	local hgid, lgid = _u16tobyte(gid)
	local hngid, lngid = _u16tobyte(ngid)
	-- local msg = S_GROUP_ADDX..string.char(hgid)..string.char(lgid)..string.char(hngid)..string.char(lngid)
	local msg = '\0\96\0\7\255\1'..string.char(hgid)..string.char(lgid)..'\1\255'..string.char(hngid)..string.char(lngid)
	_dbg("add group "..gid.." to another group "..ngid)
	_sendcmd(msg, WRITE_TIMEOUT)
end

function d_setonoff(self, addr, onoff)
	local haddr, laddr = _u16tobyte(addr)
	-- local msg = S_DEV_ONOFF..string.char(haddr)..string.char(laddr)..string.char(onoff)
	local msg = '\0\146\0\6\255\2'..string.char(haddr)..string.char(laddr)..'\1\255'..string.char(onoff)
	_dbg("change device onoff is : "..addr..onoff)
	_sendcmd(msg, WRITE_TIMEOUT)
end

-- lum={1..255}
function d_setlum(self, addr, lum)
	local haddr, laddr = _u16tobyte(addr)
	-- local msg = S_DEV_LUM..string.char(haddr)..string.char(laddr)..string.char(lum)
	local msg = '\0\129\0\9\255\2'..string.char(haddr)..string.char(laddr)..'\1\255\0'..string.char(lum)..'\0\5'
	_dbg("change device lum is : "..addr..lum)
	_sendcmd(msg, WRITE_TIMEOUT)
end

function d_setcct(self, addr, cct)
	local haddr, laddr = _u16tobyte(addr)
	local hcct, lccd = _u16tobyte(371 - cct)
	-- local msg = S_DEV_CCT..string.char(haddr)..string.char(laddr) .. string.char(cct)
	local msg = '\0\192\0\9\255\2'..string.char(haddr)..string.char(laddr)..'\1\255'..string.char(hcct)..string.char(lccd)..'\0\0'
	_dbg("change device cct is : "..addr..cct)
	_sendcmd(msg, WRITE_TIMEOUT)
end

-- hue_id={1..255}->{1..65535}
function d_sethue(self, addr, hue)
	local haddr, laddr = _u16tobyte(addr)
	local hhue, lhue = _u16tobyte(257 * hue)
	-- local msg = S_DEV_COLOR..string.char(haddr)..string.char(laddr)..string.char(hue)
	local msg = '\0\189\0\10\255\2'..string.char(haddr)..string.char(laddr)..'\1\255\254'..string.char(hhue)..string.char(lhue)..'\0\0'
	_dbg("change device hue is : "..addr..hue)
	_sendcmd(msg, WRITE_TIMEOUT)
end

function d_addgroup(self, addr, gid)
	local haddr, laddr = _u16tobyte(addr)
	local hgid, lgid = _u16tobyte(gid)
	-- local msg = S_DEV_ADDGROUP..string.char(haddr)..string.char(laddr)..string.char(hgid)..string.char(lgid)
	local msg = '\0\96\0\7\255\2'..string.char(haddr)..string.char(laddr)..'\1\255'..string.char(hgid)..string.char(lgid)
	_dbg("add device group is : "..addr..gid)
	_sendcmd(msg, WRITE_TIMEOUT)
end

-- seconds: 1 byte here, although 2 bytes in standart 
function d_setidentify(self, addr, seconds)
	local haddr, laddr = _u16tobyte(addr)
	--local msg = S_DEV_IDENTIFY..string.char(haddr)..string.char(laddr)..string.char(seconds)
	local msg = '\0\112\0\7\255\2'..string.char(haddr)..string.char(laddr)..'\1\255\0'..string.char(seconds)
	_dbg("change device identify is : "..addr..seconds)
	_sendcmd(msg, WRITE_TIMEOUT)
end

function d_removegroup(self, addr, gid)
	local haddr, laddr = _u16tobyte(addr)
	local hgid, lgid = _u16tobyte(gid)
	-- local msg = S_DEV_REMOVEGROUP..string.char(haddr)..string.char(laddr)..string.char(hgid)..string.char(lgid)
	local msg = '\0\99\0\7\255\2'..string.char(haddr)..string.char(laddr)..'\1\255'..string.char(hgid)..string.char(lgid)
	_dbg("remove device group is : "..addr..gid)
	_sendcmd(msg, WRITE_TIMEOUT)
end

function d_leavenet(self, addr, mac)
	local haddr, laddr = _u16tobyte(addr)
	local byte8, byte7, byte6, byte5, byte4, byte3, byte2, byte1 = _u64tobyte(mac)
	local msg = '\0\71\0\12\255'
	msg = msg..string.char(haddr)..string.char(laddr)
	-- msg = msg..string.char(byte8)..string.char(byte7)..string.char(byte6)..string.char(byte5)..string.char(byte4)..string.char(byte3)..string.char(byte2)..string.char(byte1)
	msg = msg..'\0\21\141'..string.char(byte5)..string.char(byte4)..string.char(byte3)..string.char(byte2)..string.char(byte1)
	msg = msg..'\0\1'
	_dbg("leave net device is : "..addr.." "..mac)
	local i = 1
	_dbg(string.byte(msg, i).." "..string.byte(msg, i+1).." "..string.byte(msg, i+2).." "..string.byte(msg, i+3).." "..string.byte(msg, i+4))
	i = i + 5
	_dbg(string.byte(msg, i).." "..string.byte(msg, i+1))
	i = i + 2
	_dbg(string.byte(msg, i).." "..string.byte(msg, i+1).." "..string.byte(msg, i+2).." "..string.byte(msg, i+3))
	i = i + 4
	_dbg(string.byte(msg, i).." "..string.byte(msg, i+1).." "..string.byte(msg, i+2).." "..string.byte(msg, i+3))
	i = i + 4
	_dbg(string.byte(msg, i).." "..string.byte(msg, i+1))
	_sendcmd(msg, WRITE_TIMEOUT)
end

function d_resetlifetime(self, addr)
	local haddr, laddr = _u16tobyte(addr)
	local msg = '\10\5\0\11\255'..string.char(haddr)..string.char(laddr)..'\0\0\0\1\1\0\0\0\0'
	_dbg("read device lifetime : "..addr)
	_sendcmd(msg, WRITE_TIMEOUT)
end

function d_resetenergy(self, addr)
	local haddr, laddr = _u16tobyte(addr)
	local msg = '\10\6\0\11\255'..string.char(haddr)..string.char(laddr)..'\0\0\0\1\1\0\0\0\0\0\0\0\0'
	_dbg("read device lifetime : "..addr)
	_sendcmd(msg, WRITE_TIMEOUT)
end

function d_requestattribute(self, addr)
	local haddr, laddr = _u16tobyte(addr)
	local msg = '\1\0\0\14\255\2'..string.char(haddr)..string.char(laddr)..'\1\1\11\4\0\0\0\0\1\5\11'
	-- local msg = '\1\0\0\14\255\2'..string.char(haddr)..string.char(laddr)..'\1\1\0\8\0\0\0\0\1\0\0'
	_dbg("requestattribute device addr is : "..addr)
	_sendcmd(msg, WRITE_TIMEOUT)
end

-- hue={0..254}
function testrgbw_sethue(self, hue)
	local msg = '\0\176\0\9\255\4\255\255\1\255'..string.char(hue)..'\0\0\0'
	_dbg("change global hue(rgbw test) is : "..hue)
	_sendcmd(msg, WRITE_TIMEOUT)
end

-- saturation={0..254}
function testrgbw_setsaturation(self, saturation)
	local msg = '\0\179\0\8\255\4\255\255\1\255'..string.char(saturation)..'\0\0'
	_dbg("change global saturation(rgbw test) is : "..saturation)
	_sendcmd(msg, WRITE_TIMEOUT)
end

-- colortemp={0..254}
function testrgbw_setcolortemp(self, colortemp)
	local msg = '\0\192\0\9\255\4\255\255\1\255\0'..string.char(colortemp)..'\0\0'
	_dbg("change global colortemp(rgbw test) is : "..colortemp)
	_sendcmd(msg, WRITE_TIMEOUT)
end

-- color={0..254}
function testrgbw_setcolor(self, color)
	local msg = '\0\183\0\11\255\4\255\255\1\255\0'..string.char(color)..'\0\0\0\0'
	_dbg("change global color(rgbw test) is : "..color)
	_sendcmd(msg, WRITE_TIMEOUT)
end