-- Copyright 2008 Steven Barth <steven@midlink.org>
-- Copyright 2011-2015 Jo-Philipp Wich <jow@openwrt.org>
-- Licensed to the public under the Apache License 2.0.
module("luci.controller.admin.zigbee", package.seeall)

function index()
	local fs = require "nixio.fs"

	entry({"admin", "zigbee"}, alias("admin", "zigbee", "room"), _("ZBweb"), 30).index = true

	entry({"admin", "zigbee", "room"}, template("admin_zigbee/room"), _("room"), 1)
	entry({"admin", "zigbee", "room_a"}, template("admin_zigbee/room_a"),nil)
	entry({"admin", "zigbee", "room", "jsonresponse"}, call("jsonresponse"), nil)

	-- scene label page --
	entry({"admin", "zigbee", "scene"}, template("admin_zigbee/scene"),nil)
	entry({"admin", "zigbee", "scene_modesetting"}, template("admin_zigbee/scene_modesetting"),nil)
	entry({"admin", "zigbee", "scene_objmodelist"}, template("admin_zigbee/scene_objmodelist"),nil)
	entry({"admin", "zigbee", "scene_objmodeadjust"}, template("admin_zigbee/scene_objmodeadjust"),nil)
	entry({"admin", "zigbee", "scene_objaddmode"}, template("admin_zigbee/scene_objaddmode"),nil)
	entry({"admin", "zigbee", "scene_schedule"}, template("admin_zigbee/scene_schedule"),nil)
	entry({"admin", "zigbee", "scene_adjustschedule"}, template("admin_zigbee/scene_adjustschedule"),nil)

	-- analyze label page --
	entry({"admin", "zigbee", "analyze"}, template("admin_zigbee/analyze"), nil)
	entry({"admin", "zigbee", "analysis_electricity"}, template("admin_zigbee/analysis_electricity"), nil)
	entry({"admin", "zigbee", "analysis_baddevice"}, template("admin_zigbee/analysis_baddevice"), nil)
	entry({"admin", "zigbee", "analysis_usedtime"}, template("admin_zigbee/analysis_usedtime"), nil)
	
	-- setting child : device setting --
	entry({"admin", "zigbee", "setting"}, template("admin_zigbee/setting"), nil)
	entry({"admin", "zigbee", "setting_gatewaylist"}, template("admin_zigbee/setting_gatewaylist"), nil)
	entry({"admin", "zigbee", "setting_addgateway"}, template("admin_zigbee/setting_addgateway"), nil)
	entry({"admin", "zigbee", "setting_devicelist"}, template("admin_zigbee/setting_devicelist"), nil)
	entry({"admin", "zigbee", "setting_adddevice"}, template("admin_zigbee/setting_adddevice"), nil)

	-- setting child: group setting --
	entry({"admin", "zigbee", "setting_grouplist"}, template("admin_zigbee/setting_grouplist"), nil)
	entry({"admin", "zigbee", "setting_addgroup"}, template("admin_zigbee/setting_addgroup"), nil)
	entry({"admin", "zigbee", "setting_objgroup"}, template("admin_zigbee/setting_objgroup"), nil)

	-- setting child: room setting
	entry({"admin", "zigbee", "setting_roomlist"}, template("admin_zigbee/setting_roomlist"), nil)
	entry({"admin", "zigbee", "setting_addroom"}, template("admin_zigbee/setting_addroom"), nil)
	entry({"admin", "zigbee", "setting_objroom"}, template("admin_zigbee/setting_objroom"), nil)

	-- setting child: room accessories
	entry({"admin", "zigbee", "setting_accessories"}, template("admin_zigbee/setting_accessories"), nil)
	entry({"admin", "zigbee", "setting_controll"}, template("admin_zigbee/setting_controll"), nil)

	-- setting child: room device update
	entry({"admin", "zigbee", "setting_deviceupdate"}, template("admin_zigbee/setting_deviceupdate"), nil)

	-- setting child: room about
	entry({"admin", "zigbee", "setting_about"}, template("admin_zigbee/setting_about"), nil)
	entry({"admin", "zigbee", "setting_aboutfunction"}, template("admin_zigbee/setting_aboutfunction"), nil)
	entry({"admin", "zigbee", "setting_aboutcopyright"}, template("admin_zigbee/setting_aboutcopyright"), nil)
	entry({"admin", "zigbee", "setting_aboutupdate"}, template("admin_zigbee/setting_aboutupdate"), nil)


	entry({"admin", "zigbee", "setting", "setjump"}, call("setjump"), nil)
	entry({"admin", "zigbee", "setting", "devctlone"}, template("admin_zigbee/devctlone"), nil)
end


function snd2client(...)
	print("Content-Type: text/plain\n")
	print(...)
end

function jsonresponse()
	local http = require "luci.http"
	local backend = require "luci.model.backend"
	 

	-- response JSON Date
	txt = nil

    	----------------------    load room page message       -----------------------------
	local loadRoom = tonumber(http.formvalue("loadRoom"))
	if (loadRoom ~= nil) then
		txt = backend:loadRoom()
	end

	-------------------------    response to client message     -----------------------------------
	local allRoom = tonumber(http.formvalue("allRoom"))

	local groupNum = tonumber(http.formvalue("groupNum"))
	local roomSwitch = tonumber(http.formvalue("roomSwitch"))
	local roomLight = tonumber(http.formvalue("roomLight"))
	local roomModeName = http.formvalue("roomModeName")

	local deviceAddress = http.formvalue("deviceAddress")
	local deviceSwitch = tonumber(http.formvalue("deviceSwitch"))

	local slideLevel = tonumber(http.formvalue("slideLevel"))
	local slideTemp = tonumber(http.formvalue("slideTemp"))
	local slideColor = tonumber(http.formvalue("slideColor"))

	local groupNumList = http.formvalue("groupNumList")
	local sceneSwitch = tonumber(http.formvalue("sceneSwitch"))
	local sceneGroupNum = tonumber(http.formvalue("sceneGroupNum"))
	local addSceneName = http.formvalue("addSceneName")
	local addSceneSave = tonumber(http.formvalue("addSceneSave"))

	if (allRoom ~= nil) then
		-- txt = "allRoom:"..allRoom
		txt = backend:loadRoom()
	end

	if (groupNum ~= nil) then                     -- room page
		txt = "groupNum:"..groupNum

		if (roomSwitch ~= nil) then
			txt = backend:roomSwitch(groupNum, roomSwitch)
			-- txt = txt.."roomSwitch:"..roomSwitch
		elseif (slideLevel ~= nil) then
			txt = backend:roomLevel(groupNum, slideLevel)
			-- txt = txt.."slideLevel:"..slideLevel
		elseif (roomModeName ~= nil) then
			-- txt = txt.."roomModeName:"..roomModeName
			txt = backend:roomModeName(groupNum, roomModeName)
		end
	elseif (deviceAddress ~= nil) then            -- room_a page
		txt = "deviceAddress:"..deviceAddress

		if (deviceSwitch ~= nil) then
			-- txt = txt.."deviceSwitch:"..deviceSwitch
			txt = backend:deviceSwitch(deviceAddress, deviceSwitch)
		elseif (slideLevel ~= nil) then
			-- txt = txt.."slideLevel:"..slideLevel
			txt = backend:deviceLevel(deviceAddress, slideLevel)
		elseif (slideTemp ~= nil) then
			-- txt = txt.."slideTemp:"..slideTemp
			txt = backend:deviceTemp(deviceAddress, slideTemp)
		elseif (slideColor ~= nil) then
			-- txt = txt.."slideColor:"..slideColor
			txt = backend:deviceColor(deviceAddress, slideColor)
		end
	elseif (sceneSwitch ~= nil or slideColor ~= nil) then    -- add scene page
		txt = backend:addSceneSave(addSceneSave, sceneGroupNum, addSceneName, sceneSwitch, slideLevel, slideTemp, slideColor)
	end

	-------------------------    room child page comment     ---------------------------------
	local loadRoomChild = tonumber(http.formvalue("loadRoomChild"))
	if (loadRoomChild ~= nil) then
		txt = backend:loadRoomChild()	
	end

	-------------------------     scene list comment     ----------------------------------------------
	local loadScene = tonumber(http.formvalue("loadScene"))
	if (loadScene ~= nil) then
		txt = backend:loadScene()
	end

	------------------------    add scene comment    ------------------------------------------------------
	local loadAddScene = tonumber(http.formvalue("loadAddScene"))
	if (loadAddScene ~= nil) then
		txt = backend:loadAddScene()
	end

	-------------------      以字符串的形式返回到 client端     -------------------------
	snd2client(txt)
end

function setjump()
	local http = require "luci.http"
	local backend  = require "luci.model.backend"

	local fv = tonumber(http.formvalue("openNet")) 
	local devAddr = http.formvalue("devAddr")
	local slideLevel = tonumber(http.formvalue("slideLevel")) 
	local slideTemp = tonumber(http.formvalue("slideTemp"))
	local slideColor = tonumber(http.formvalue("slideColor"))
	local switchONF= tonumber(http.formvalue("switchONF"))
	local addGroup= tonumber(http.formvalue("addGroup"))
	local startNet= tonumber(http.formvalue("startNet"))

	if (fv ~= nil) then txt = backend:permitJohn() end
	if (slideLevel ~= nil) then txt = backend:slideLevel(888, slideLevel) end
	if (slideTemp ~= nil) then txt = backend:slideTemp(888, slideTemp) end
	if (slideColor ~= nil) then txt = backend:slideColor(888, slideColor) end
	if (switchONF ~= nil) then txt = backend:switchONF(888, slideColor) end
	if (addGroup ~= nil) then txt = backend:addGroup(888) end
	if (startNet ~= nil) then txt = backend:startNet() end

	snd2client(txt)
end
