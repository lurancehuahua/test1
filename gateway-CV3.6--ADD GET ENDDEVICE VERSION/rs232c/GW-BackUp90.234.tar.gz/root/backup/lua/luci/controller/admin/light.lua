-- Copyright 2008 Steven Barth <steven@midlink.org>
-- Copyright 2011-2015 Jo-Philipp Wich <jow@openwrt.org>
-- Licensed to the public under the Apache License 2.0.

module("luci.controller.admin.light", package.seeall)

function index()
	entry({"admin", "light"}, alias("admin", "light", "lightMose"), _("Light"), 30).index = true
	entry({"admin", "light", "lightMose"}, template("admin_light/lightMose"), _("LightMose"), 1)
	entry({"admin", "light", "lightMose", "lightFun"}, call("action_lightFun"),nil)
end

function snd2client(...)
	print("Content-Type: text/plain\n")
	print(...)
end

function action_lightFun()
	local http = require "luci.http"
	--local serial  = require "luci.model.serial"
	--local db = require "luci.model.db"
	local backend = require "luci.model.backend"
	local fv = tonumber(http.formvalue("para"))
	txt = backend:loadRoom()
	snd2client(txt)
	http.redirect(luci.dispatcher.build_url('admin/light/lightMose'))
end
