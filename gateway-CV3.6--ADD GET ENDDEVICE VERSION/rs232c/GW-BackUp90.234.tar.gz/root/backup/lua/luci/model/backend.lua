-- Copyright 2017-11-14 N Lottie


--local require = require

local nxo = require "nixio"
local nfs = require "nixio.fs"
local sys = require "luci.sys"
local utl = require "luci.util"
local dsp = require "luci.dispatcher"
local uci = require "luci.model.uci"
local lng = require "luci.i18n"
local jsc = require "luci.jsonc"

local db = require "luci.model.db"
local serial  = require "luci.model.serial"
local math = require("math")
local string = require("string")


module "luci.model.backend"

function _dbg(...)
    --print(...)
end

function _u16tobyte(u16n)
	local hbyte = math.floor((u16n/256)%256)
	local lbyte = math.mod(u16n, 256)
	return hbyte, lbyte
end


local S_CMD_HEADER = '\255\204'

local S_NET_START = S_CMD_HEADER .. '\201'
local S_NET_PERMITJOIN = S_CMD_HEADER .. '\202\10'
local S_NET_RESET = S_CMD_HEADER .. '\203'
local S_NET_ERASEPD = S_CMD_HEADER .. '\204'
local S_ALL_ONOFF = S_CMD_HEADER .. '\205'

local S_GROUP_ADD = S_CMD_HEADER .. '\210'
local S_GROUP_ONOFF = S_CMD_HEADER .. '\211'
local S_GROUP_LUM = S_CMD_HEADER .. '\212'
local S_GROUP_CCT = S_CMD_HEADER .. '\213'
local S_GROUP_COLOR = S_CMD_HEADER .. '\214'

local S_DEV_ONOFF = S_CMD_HEADER .. '\220'
local S_DEV_LUM = S_CMD_HEADER .. '\221'
local S_DEV_CCT = S_CMD_HEADER .. '\222'
local S_DEV_COLOR = S_CMD_HEADER .. '\223'

local sta = "{\""
local en = "\"}"
local nen = "}"
local mop = "\":\""
local dop = "\",\""
local nmop = "\":"
local ndop = ",\""


function startNet(self)
	local txt
	serial:sendcmd(S_NET_START, 200)
	_dbg("start network")
	txt = "start network"
	return txt
end

function permitJohn(self)
	local txt
	-- open network 10s
	serial:sendcmd(S_NET_PERMITJOIN, 200)
	_dbg("open network 10s")
	txt = "open network 10s"
	return txt
end

function resetNet(self)
	local txt
	serial:sendcmd(S_NET_RESET, 200)
	_dbg("reset network")
	txt = "reset network"
	return txt
end

function erasePD(self)
	local txt
	serial:sendcmd(S_NET_ERASEPD, 200)
	_dbg("erase PD")
	txt = "erase PD"
	return txt
end

function slideLevel(self, gid, level)
	local txt
	local hgid, lgid = _u16tobyte(gid)
	local msg = S_GROUP_LUM .. string.char(hgid) .. string.char(lgid) .. string.char(level)
	serial:sendcmd(msg, 200)
	_dbg("change light level is : " .. gid .. level)
	txt = "change light level is : " .. gid .. level
	return txt
end

function slideTemp(self, gid, temp)
	local txt
	local hgid, lgid = _u16tobyte(gid)
	local msg = S_GROUP_CCT .. string.char(hgid) .. string.char(lgid) .. string.char(temp)
	serial:sendcmd(msg, 200)
	_dbg("change light temp is : " .. gid .. temp)
	txt = "change light temp is : " .. gid .. temp
	return txt
end

function slideColor(self, gid, color)
	local txt
	local hgid, lgid = _u16tobyte(gid)
	local msg = S_GROUP_COLOR .. string.char(hgid) .. string.char(lgid) .. string.char(color)
	serial:sendcmd(msg, 200)
	_dbg("change light temp is : " .. gid .. color)
	txt = "change light temp is : " .. gid .. color
	return txt
end

function switchONF(self, onoff)
	local txt
	local msg = S_ALL_ONOFF .. string.char(onoff)
	serial:sendcmd(msg, 200)
	_dbg("switch is(0:OFF, 1:ON): " .. onoff)
	txt = "switch is(0:OFF, 1:ON): " .. onoff
	return txt
end

function addGroup(self, gid)
	local txt
	local hgid, lgid = _u16tobyte(gid)
	local msg = S_GROUP_ADD .. string.char(hgid) .. string.char(lgid)
	serial:sendcmd(msg, 200)
	_dbg("add group " .. gid)
	txt = "add group " .. gid
	return txt
end

function loadRoom(self)
	local txt
	txt = sta.."roomMsg".."\":["
	txt = txt..sta.."GN"..nmop.."1"..ndop.."IC"..nmop.."1"..ndop.."NA"..mop.."Bigroom"..dop.."MO"..mop.."sleeping"..dop.."SW"..nmop.."1"..ndop.."LE"..nmop.."100"..nen

	txt = txt..","..sta.."GN"..nmop.."2"..ndop.."IC"..nmop.."2"..ndop.."NA"..mop.."Childroom"..dop.."MO"..mop.."Reading"..dop.."SW"..nmop.."1"..ndop.."LE"..nmop.."150"..nen
	txt = txt..","..sta.."GN"..nmop.."3"..ndop.."IC"..nmop.."3"..ndop.."NA"..mop.."Guestroom"..dop.."MO"..mop.."sleeping"..dop.."SW"..nmop.."0"..ndop.."LE"..nmop.."200"..nen
	txt = txt..","..sta.."GN"..nmop.."4"..ndop.."IC"..nmop.."5"..ndop.."NA"..mop.."Hall"..dop.."MO"..mop.."Party"..dop.."SW"..nmop.."0"..ndop.."LE"..nmop.."50"..nen
	txt = txt..","..sta.."GN"..nmop.."5"..ndop.."IC"..nmop.."1"..ndop.."NA"..mop.."Kitchen"..dop.."MO"..mop.."Cooking"..dop.."SW"..nmop.."0"..ndop.."LE"..nmop.."180"..nen
	txt = txt..","..sta.."GN"..nmop.."6"..ndop.."IC"..nmop.."4"..ndop.."NA"..mop.."Toilet"..dop.."MO"..mop.."Washing"..dop.."SW"..nmop.."0"..ndop.."LE"..nmop.."230"..nen
	txt = txt..","..sta.."GN"..nmop.."7"..ndop.."IC"..nmop.."1"..ndop.."NA"..mop.."Balcony"..dop.."MO"..mop.."Lowlight"..dop.."SW"..nmop.."0"..ndop.."LE"..nmop.."30"..nen

	txt = txt.."]}"

	return txt
end


function allRoom(self, onoff)
	local txt, msg

	msg = S_ALL_ONOFF .. string.char(onoff) 
	serial:sendcmd(msg, 200)

	db:groups_setonoffall(onoff, 0)
	db:devices_setonoffall(onoff, 0)

	txt = "allRoom:"..onoff
	return txt
end

function roomSwitch(self, gid, onoff)
	local txt, msg
	local hgid, lgid = _u16tobyte(gid)

	msg = S_GROUP_ONOFF .. string.char(hgid) .. string.char(lgid) .. string.char(onoff)
	serial:sendcmd(msg, 200)

	db:groups_setonoff(gid, onoff, 0)

	txt = "groupNum:"..gid.."roomSwitch:"..onoff
	return txt
end

function roomLevel(self, gid, level)
	local txt, msg
	local hgid, lgid = _u16tobyte(gid)

	msg = S_GROUP_LUM .. string.char(hgid) .. string.char(lgid) .. string.char(level)
	serial:sendcmd(msg, 200)

	db:groups_setlum(gid, level, 0)

	txt = "groupNum:"..gid.."slideLevel:"..level
	return txt
end

function roomModeName(self, gid, modeName)
	local txt, msg

	--msg = '\255\204\230' .. string.char(gid) .. string.char(modeName)
	--serial:sendcmd(msg, 200)

	--db

	txt = "groupNum:"..gid.."roomModeName:"..modeName
	return txt
end

function deviceSwitch(self, addr, onoff)
	local txt, msg
	local hdddr, laddr = _u16tobyte(addr)

	msg = S_DEV_ONOFF .. string.char(hdddr) .. string.char(laddr) .. string.char(onoff)
	serial:sendcmd(msg, 200)

    txt = "deviceAddress:"..addr.."deviceSwitch:"..onoff
    return txt
end

function deviceLevel(self, addr, level)
	local txt, msg
	local hdddr, laddr = _u16tobyte(addr)

	msg = S_DEV_LUM .. string.char(hdddr) .. string.char(laddr) .. string.char(level)
	serial:sendcmd(msg, 200)

    txt = "deviceAddress:"..addr.."deviceSwitch:"..level
    return txt
end

function deviceTemp(self, addr, temp)
	local txt, msg
	local hdddr, laddr = _u16tobyte(addr)

	msg = S_DEV_CCT .. string.char(hdddr) .. string.char(laddr) .. string.char(temp)
	serial:sendcmd(msg, 200)

    txt = "deviceAddress:"..addr.."deviceSwitch:"..temp
    return txt
end

function deviceColor(self, addr, color)
	local txt, msg
	local hdddr, laddr = _u16tobyte(addr)

	msg = S_DEV_COLOR .. string.char(hdddr) .. string.char(laddr) .. string.char(color)
	serial:sendcmd(msg, 200)

    txt = "deviceAddress:"..addr.."deviceSwitch:"..color
    return txt
end

function addSceneSave(self, save, gids, gid, name, onoff, level, temp, color)
	local splitlist = {}
	local txt = ""

	--	addSceneSave 
    if (save ~= nil) then
		txt = txt..save
	end

	-- add scene page select room list number
	if (gids ~= nil) then
		-- ����ַ��� ",2,3,4"  ȡ����','���ַ����� splitlist�У���������ǣ� splitlist = ��"2", "3", "4"��
		string.gsub(gids, '[^,]+', function(w) table.insert(splitlist, w) end )   
		  
		-- ѭ��ȡ�� splitlist �����Ԫ��ֵ
		for i,v in ipairs(splitlist)
			do txt = txt.." "..v
		end

	end

	-- add scene page select room number
	if (gid ~= nil) then
	    txt = txt.."gpNum:"..gid
	end

    -- add scene page save scene name
	if (name ~= nil) then
		txt = txt.."Name:"..name;
	end

	-- add scene switch
	if (onoff ~= nil) then
		txt = txt.." sceneSwitch:"..onoff
	end

	-- add scene three slide value
	if (level ~= nil) then
		txt = txt.."slideLevel:"..level
	end

	if (temp ~= nil) then
		txt = txt.."slideTemp:"..temp
	end

	if (color ~= nil) then
		txt = txt.."slideColor:"..color
	end

	return txt
end

function loadRoomChild()
	-- Nest is JSON response comment :
	-- {"DEVICE":[
	-- {"AD":"0x1234", "TY":3, "NA":"readTable", "SW":1, "LE":200, "TE":180},
	-- {"AD":"0x5678", "TY":4, "NA":"Hallsofe",  "SW":1, "LE":150, "CO":200}],

	-- "MODE":[
	-- {"NA":"reading", "IC":2, "MV":1},
	-- {"NA":"wake up", "IC":1, "MV":0}
	-- ]}

	local txt = nil     --  txt ��λ����
	txt = sta.."DEVICE".."\":["
	txt = txt..sta.."AD"..mop.."0x1234"..dop.."TY"..nmop.."61"..ndop.."NA"..mop.."readTable"..dop.."SW"..nmop.."1"..nen
	txt = txt..","..sta.."AD"..mop.."0x5678"..dop.."TY"..nmop.."62"..ndop.."NA"..mop.."Hallsofe"..dop.."SW"..nmop.."1"..ndop.."LE"..nmop.."150"..nen
	txt = txt..","..sta.."AD"..mop.."0x1111"..dop.."TY"..nmop.."63"..ndop.."NA"..mop.."TV-CCT"..dop.."SW"..nmop.."1"..ndop.."LE"..nmop.."50"..ndop.."TE"..nmop.."30"..nen
	txt = txt..","..sta.."AD"..mop.."0xffff"..dop.."TY"..nmop.."64"..ndop.."NA"..mop.."TV-RGB"..dop.."SW"..nmop.."1"..ndop.."LE"..nmop.."90"..ndop.."CO"..nmop.."130"..nen

	txt = txt.."]," 

	txt = txt.."\"MODE\":["
	txt = txt..sta.."NA"..mop.."reading"..dop.."IC"..nmop.."2"..nen
	txt = txt..","..sta.."NA"..mop.."wakeUp"..dop.."IC"..nmop.."1"..nen
	txt = txt..","..sta.."NA"..mop.."washing"..dop.."IC"..nmop.."3"..nen

	txt = txt.."],"
	txt = txt.."\"CURRENT\":".."\"".."wakeUp".."\"}"

	return txt
end

function loadScene()
	local txt = nil   --txt ��λ����

	txt = sta.."sceneList".."\":["
	--txt = txt..sta.."NA"..mop.."watching movie"..dop.."IC"..nmop.."1"..nen
	txt = txt..sta.."NA"..mop..db:scences_getname(1)..dop.."IC"..nmop.."1"..nen
	-- txt = txt..","..sta.."NA"..mop.."Meet vistor"..dop.."IC"..nmop.."3"..nen
	-- txt = txt..","..sta.."NA"..mop.."Reading book"..dop.."IC"..nmop.."1"..nen
	-- txt = txt..","..sta.."NA"..mop.."Normal"..dop.."IC"..nmop.."5"..nen
	-- txt = txt..","..sta.."NA"..mop.."Cleaning"..dop.."IC"..nmop.."2"..nen
	-- txt = txt..","..sta.."NA"..mop.."Wake up"..dop.."IC"..nmop.."4"..nen
	-- txt = txt..","..sta.."NA"..mop.."KTV"..dop.."IC"..nmop.."2"..nen
	for i=2, 100, 1 do
		name = nil
		name = db:scences_getname(i)
		if name == nil then 
			break
		end
		txt = txt..","..sta.."NA"..mop..name..dop.."IC"..nmop.."3"..nen
	end

	txt = txt.."]}"

	return txt
end

function loadAddScene()
	local txt = nil    
		-- {"addScene":[
		-- {"GN":2, "IC":2, "NA":"Hall"},
		-- {"GN":3, "IC":3, "NA":"Bigroom"},
		-- {"GN":1, "IC":1, "NA":"Childroom"}
		-- ]}
	txt = sta.."addScene\":["
	txt = txt..sta.."GN"..nmop.."2"..ndop.."IC"..nmop.."2"..ndop.."NA"..mop.."Hall"..en
	txt = txt..","..sta.."GN"..nmop.."3"..ndop.."IC"..nmop.."3"..ndop.."NA"..mop.."Bigroom"..en
	txt = txt..","..sta.."GN"..nmop.."1"..ndop.."IC"..nmop.."1"..ndop.."NA"..mop.."Childroom"..en
	txt = txt.."]}"

	return txt
end
