-- Copyright 2017-11-14 N Lottie

local require = require

local nxo = require "nixio"
local nfs = require "nixio.fs"
local sys = require "luci.sys"
local utl = require "luci.util"
local dsp = require "luci.dispatcher"
local uci = require "luci.model.uci"
local lng = require "luci.i18n"
local jsc = require "luci.jsonc"
local rs232 = require "luars232"

module "luci.model.serial"

local serialPort = "/dev/ttyS1"

function sendcmd(self, ...)
	local e, p = rs232.open(serialPort)
	p:set_baud_rate(rs232.RS232_BAUD_115200)
	p:set_data_bits(rs232.RS232_DATA_8)
	p:set_parity(rs232.RS232_PARITY_NONE)
	p:set_stop_bits(rs232.RS232_STOP_1)
	p:set_flow_control(rs232.RS232_FLOW_OFF)
	p:write(...)
	p:close()
end

function recvcmd(self, ...)
	local e, p = rs232.open(serialPort)
	p:set_baud_rate(rs232.RS232_BAUD_115200)
	p:set_data_bits(rs232.RS232_DATA_8)
	p:set_parity(rs232.RS232_PARITY_NONE)
	p:set_stop_bits(rs232.RS232_STOP_1)
	p:set_flow_control(rs232.RS232_FLOW_OFF)
	p:read(...)
	p:close()
end
