#!bin/bash
#loaddb.sh
echo copy /root/zgw.db to /tmp/zgw.db
cp /root/zgw.db /tmp/zgw.db
chmod -R 777 /tmp/zgw.db
