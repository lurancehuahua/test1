#!/bin/sh

# echo "killall -9 zigbee"
# killall -9 zigbee

echo "chmod -R 777 /root/progressMT7688/zigbee"
chmod -R 777 /root/progressMT7688/zigbee
echo "chmod -R 777 /root/progressMT7688/ZigbeeNodeControlBridge_JN5169.bin"
chmod -R 777 /root/progressMT7688/ZigbeeNodeControlBridge_JN5169.bin


echo "cp /root/progressMT7688/zigbee /root/zigbee"
cp /root/progressMT7688/zigbee /root/zigbee
echo "cp /root/progressMT7688/ZigbeeNodeControlBridge_JN5169.bin /usr/lib/iot/ZigbeeNodeControlBridge_JN5169.bin"
cp /root/progressMT7688/ZigbeeNodeControlBridge_JN5169.bin /usr/lib/iot/ZigbeeNodeControlBridge_JN5169.bin


echo "chmod -R 777 /root/zigbee"
chmod -R 777 /root/zigbee
echo "chmod -R 777 /usr/lib/iot/ZigbeeNodeControlBridge_JN5169.bin"
chmod -R 777 /usr/lib/iot/ZigbeeNodeControlBridge_JN5169.bin


# echo "run /root/zigbee"
# /root/zigbee