local time = os.time()

print( time )

-- local test = os.date( "%c", time )
local test = os.date("%a, %d %b %Y %X GMT", os.time())

print( test )