#!/bin/sh

array_num=(1)

#echo ${array_num[0]}
#echo ${array_num[1]}
#echo ${array_num[2]}
#echo ${array_num[3]}
#echo ${array_num[4]}
