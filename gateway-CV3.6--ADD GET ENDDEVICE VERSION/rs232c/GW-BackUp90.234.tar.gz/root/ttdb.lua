local qlite3 = require "luasql.sqlite3"

module ("ttdb", package.seeall)

-- local dbfile = "/root/zgw.db"
local dbfile = "/tmp/zgw.db"

function _dbg(...)
	print(...)
end

function printtab(t)
	local k, v
	for k,v in pairs(t) do  
		_dbg(k, " = ", v)
	end  
end  

function mac2gid(mac64s)
	local gid = math.mod(tonumber(mac64s), 16384) * 4
	_dbg("mac64s = "..mac64s..", gid = "..gid)
	return gid
end

function rows(cur)  
    return function(cur)  
        local t = {}  
        if(nil ~= cur:fetch(t, 'a')) then return t  
        else return nil end
    end, cur 
end  

-- function xprinttab(self,t)  
-- 	printtab(t)
-- end  
  
-- function xrows(self,cur)  
-- 	return rows(cur)
-- end  

--delete a record by id
function del(t,id)
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile) 
	local sql, res

	sql = "DELETE FROM " .. t .. " " .. " WHERE id = " .. id
	_dbg(sql)

	db:setautocommit(false)
	res = db:execute(sql)
	db:commit() 
	_dbg(res)

	db:close()
	env:close()
	return res  
end    

function getidbyname(t, iname)
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile) 
	local sql, res, r, id

	sql = "SELECT id FROM " .. t .. " WHERE name = " .. "\'" .. iname .. "\'"
	_dbg(sql)

	res = db:execute(sql)
	if res ~= nil then
		for r in rows(res) do
			id = r["id"]
			printtab(r)
		end
		res:close()
	end

	_dbg(id)

	db:close()
	env:close()
	return id
end

function getavailableids(t)
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile) 
	local sql, res, r, i, ids

	sql = "SELECT * FROM " .. t
	_dbg(sql)

	res = db:execute(sql)
	if res ~= nil then 
		i = 1
		ids = {}
 		for r in rows(res) do
			ids[i] = r["id"]
			i = i + 1
			printtab(r)
		end
		res:close()
	end 	

	printtab(ids)

	-- res:close()
	db:close()
	env:close()
	return ids
end

function getavailableidsbytag(t, itag)
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile) 
	local sql, res, r, i, ids

	sql = "SELECT * FROM " .. t .. " WHERE tag = " .. itag
	_dbg(sql);

	res = db:execute(sql)
	if res ~= nil then 
		i = 1
		ids = {}
 		for r in rows(res) do
			ids[i] = r["id"]
			i = i + 1
			printtab(r)
		end
		res:close()
	end 	

	printtab(ids)

	-- res:close()
	db:close()
	env:close()
	return ids
end

--set state to db
function setsta(t,id,ista)  
	local env = qlite3.sqlite3()  
	local db = env:connect(dbfile)
	local sql, res

	sql = "UPDATE " .. t .. " SET sta = \'" .. ista .. "\' WHERE id = " .. id
	_dbg(sql)

	db:setautocommit(false)
	res = db:execute(sql)
	db:commit()
	_dbg(res)

	db:close()  
	env:close()
	return res 
end  

--get state by id
function getsta(t,id)  
	local env = qlite3.sqlite3() 
	local db = env:connect(dbfile)
	local sql, res, r, sta

	sql = "SELECT * FROM " .. t .. " WHERE id = " .. id
	_dbg(sql)

	res = db:execute(sql)
	if res ~= nil then
 		for r in rows(res) do  
			sta = r["sta"] or "0"
			printtab(r)
		end
		res:close()
	end 

	_dbg('sta = ',sta)

	--res:close()
	db:close()
	env:close()
	return sta  
end

--set onoff ott to db
function setonoff(t,id,ionoff,iott)  
	local env = qlite3.sqlite3() 
	local db = env:connect(dbfile) 
	local sql, res

	sql = "UPDATE " .. t .. " SET onoff = " .. ionoff .. " , ott = " .. iott .. " WHERE id = " .. id
	_dbg(sql)

	db:setautocommit(false)  
	res = db:execute(sql)
	db:commit()

	_dbg(res)

	db:close()  
	env:close() 
	return res
end

--get onoff ott by id
function getonoff(t,id)
	local env = qlite3.sqlite3()  
	local db = env:connect(dbfile)
	local sql, res, r, onoff, ott

	sql = "SELECT * FROM " .. t .. " WHERE id = " .. id
	_dbg(sql)

	res = db:execute(sql)
	if res ~= nil then
 		for r in rows(res) do
			onoff = r["onoff"] or "1"
			ott = r["ott"] or "0"
			printtab(r)  
		end 
		res:close()
	end	

	_dbg('onoff = ', onoff)
	_dbg('ott = ', ott)

	--res:close()
	db:close()
	env:close()
	return onoff , ott  
end

function setonoffall(t, ionoff, iott)
	local env = qlite3.sqlite3() 
	local db = env:connect(dbfile) 
	local sql, res

	sql = "UPDATE " .. t .. " SET onoff = " .. ionoff .. " , ott = " .. iott
	_dbg(sql) 

	db:setautocommit(false)  
	res = db:execute(sql)
	db:commit()

	_dbg(res)

	db:close()
	env:close()
	return res
end

--set ct ctt to db
function setcct(t,id,ict,ictt)  
	local env = qlite3.sqlite3() 
	local db = env:connect(dbfile)
	local sql, res

	sql = "UPDATE " .. t .. " SET ct = " .. ict .. " , ctt = " .. ictt .. " WHERE id = " .. id
	_dbg(sql)

	db:setautocommit(false)  
	res = db:execute(sql)
	db:commit()

	_dbg(res)

	db:close()  
	env:close() 
	return res  
end

--get ct ctt by id
function getcct(t,id)  
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile) 
	local sql, res, r, ct, ctt

	sql = "SELECT * FROM " .. t .. " WHERE id = " .. id
	_dbg(sql)

	res = db:execute(sql)
	if res ~= nil then
 		for r in rows(res) do  
			ct = r["ct"] or "30"
			ctt = r["ctt"] or "0"
			printtab(r) 
		end
		res:close()
	end

	_dbg('ct = ',ct)
	_dbg('ctt = ',ctt)

	--res:close() 
	db:close()
	env:close()
	return ct , ctt  
end

--set tag to db
function settag(t,id,itag)  
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile)
	local sql, res

	sql = "UPDATE " .. t .. " SET tag = \'" .. itag .. "\' WHERE id = " .. id
	_dbg(sql)

	db:setautocommit(false)  
	res = db:execute(sql)
	db:commit()

	_dbg(res)

	db:close()  
	env:close() 
	return res  
end  

--get tag by id
function gettag(t,id)  
	local env = qlite3.sqlite3()  
	local db = env:connect(dbfile)
	local sql, res, r, tag

	sql = "SELECT * FROM " .. t .. " WHERE id = " .. id
	_dbg(sql)

	res = db:execute(sql)
	if res ~= nil then
 		for r in rows(res) do  
			tag = r["tag"] or ""
			printtab(r)
		end
		res:close()
	end

	_dbg('tag=',tag)

	--res:close()
	db:close()
	env:close()
	return tag
end

function checktag(t, itag)
	local env = qlite3.sqlite3()  
	local db = env:connect(dbfile)
	local sql, res, r, tag

	sql = "SELECT * FROM " .. t .. " WHERE tag = " .. itag
	_dbg(sql)

	res = db:execute(sql)
	if res ~= nil then
 		for r in rows(res) do
			tag = r["tag"] or ""
			printtab(r)
		end
		res:close()
	end

	_dbg('tag=',tag)

	--res:close()
	db:close()
	env:close()

	if tag == itag then return 1 else return 0 end
	-- return tag
end

--set hue sat htt to db
function sethue(t,id,ihue,isat,ihtt)  
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile)
	local sql, res

	sql = "UPDATE " .. t .. " SET hue = " .. ihue .. " , htt = " .. ihtt .. " , sat = " .. isat .. " WHERE id = " .. id
	_dbg(sql)

	db:setautocommit(false)  
	res = db:execute(sql)
	db:commit()

	_dbg(res)

	db:close()
	env:close()
	return res  
end

--get hue sat htt by id
function gethue(t,id)  
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile)  
	local sql, res, r, hue, sat, htt

	sql = "SELECT * FROM " .. t .. " WHERE id = " .. id
	_dbg(sql)

	res = db:execute(sql)
	if res ~= nil then
 		for r in rows(res) do  
			hue = r["hue"] or "130"
			sat = r["sat"] or "0"
			htt = r["htt"] or "0"
			printtab(r)
		end 
		res:close()
	end

	_dbg('hue=',hue)
	_dbg('sat=',sat)
	_dbg('htt=',htt)

	--res:close()
	db:close()
	env:close()
	return hue , sat , htt  
end

--set lum ltt to db
function setlum(t,id,ilum,iltt)  
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile) 
	local sql, res

	sql = "UPDATE " .. t .. " SET lum = " .. ilum .. " , ltt = " .. iltt .. " WHERE id = " .. id
	_dbg(sql) 

	db:setautocommit(false)
	res = assert (db:execute(sql))
	db:commit()

	_dbg(res)

	db:close() 
	env:close()
	return res  
end

--get lum ltt by id
function getlum(t,id)
	local env = qlite3.sqlite3() 
	local db = env:connect(dbfile)
	local sql, res, r, lum, ltt

	sql = "SELECT * FROM " .. t .. " WHERE id = " .. id
	_dbg(sql)

	res = db:execute(sql)
	if res ~= nil then
 		for r in rows(res) do  
			lum = r["lum"] or "100"
			ltt = r["ltt"] or "5"
			printtab(r)
		end 
		res:close()
	end

	_dbg('lum = ',lum)
	_dbg('ltt = ',ltt)

	--res:close() 
	db:close()
	env:close()
	return lum , ltt  
end

--set name to db
function setname(t,id,iname) 
	local env = qlite3.sqlite3()  
	local db = env:connect(dbfile) 
	local sql, res

	sql = "UPDATE " .. t .. " SET name = \'" .. iname .. "\' WHERE id = " .. id
	_dbg(sql)

	db:setautocommit(false)  
	res = db:execute(sql)
	db:commit()

	_dbg(res)

	db:close()  
	env:close() 
	return res  
end

--get name by id
function getname(t,id)
	local env = qlite3.sqlite3() 
	local db = env:connect(dbfile)
	local sql, res, r, name

	sql = "SELECT * FROM " .. t .. " WHERE id = " .. id
	_dbg(sql)

	res = db:execute(sql)
	if res ~= nil then
 		for r in rows(res) do  
			name = r["name"] or ""
			printtab(r) 
		end 
		res:close()
	end 

	_dbg('name = ',name)

	--res:close()
	db:close()
	env:close()
	return name  
end

-- ROOM OPs
--add a record and set tag name
function rooms_add(self,itag,iname)  
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile)
	local sql, res

	sql = "INSERT INTO rooms (tag,name) VALUES (" .. itag .. ",\'" .. iname .. "\')"
	_dbg(sql)

	db:setautocommit(false)
	res = db:execute(sql)
	db:commit()

	_dbg(res)

	db:close()
	env:close()
	return res  
end    

--delete a record by id
function rooms_del(self,id)  
	return del('rooms',id)
end    

--set name to db
function rooms_setname(self,id,iname)
	return setname('rooms',id,iname)
end  

--get name by id
function rooms_getname(self,id)  
	return getname('rooms',id)
end

--set tag to db
function rooms_settag(self,id,itag)  
	return settag('rooms',id,itag)
end  

--get tag by id
function rooms_gettag(self,id)  
	return gettag('rooms',id)  
end

--set state to db
function rooms_setsta(self,id,ista)  
	return setsta('rooms',id,ista)
end

--get state by id
function rooms_getsta(self,id)
	return getsta('rooms',id)
end

function rooms_getavailableids(self)
	return getavailableids('rooms')
end

--set dids to db
function rooms_setsids(self,id,isids)  
	local env = qlite3.sqlite3()  
	local db = env:connect(dbfile) 
	local sql, res

	sql = "UPDATE rooms SET sids = " .. isids .. " WHERE id = " .. id
	_dbg(sql)

	db:setautocommit(false)  
	res = db:execute(sql)
	db:commit()

	_dbg(res)

	db:close()  
	env:close() 
	return res  
end  

--get dids by id
function rooms_getsids(self,id)  
	local env = qlite3.sqlite3();  
	local db = env:connect(dbfile);  
	local sql, res, r, sids

	sql = "SELECT * FROM rooms WHERE id = " .. id
	_dbg(sql)

	res = db:execute(sql)
	if res ~= nil then
 		for r in rows(res) do  
			sids = r["sids"] or "0"
			printtab(r)
		end
		res:close()
	end 

	_dbg('sids = ',sids)

	--res:close()
	db:close()
	env:close()
	return sids  
end

-- SCENCE OPs
--add a record and set tag name
function scenes_add(self,itag,iname)  
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile)
	local sql, res

	sql = "INSERT INTO scenes (tag,name) VALUES (" .. itag .. ",\'" .. iname .. "\')"
	_dbg(sql)

	db:setautocommit(false);
	res = db:execute(sql)
	db:commit()

	_dbg(res)

	db:close()
	env:close()
	return res  
end    

--delete a record by id
function scenes_del(self,id)
	return del('scenes',id)
end    

--set name to db
function scenes_setname(self,id,iname)  
	return setname('scenes',id,iname) 
end  

--get name by id
function scenes_getname(self,id)  
	return getname('scenes',id)
end

--set tag to db
function scenes_settag(self,id,itag)  
	return settag('scenes',id,itag)
end  

--get tag by id
function scenes_gettag(self,id)  
	return gettag('scenes',id)  
end

function scenes_getavailableids(self)
	return getavailableids('scenes')
end

--set gids to db
function scenes_setgids(self,id,igids)  
	local env = qlite3.sqlite3()  
	local db = env:connect(dbfile)  
	local sql, res

	sql = "UPDATE scenes SET gids = " .. igids .. " WHERE id = " .. id
	_dbg(sql) 

	db:setautocommit(false)  
	res = db:execute(sql)
	db:commit()

	_dbg(res)

	db:close()  
	env:close() 
	return res  
end  

--get gids by id
function scenes_getgids(self,id)  
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile) 
	local sql, res, r, gids

	sql = "SELECT * FROM scenes WHERE id = " .. id
	_dbg(sql)

	res = db:execute(sql)
	if res ~= nil then
 		for r in rows(res) do  
			gids = r["gids"] or "0"
			printtab(r) 
		end
		res:close()
	end 

	_dbg('gids = ',gids)

	--res:close()
	db:close() 
	env:close()
	return gids  
end

-- GROUP OPs
--add a record and set tag name
function groups_add(self,itag,iname)
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile)
	local sql, res

	sql = "INSERT INTO groups (tag,name) VALUES (" .. itag .. ",\'" .. iname .. "\')"
	_dbg(sql)

	db:setautocommit(false)
	res = db:execute(sql)
	db:commit()

	_dbg(res)

	db:close()
	env:close()
	return res  
end    

--delete a record by id
function groups_del(self,id)  
	return del('groups',id)
end 
 
--set name to db
function groups_setname(self,id,iname)  
	return setname('groups',id,iname)
end  

--get name by id
function groups_getname(self,id)  
	return getname('groups',id)
end

--set tag to db
function groups_settag(self,id,itag)  
	return settag('groups',id,itag)
end

--get tag by id
function groups_gettag(self,id)  
	return gettag('groups',id) 
end

--check tag
function groups_checktag(self,itag)  
	return checktag('groups',itag) 
end

--set all groups onoff ott to db
function groups_setonoffall(self,ionoff,iott)  
	return setonoffall('groups',ionoff,iott)
end

--set onoff ott to db
function groups_setonoff(self,id,ionoff,iott)  
	return setonoff('groups',id,ionoff,iott)
end  

--get onoff ott by id
function groups_getonoff(self,id)  
	return getonoff('groups',id) 
end

--set lum ltt to db
function groups_setlum(self,id,ilum,iltt)  
	return setlum('groups',id,ilum,iltt)
end

--get lum ltt by id
function groups_getlum(self,id)  
	return getlum('groups',id)
end

--set ct ctt to db
function groups_setcct(self,id,ict,ictt)  
	return setcct('groups',id,ict,ictt)
end

--get ct ctt by id
function groups_getcct(self,id)  
	return getcct('groups',id)
end

--set hue hdir htt to db
function groups_sethue(self,id,ihue,isat,ihtt)  
	return sethue('groups',id,ihue,isat,ihtt)
end

--get hue hdir htt by id
function groups_gethue(self,id)  
	return gethue('groups',id)  
end

--set state to db
function groups_setsta(self,id,ista)  
	return setsta('groups',id,ista)
end

--get state by id
function groups_getsta(self,id)  
	return getsta('groups',id)
end

function groups_getavailableids(self)
	return getavailableids('groups')
end

function groups_getavailableidsbytag(self, itag)
	return getavailableidsbytag('groups',itag)
end

function groups_getidbyname(self, iname)
	return getidbyname('groups',iname)
end

--set dids to db
function groups_setdids(self,id,idids)
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile)
	local sql, res

	sql = "UPDATE groups SET dids = " .. idids .. " WHERE id = " .. id
	_dbg(sql)

	db:setautocommit(false)  
	res = db:execute(sql)
	db:commit()

	_dbg(res)

	db:close()
	env:close()
	return res
end  

--get dids by id
function groups_getdids(self,id)
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile)
	local sql, res, r, dids

	sql = "SELECT * FROM groups WHERE id = " .. id
	_dbg(sql)

	res = db:execute(sql)
	if res ~= nil then
		for r in rows(res) do
			dids = r["dids"] or "0"
			printtab(r)
		end
		res:close()
	end 

	_dbg('dids = ',dids)

	--res:close()
	db:close()
	env:close()
	return dids
end

--set sid to db
function groups_setsid(self,id,isid)
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile)
	local sql, res

	sql = "UPDATE groups SET sid = " .. isid .. " WHERE id = " .. id
	_dbg(sql);

	db:setautocommit(false)
	res = db:execute(sql)
	db:commit()

	_dbg(res)

	db:close()  
	env:close()
	return res  
end  

--get sid by id
function groups_getsid(self,id)  
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile) 
	local sql, res, r, sid

	sql = "SELECT * FROM groups WHERE id = " .. id
	_dbg(sql);

	res = db:execute(sql)
	if res ~= nil then
 		for r in rows(res) do  
			sid = r["sid"] or "0"
			printtab(r)
		end
		res:close()
	end 

	_dbg('sid = ',sid)

	--res:close() 
	db:close()
	env:close()
	return sid  
end

-- DEVICE OPs
--add a record and set tag mac
function devices_add(self,itag,imac)  
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile)
	local sql, res

	sql = "INSERT INTO devices (tag,mac) VALUES (" .. itag .. "," .. imac .. ")"
	_dbg(sql)

	db:setautocommit(false)
	res = db:execute(sql)
	db:commit()

	_dbg(res)

	db:close()
	env:close()
	return res  
end    

--delete a record by id
function devices_del(self,id)  
	return del('devices',id)  
end    

--set name to db
function devices_setname(self,id,iname)  
	return setname('devices',id,iname)
end

--get name by id
function devices_getname(self,id)
	return getname('devices',id)
end

--set hue sat htt to db
function devices_sethue(self,id,ihue,isat,ihtt)
	return sethue('devices',id,ihue,isat,ihtt) 
end

--get hue sat htt by id
function devices_gethue(self,id)  
	return gethue('devices',id) 
end

--set state to db
function devices_setsta(self,id,ista)  
	return setsta('devices',id,ista)
end  

--get state by id
function devices_getsta(self,id)  
	return getsta('devices',id)
end

--set all devices onoff ott to db
function devices_setonoffall(self,id,ionoff,iott)  
	return setonoffall('devices',id,ionoff,iott)
end

--set onoff ott to db
function devices_setonoff(self,id,ionoff,iott)  
	return setonoff('devices',id,ionoff,iott)
end  

--get onoff ott by id
function devices_getonoff(self,id)  
	return getonoff('devices',id) 
end

--set lum ltt to db
function devices_setlum(self,id,ilum,iltt)  
	return setlum('devices',id,ilum,iltt)  
end

--get lum ltt by id
function devices_getlum(self,id)  
	return getlum('devices',id) 
end

--set ct ctt to db
function devices_setcct(self,id,ict,ictt)  
	return setcct('devices',id,ict,ictt)
end

--get ct ctt by id
function devices_getcct(self,id)  
	return getcct('devices',id)
end

--set tag to db
function devices_settag(self,id,itag)  
	return settag('devices',id,itag)
end  

--get tag by id
function devices_gettag(self,id)  
	return gettag('devices',id)
end

function devices_getavailableids(self)
	return getavailableids('devices')
end

--set pos to db
function devices_setpos(self,id,ipos)  
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile) 
	local sql, res

	sql = "UPDATE devices SET pos = " .. ipos .. " WHERE id = " .. id
	_dbg(sql) 

	db:setautocommit(false)  
	res = db:execute(sql)
	db:commit()

	_dbg(res)

	db:close() 
	env:close()
	return res  
end  

--get pos by id
function devices_getpos(self,id)  
	local env = qlite3.sqlite3() 
	local db = env:connect(dbfile)
	local sql, res, r, pos

	sql = "SELECT * FROM devices WHERE id = " .. id
	_dbg(sql)

	res = db:execute(sql)
	if res ~= nil then
 		for r in rows(res) do  
			pos = r["pos"] or "0"
			printtab(r)
		end
		res:close()
	end 

	_dbg('pos = ',pos)

	--res:close()
	db:close()
	env:close()
	return pos  
end

--get addr by id
function devices_getaddr(self, id)
	local env = qlite3.sqlite3() 
	local db = env:connect(dbfile)
	local sql, res, r, addr

	sql = "SELECT * FROM devices WHERE id = " .. id
	_dbg(sql)

	res = db:execute(sql)
	if res ~= nil then
 		for r in rows(res) do  
			addr = r["addr"] or "0"
			printtab(r)
		end
		res:close()
	end 

	_dbg('addr = ',addr)

	--res:close()
	db:close()
	env:close()
	return addr
end

-- devices_getaddr(self, 4)

--get mac by id
function devices_getmac(self, id)
	local env = qlite3.sqlite3() 
	local db = env:connect(dbfile)
	local sql, res, r, mac

	sql = "SELECT mac FROM devices WHERE id = " .. id
	_dbg(sql)

	res = db:execute(sql)
	if res ~= nil then
 		for r in rows(res) do  
			mac = r["mac"] or "0"
			printtab(r)
		end
		res:close()
	end 

	_dbg('mac = ',mac)

	--res:close()
	db:close()
	env:close()
	return mac
end

-- devices_getmac(self, 4)

--get id by addr
function devices_getidbyaddr(self,iaddr)  
	local env = qlite3.sqlite3() 
	local db = env:connect(dbfile)
	local sql, res, r, id

	sql = "SELECT * FROM devices WHERE addr = " .. iaddr
	_dbg(sql)

	res = db:execute(sql)
	if res ~= nil then
 		for r in rows(res) do  
			id = r["id"]
			printtab(r)
		end
		res:close()
	end 

	_dbg('id = ',id)

	--res:close()
	db:close()
	env:close()
	return id  
end

function devices_delbyaddr(self, iaddr)
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile)
	local sql, res

	sql = "DELETE FROM devices WHERE addr = " .. iaddr
	_dbg(sql)

	db:setautocommit(false)
	res = db:execute(sql)
	db:commit() 
	_dbg(res)

	db:close()
	env:close()
end

-- devices_delbyaddr(self, )

--set name to db
function devices_setnamebyaddr(t,iaddr,iname) 
	local env = qlite3.sqlite3()  
	local db = env:connect(dbfile) 
	local sql, res

	sql = "UPDATE devices SET name = \'" .. iname .. "\' WHERE addr = " .. iaddr
	_dbg(sql)

	db:setautocommit(false)
	res = db:execute(sql)
	db:commit()

	_dbg(res)

	db:close()  
	env:close() 
	return res  
end

-- devices_setnamebyaddr(self, )

function devices_load(self)
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile)
	local sql, res, r, array, i

	sql = "SELECT id, tag, name, addr FROM devices"
	_dbg(sql)

	array = {}
	res = db:execute(sql)
	if res ~= nil then
		i = 1
 		for r in rows(res) do 
			array[i] = r["id"] or ""
			array[i+1] = r["tag"] or ""
			array[i+2] = r["name"] or ""
			array[i+3] = r["addr"] or ""
			_dbg(array[i] .. ", " .. array[i+1] .. ", " .. array[i+2] .. ", " .. array[i+3])
			printtab(r)
			i = i + 4
		end
		res:close()
	end 

	db:close()
	env:close()
	return array
end

-- devices_load(self)

function devices_checkid(self, id)
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile)
	local sql, res, flag

	sql = "SELECT id FROM devices WHERE id = " .. id
	_dbg(sql)

	flag = 0
	res = db:execute(sql)
	if res ~= nil then
		for r in rows(res) do 
			flag = 1
			printtab(r)
		end
		res:close()
	end

	_dbg(flag)

	db:close()
	env:close()
	return flag
end

function devices_getdetail(self, id)
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile)
	local sql, res, name, tag, addr

	sql = "SELECT * FROM devices WHERE id = " .. id
	_dbg(sql)

	res = db:execute(sql)
	if res ~= nil then
		for r in rows(res) do 
			name = r["name"] or ""
			tag = r["tag"] or ""
			addr = r["addr"] or ""
			printtab(r)
		end
		res:close()
	end

	db:close()
	env:close()
	return name, tag, addr
end

function devices_getgid(self, id)
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile)
	local sql, res, gid

	sql = "SELECT * FROM devices WHERE id = " .. id
	_dbg(sql)

	res = db:execute(sql)
	if res ~= nil then
		for r in rows(res) do 
			if r["mac"] ~= nil then
				gid = mac2gid(r["mac"])
				_dbg(gid)
			end
			printtab(r)
		end
		res:close()
	end

	db:close()
	env:close()
	return gid
end

-- devices_getgid(sekf, 11)

function devices_getprofile(self, iaddr)
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile)
	local sql, res, onh, offh, uen

	sql = "SELECT onh, offh, uen FROM devices WHERE addr = " .. iaddr
	_dbg(sql)
	res = db:execute(sql)
	if res ~= nil then
		for r in rows(res) do 
			onh = r["onh"] or "0"
			offh = r["offh"] or "0"
			uen = r["uen"] or "0"
			printtab(r)
		end
		res:close()
	end
	db:close()
	env:close()
	return onh, offh, uen
end

-- devices_getprofile(self, 7090)

-- multi-api, rooms, scenes add as a group
-- use state to sign it is a room-group
function grooms_add(self, itag, iname)
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile)
	local sql, res

	-- return if the same name grooms is exist already
	sql = "SELECT * FROM groups WHERE sta = 55 AND name = " .. "\'" .. iname .. "\'"
	_dbg(sql)
	res = db:execute(sql)
	if res ~= nil then
		for r in rows(res) do 
			printtab(r)
			res:close()
			db:close()
			env:close()
			return 0
		end
		res:close()
	end

	sql = "INSERT INTO groups (tag,name,sta,onoff,lum) VALUES (" .. itag .. ",\'" .. iname .. "\', 55, 0, 0)"
	_dbg(sql)
	db:setautocommit(false);
	res = db:execute(sql)
	db:commit()
	_dbg(res)

	db:close()
	env:close()
	return res 
end

function grooms_modify(self, inameorg, itag, iname)
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile)
	local sql, res, id

	-- return if the same name grooms is exist already
	sql = "SELECT id FROM groups WHERE sta = 55 AND name = " .. "\'" .. inameorg .. "\'"
	_dbg(sql)
	res = db:execute(sql)
	if res ~= nil then
 		for r in rows(res) do
 			id =  r["id"] or ""
			printtab(r)
		end
		res:close()
	end

	if id ~= nil then
		sql = "UPDATE groups SET name = " .. "\'" .. iname .. "\', tag = " .. itag .. " WHERE sta = 55 AND id = " .. id
		_dbg(sql)
		db:setautocommit(false)
		res = db:execute(sql)
		db:commit()
		_dbg(res)
	end

	db:close()
	env:close()
	return res 
end

function grooms_del(self, id)
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile)
	local sql, res

	sql = "DELETE FROM groups WHERE id = " .. id
	_dbg(sql)

	db:setautocommit(false)
	res = db:execute(sql)
	db:commit() 
	_dbg(res)

	db:close()
	env:close()
	return res
end

-- ret: array = {id, tag, name, scence_name, onoff, lum} * n
function grooms_load(self)
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile)
	local sql, res, r, array, i

	sql = "SELECT id, tag, name, sid, onoff, lum FROM groups WHERE sta = 55"
	_dbg(sql)

	array = {}
	res = db:execute(sql)
	if res ~= nil then
		i = 1
 		for r in rows(res) do 
			array[i] = r["id"] or ""
			array[i+1] = r["tag"] or ""
			array[i+2] = r["name"] or ""
			array[i+3] = r["sid"] or "0"
			array[i+4] = r["onoff"] or "1"
			array[i+5] = r["lum"] or "100"
			_dbg(array[i] .. " " .. array[i+1] .. " " .. array[i+2] .. " " .. array[i+3] .. " " .. array[i+4] .. " " .. array[i+5])
			printtab(r)
			i = i + 6
		end
		res:close()
	end 

	-- get scence name by sid and replace array[i+3] which store sid before.
	if i > 1 then
		i = 1
		while (array[i] ~= nil) do
			sql = "SELECT name FROM groups WHERE id = " .. array[i+3]
			res = db:execute(sql)
			array[i+3] = ""
			if res ~= nil then
				for r in rows(res) do 
					array[i+3] = r["name"] or ""
					printtab(r)
				end
				res:close()
			end
			_dbg(array[i] .. " " .. array[i+1] .. " " .. array[i+2] .. " " .. array[i+3] .. " " .. array[i+4] .. " " .. array[i+5])
			i = i + 6
		end
	end

	db:close()
	env:close()
	return array
end

-- grooms_load(self)

-- ret: array = {id, tag, name} * n
function grooms_loadtagname(self)
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile)
	local sql, res, r, array, i

	sql = "SELECT id, tag, name FROM groups WHERE sta = 55"
	_dbg(sql)

	array = {}
	res = db:execute(sql)
	if res ~= nil then
		i = 1
 		for r in rows(res) do 
 			array[i] = r["id"] or ""
			array[i+1] = r["tag"] or ""
			array[i+2] = r["name"] or ""
			_dbg(array[i] .. " " .. array[i+1] .. " " .. array[i+2])
			printtab(r)
			i = i + 3
		end
		res:close()
	end 

	db:close()
	env:close()
	return array
end
-- grooms_loadtagname(self)

-- ret: room's scence list, array = {id, tag, name}
function grooms_loadscenes(self, id)
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile)
	local sql, res, r, array, i, array2, j, splitlist, k, v

	-- get all scences' list
	sql = "SELECT id, tag, name, dids FROM groups WHERE sta = 44"
	_dbg(sql)
	array = {}
	res = db:execute(sql)
	if res ~= nil then
		i = 1
 		for r in rows(res) do 
 			array[i] = r["id"] or ""
			array[i+1] = r["tag"] or ""
			array[i+2] = r["name"] or ""
			array[i+3] = r["dids"] or "0"
			_dbg(array[i] .. " " .. array[i+1] .. " " .. array[i+2] .. " " .. array[i+3])
			printtab(r)
			i = i + 4
		end
		res:close()
	end 

	-- check every scence's dids if content param id
	i = 1
	j = 1
	array2 = {}
	while (array[i] ~= nil) do
		splitlist = {}
		string.gsub(array[i+3], '[^,]+', function(w) table.insert(splitlist, w) end ) 
		for k,v in ipairs(splitlist) do
			if tonumber(v) == id then 
				array2[j] = array[i]
				array2[j+1] = array[i+1]
				array2[j+2] = array[i+2]
				_dbg(array2[j] .. " " .. array2[j+1] .. " " .. array2[j+2])
				j = j + 3
			end
		end
		i = i + 4
	end

	db:close()
	env:close()
	return array2
end
-- grooms_loadscenes(self, '10')

-- ret: room's devices list, array = {addr, tag, name, onoff, lum, ct, hue}
function grooms_loaddevices(self, id)
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile)
	local sql, res, r, dids, array, i, splitlist, k, v

	-- get room's dids(devices list)
	sql = "SELECT dids FROM groups WHERE id = " .. id
	_dbg(sql)

	res = db:execute(sql)
	if res ~= nil then
 		for r in rows(res) do 
 			dids = r["dids"] or "0"
			printtab(r)
		end
		res:close()
	end 

	-- get every device's details
	if dids ~= nil then
		splitlist = {}
		string.gsub(dids, '[^,]+', function(w) table.insert(splitlist, w) end ) 

		array = {}
		i = 1
		for k,v in ipairs(splitlist) do
			sql = "SELECT addr, tag, name, onoff, lum, ct, hue FROM devices WHERE id = " .. v
			res = db:execute(sql)
			if res ~= nil then
 				for r in rows(res) do 
 					array[i] = r["addr"] or ""
 					array[i+1] = r["tag"] or ""
 					array[i+2] = r["name"] or ""
 					array[i+3] = r["onoff"] or "1"
 					array[i+4] = r["lum"] or "100"
 					array[i+5] = r["ct"] or "30"
 					array[i+6] = r["hue"] or "130"
 					_dbg(array[i] .. " " .. array[i+1] .. " " .. array[i+2] .. " " .. array[i+3] .. " " .. array[i+4] .. " " .. array[i+5] .. " " .. array[i+6])
 					printtab(r)
 					i = i + 7
				end
				res:close()
			end 
		end
	end

	db:close()
	env:close()
	return array
end

-- grooms_loaddevices(self, '10')

-- ret: room's scene's name
function grooms_loadcurscenesname(self, id)
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile)
	local sql, res, r, sid, s_name

	-- get room's sid
	sql = "SELECT sid FROM groups WHERE id = " .. id
	_dbg(sql)

	res = db:execute(sql)
	if res ~= nil then
 		for r in rows(res) do 
 			sid = r["sid"] or "0"
			printtab(r)
		end
		res:close()
	end 

	-- get scence's name by sid
	if sid ~= nil then
		sql = "SELECT name FROM groups WHERE id = " .. sid
		res = db:execute(sql)
		s_name = ""
		if res ~= nil then
			for r in rows(res) do
				s_name = r["name"]
				printtab(r)
			end
			res:close()
		end
	end

	_dbg(s_name)

	db:close()
	env:close()
	return s_name
end

-- grooms_loadcurscenesname(self, '8')

-- ret: devices list, array = {addr, tag, name, onoff, lum, ct, hue}
-- ret: scence list, array = {id, tag, name}
-- ret: current scene's name
function grooms_loadchild(self, id)
	local devices = {}
	local scenes = {}
	local s_name, i

	devices = grooms_loaddevices(self, id)
	scenes = grooms_loadscenes(self, id)
	s_name = grooms_loadcurscenesname(self, id)

	_dbg("------------grooms_loadchild---------------")
	if devices ~= nil then
		i = 1
		while (devices[i] ~= nil) do
			_dbg(devices[i] .. " " .. devices[i+1] .. " " .. devices[i+2] .. " " .. devices[i+3] .. " " .. devices[i+4] .. " " .. devices[i+5] .. " " .. devices[i+6])
			i = i + 7
		end
	end

	if scenes ~= nil then
		i = 1
		while (scenes[i] ~= nil) do
			_dbg(scenes[i] .. " " .. scenes[i+1] .. " " .. scenes[i+2])
			i = i + 3
		end
	end

	_dbg(s_name)
	_dbg("------------grooms_loadchild end---------------")

	return devices, scenes, s_name
end

-- grooms_loadchild(self, 10)

function grooms_loaddids(self)
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile)
	local sql, res, r, dids, didsall

	sql = "SELECT dids FROM groups WHERE sta = 55"
	_dbg(sql)

	didsall = "0"
	res = db:execute(sql)
	if res ~= nil then
 		for r in rows(res) do 
 			dids = r["dids"] or "0"
 			didsall = didsall..","..dids
			printtab(r)
		end
		res:close()
	end 

	_dbg(dids)

	db:close()
	env:close()
	return dids
end
-- grooms_loaddids(self)

function grooms_loadbydid(self, idid)
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile)
	local sql, res, r, array, i, dids, splitlist, k, v, txt

	sql = "SELECT id, dids FROM groups WHERE sta = 55"
	_dbg(sql)

	array = {}
	txt = ""
	res = db:execute(sql)
	if res ~= nil then
		i = 1
 		for r in rows(res) do 
 			dids = r["dids"]
 			if dids ~= nil then
 				splitlist = {}
 				string.gsub(dids, '[^,]+', function(w) table.insert(splitlist, w) end )
 				for k, v in ipairs(splitlist) do
 					if idid == tonumber(v) then
 						array[i] = r["id"]
 						txt = txt..i.." "..array[i].." "
 						i = i + 1
 					end
				end
 			end
			printtab(r)
		end
		res:close()
	end 

	_dbg(txt)

	db:close()
	env:close()
	return array
end

-- grooms_loadbydid()

-- ret flag: 1-the name is already exist, 0-the name is not exist yet
function grooms_checkname(self, iname)
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile)
	local sql, res, flag

	sql = "SELECT name FROM groups WHERE sta = 55 AND name = " .. "\'" .. iname .. "\'"
	_dbg(sql)

	flag = 0
	res = db:execute(sql)
	if res ~= nil then
		for r in rows(res) do 
			flag = 1
			printtab(r)
		end
		res:close()
	end

	_dbg(flag)

	db:close()
	env:close()
	return flag
end

-- ret flag: 1-the id is available, 0-the id is unavailable
function grooms_checkid(self, id)
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile)
	local sql, res, flag

	sql = "SELECT id FROM groups WHERE sta = 55 AND id = " .. id
	_dbg(sql)

	flag = 0
	res = db:execute(sql)
	if res ~= nil then
		for r in rows(res) do 
			flag = 1
			printtab(r)
		end
		res:close()
	end

	_dbg(flag)

	db:close()
	env:close()
	return flag
end

-- ret id: nil or id
function grooms_getidbyname(self, iname)
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile) 
	local sql, res, r, id

	sql = "SELECT id FROM groups WHERE sta = 55 AND name = " .. "\'" .. iname .. "\'"
	_dbg(sql)

	res = db:execute(sql)
	if res ~= nil then
		for r in rows(res) do
			id = r["id"] or ""
			printtab(r)
		end
		res:close()
	end

	_dbg(id)

	db:close()
	env:close()
	return id
end

-- grooms_checkname(self, "Reading book")

function gscenes_add(self,itag,iname,igids,ilum,ict,ihue)
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile)
	local sql, res, r, sid, splitlist, k, v

	-- return if the same name scenes is exist already
	sql = "SELECT * FROM groups WHERE sta = 44 AND name = " .. "\'" .. iname .. "\'"
	_dbg(sql)
	res = db:execute(sql)
	if res ~= nil then
		for r in rows(res) do 
			printtab(r)
			res:close()
			db:close()
			env:close()
			return 0
		end
		res:close()
	end

	-- add a scenes-group
	sql = "INSERT INTO groups (tag,name,sta,dids,lum,ct,hue) VALUES "
	sql = sql .. "(" .. itag .. ",\'" .. iname .. "\', 44,\'" .. igids .. "\'," .. ilum .. "," .. ict .. "," .. ihue .. ")"
	_dbg(sql)
	db:setautocommit(false)
	res = db:execute(sql)
	db:commit()
	_dbg(res)

	-- get the scenes-group's id added above
	sql = "SELECT id FROM groups WHERE sta = 44 AND name = " .. "\'" .. iname .. "\'"
	_dbg(sql)
	res = db:execute(sql)
	if res ~= nil then
 		for r in rows(res) do
 			sid =  r["id"] or ""
			printtab(r)
		end
		res:close()
	end 

	if sid ~= nil then 
		-- gids is the room-group ids, update the room-group's sid
		if (igids ~= nil) then
			splitlist = {}
			string.gsub(igids, '[^,]+', function(w) table.insert(splitlist, w) end) 
			for k,v in ipairs(splitlist) do
				sql = "UPDATE groups SET sid = " .. sid .. " WHERE sta = 55 AND id = " .. v
				_dbg(sql)
				res = db:execute(sql)
				db:commit()
				_dbg(res)
			end
		end
	end

	db:close()
	env:close()
	return res 
end 

-- test function
function gscenes_setdefault(self)
	gscenes_add(self, 0, 'Watching movie', '1', 150, 1, 0)
	gscenes_add(self, 0, 'Meet visitor', '1', 150, 1, 0)
	gscenes_add(self, 0, 'Reading book', '1', 150, 1, 0)
	gscenes_add(self, 0, 'Normal', '1', 150, 1, 0)
	gscenes_add(self, 0, 'Cleaning', '1', 150, 1, 0)
	gscenes_add(self, 0, 'Wake up', '1', 150, 1, 0)
end

--gscenes_setdefault(self)

function gscenes_modify(self,inameorg,itag,iname,igids,ilum,ict,ihue)
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile)
	local sql, res, r, sid, splitlist, k, v

	-- find the scene's id by name
	sql = "SELECT id FROM groups WHERE sta = 44 AND name = " .. "\'" .. inameorg .. "\'"
	_dbg(sql)
	res = db:execute(sql)
	if res ~= nil then
 		for r in rows(res) do
 			sid =  r["id"] or ""
			printtab(r)
		end
		res:close()
	end

	if sid ~= nil then
		-- update name,dids,lum,ct,hue
		-- sql = "UPDATE groups SET name = " .. "\'" .. iname .. "\', dids = " .. "\'" .. igids .. "\', lum = " .. ilum .. ", ct = " .. ict .. ", hue = " .. ihue .. " WHERE sta = 44 AND id = " .. sid
		sql = "UPDATE groups SET "
		sql = sql .. "name = \'" .. iname .. "\'"
		sql = sql .. ", dids = \'" .. igids .."\'"
		sql = sql .. ", lum = " .. ilum
		sql = sql .. ", ct = " .. ict
		sql = sql .. ", hue = " .. ihue
		sql = sql .. " WHERE sta = 44 AND id = " .. sid

		_dbg(sql)
		db:setautocommit(false)
		res = db:execute(sql)
		db:commit()
		_dbg(res)

		-- set room-group's which sid is above to 0
		sql = "SELECT id FROM groups WHERE sta = 55 AND sid = " .. sid
		_dbg(sql)
		res = db:execute(sql)
		if res ~= nil then
			for r in rows(res) do
				sql = "UPDATE groups SET sid = 0 WHERE sta = 55 AND id = " .. r["id"]
				_dbg(sql)
				res = db:execute(sql)
				db:commit()
				_dbg(res)
			end
		end

		-- gids is the room-group ids, update the room-group's sid
		if (igids ~= nil) then
			splitlist = {}
			string.gsub(igids, '[^,]+', function(w) table.insert(splitlist, w) end) 
			for k,v in ipairs(splitlist) do
				sql = "UPDATE groups SET sid = " .. sid .. " WHERE sta = 55 AND id = " .. v
				_dbg(sql)
				res = db:execute(sql)
				db:commit()
				_dbg(res)
			end
		end
	end
	
	db:close()
	env:close()
	return res 
end

-- ret scenes list, array = {name, tag} * n
function gscenes_load(self)
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile)
	local sql, res, r, array, i

	-- get scence's list
	-- sql = "SELECT name, tag FROM scenes"
	sql = "SELECT name, tag FROM groups WHERE sta = 44"
	_dbg(sql)

	array = {}
	res = db:execute(sql)
	if res ~= nil then
		i = 1
 		for r in rows(res) do  
			array[i] = r["name"]
			array[i+1] = r["tag"]
			_dbg(array[i] .. " " .. array[i+1])
			printtab(r)
			i = i + 2
		end
		res:close()
	end 

	db:close()
	env:close()
	return array
end

-- gscenes_load(self)

-- get scenes' more info
-- ret: onoff, lum, ct, hue
function gscenes_loadmore(self, id)
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile)
	local sql, res, r, onoff, lum, ct, hue

	-- sql = "SELECT name, tag FROM scenes"
	sql = "SELECT onoff, lum, ct, hue FROM groups WHERE sta = 44 AND id = "..id
	_dbg(sql)

	res = db:execute(sql)
	if res ~= nil then
 		for r in rows(res) do  
			onoff = r["onoff"] or "1"
			lum = r["lum"] or "100"
			ct = r["ct"] or "30"
			hue = r["hue"] or "130"
			printtab(r)
		end
		res:close()
	end 

	db:close()
	env:close()
	return onoff, lum, ct, hue
end

-- gscenes_loadmore(self, 1)

-- ret flag: 1-the name is already exist, 0-the name is not exist yet
function gscenes_checkname(self, iname)
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile)
	local sql, res, flag

	sql = "SELECT name FROM groups WHERE sta = 44 AND name = " .. "\'" .. iname .. "\'"
	_dbg(sql)

	flag = 0
	res = db:execute(sql)
	if res ~= nil then
		for r in rows(res) do 
			flag = 1
			printtab(r)
		end
		res:close()
	end

	_dbg(flag)

	db:close()
	env:close()
	return flag
end

-- gscenes_checkname(self, "Reading book")

-- get id according to the param name
-- ret id: nil or id
function gscenes_getidbyname(self, iname)
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile) 
	local sql, res, r, id

	sql = "SELECT id FROM groups WHERE sta = 44 AND name = " .. "\'" .. iname .. "\'"
	_dbg(sql)

	res = db:execute(sql)
	if res ~= nil then
		for r in rows(res) do
			id = r["id"]
			printtab(r)
		end
		res:close()
	end

	_dbg(id)

	db:close()
	env:close()
	return id
end

-- del user defined scence. not judge wheather it is user defined or not here, judged by up layer(web) functions.
function gscenes_deluserdef(self, iname)
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile)
	local sql, res, sid

	-- find the scene's id by name
	sql = "SELECT id FROM groups WHERE sta = 44 AND name = " .. "\'" .. iname .. "\'"
	_dbg(sql)

	res = db:execute(sql)
	if res ~= nil then
		for r in rows(res) do 
			sid = r["id"]
			printtab(r)
		end
		res:close()
	end

	_dbg(sid)

	-- del the scene by id & reset the room's sid if the sid is the deleted scene.
	if sid ~= nil then
		sql = "DELETE FROM groups WHERE id = " .. sid
		_dbg(sql)

		db:setautocommit(false)
		res = db:execute(sql)
		db:commit() 
		_dbg(res)

		sql = "UPDATE groups SET sid = 0 WHERE sta = 55 AND sid = " .. sid
		_dbg(sql)

		res = db:execute(sql)
		db:commit()
		_dbg(res)
	end

	db:close()
	env:close()
end

-- gscenes_deluserdef(self, "Normal")
function timers_addschedule(self, id, iname, itime, irt, irids, isids)
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile)
	local sql, res, r

	if id == nil then
		-- add a timer
		sql = "INSERT INTO timers (tag,name,onf,time,rt,rids,sids) VALUES "
		sql = sql .. "(0,\'" .. iname .. "\', 0,\'" .. itime .. "\',\'" .. irt .. "\',\'" .. irids .. "\',\'" .. isids .. "\')"
		_dbg(sql)
		db:setautocommit(false)
		res = db:execute(sql)
		db:commit()
		_dbg(res)
	else
		-- update a timer
		sql = "UPDATE timers SET "
		sql = sql .. "name = \'" .. iname .. "\'"
		sql = sql .. ", time = \'" .. itime .. "\'"
		sql = sql .. ", rt = \'" .. irt .. "\'"
		sql = sql .. ", rids = \'" .. irids .. "\'"
		sql = sql .. ", sids = \'" .. isids .. "\'"
		sql = sql .. " WHERE id = " .. id
		_dbg(sql)
		db:setautocommit(false)
		res = db:execute(sql)
		db:commit()
		_dbg(res)
	end

	db:close()
	env:close()
	return res 
end 

-- timers_addschedule(self, 1, "test_timer0", "11:30", ",1,2,3,4", ",74", ",2")

function timers_deleteschedule(self, id)
	return del('timers',id)
end

-- timer
function timers_loadschedule(self)
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile)
	local sql, res, r, array, i

	sql = "SELECT * FROM timers"
	_dbg(sql)

	array = {}
	res = db:execute(sql)
	if res ~= nil then
		i = 1
 		for r in rows(res) do 
			array[i] = r["id"] or ""
			array[i+1] = r["name"] or ""
			array[i+2] = r["time"] or ""
			array[i+3] = r["rt"] or ""
			array[i+4] = r["onf"] or "0"
			_dbg(array[i] .. " " .. array[i+1] .. " " .. array[i+2] .. " " .. array[i+3] .. " " .. array[i+4])
			printtab(r)
			i = i + 5
		end
		res:close()
	end

	db:close()
	env:close()
	return array
end

-- timers_loadschedule(self)

function timers_setonf(self,id,ionf)  
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile)
	local sql, res

	sql = "UPDATE timers SET onf = \'" .. ionf .. "\' WHERE id = " .. id
	_dbg(sql)

	db:setautocommit(false)  
	res = db:execute(sql)
	db:commit()

	_dbg(res)

	db:close()  
	env:close() 
	return res  
end

-- timers_setonf(self, 1, 1)

function timers_loadaddschedule(self, id)
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile)
	local sql, res, r, array, i, rarray, ri, sarray, si, splitlist, k, v, rids, sids, rsarray, rsi

	-- get all rooms' list
	sql = "SELECT id, tag, name FROM groups WHERE sta = 55"
	_dbg(sql)

	rarray = {}
	res = db:execute(sql)
	if res ~= nil then
		i = 1
 		for r in rows(res) do 
 			rarray[i] = r["id"] or ""
			rarray[i+1] = r["tag"] or ""
			rarray[i+2] = r["name"] or ""
			_dbg(rarray[i] .. " " .. rarray[i+1] .. " " .. rarray[i+2])
			printtab(r)
			i = i + 3
		end
		res:close()
	end 

	-- get all scences' list
	sql = "SELECT id, tag, name, dids FROM groups WHERE sta = 44"
	_dbg(sql)
	sarray = {}
	res = db:execute(sql)
	if res ~= nil then
		i = 1
 		for r in rows(res) do 
 			sarray[i] = r["id"] or ""
			sarray[i+1] = r["tag"] or ""
			sarray[i+2] = r["name"] or ""
			sarray[i+3] = r["dids"] or "0"
			_dbg(sarray[i] .. " " .. sarray[i+1] .. " " .. sarray[i+2] .. " " .. sarray[i+3])
			printtab(r)
			i = i + 4
		end
		res:close()
	end

	-- get id - rids -sids
	if id ~= nil then
		sql = "SELECT * FROM timers WHERE id = " .. id
		_dbg(sql)
		res = db:execute(sql)
		if res ~= nil then
			for r in rows(res) do 
				rids = r["rids"] or ""
				sids = r["sids"] or ""
				rsarray = {}
				splitlist = {}
				string.gsub(rids, '[^,]+', function(w) table.insert(splitlist, w) end )
				i = 1
				for k, v in ipairs(splitlist) do
					rsarray[i] = v
					i = i + 2
				end
				splitlist = {}
				string.gsub(sids, '[^,]+', function(w) table.insert(splitlist, w) end )
				i = 2
				for k, v in ipairs(splitlist) do
					rsarray[i] = v
					-- si = 1
					-- while (sarray[si] ~= nil) do
					-- 	if tonumber(sarray[si]) == tonumber(v) then rsarray[i] = sarray[si+2] end
					-- 	si = si + 4
					-- end
					i = i + 2
				end
			end
			res:close()
		end
	end

	-- check every scence's dids if content param id
	i, ri, si = 1, 1, 1
	array = {}
	while (rarray[ri] ~= nil) do
		array[i] = rarray[ri]
		array[i+1] = rarray[ri+2]
		array[i+2] = "\""
		array[i+3] = ""
		while (sarray[si] ~= nil) do
			splitlist = {}
			string.gsub(sarray[si+3], '[^,]+', function(w) table.insert(splitlist, w) end ) 
			for k,v in ipairs(splitlist) do
				if tonumber(v) == tonumber(rarray[ri]) then 
					if si == 1 then
						array[i+2] = array[i+2] .. sarray[si+2]
					else
						array[i+2] = array[i+2] .. "\",\"" .. sarray[si+2]
					end
				end
			end
			si = si + 4
		end
		array[i+2] = array[i+2] .. "\""

		if rsarray ~= nil then
			rsi = 1
			while (rsarray[rsi] ~= nil) do
				if tonumber(rsarray[rsi]) == tonumber(array[i]) then array[i+3] = rsarray[rsi+1] end
				if tonumber(array[i+3]) == 0 then array[i+3] = "" end 
				rsi = rsi + 2
			end
		end

		_dbg(array[i] .. " " .. array[i+1] .. " " .. array[i+2] .. " " .. array[i+3])
		i = i + 4
		ri = ri + 3
	end

	db:close()
	env:close()
	return array
end

-- timers_loadaddschedule(self, 1)
function devices_loadelectrityanalyze(self)
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile)
	local sql, res, r, array, i

	sql = "SELECT id, name, addr, onh, offh, uenh, uenl, watt FROM devices"
	_dbg(sql)

	array = {}
	res = db:execute(sql)
	if res ~= nil then
		i = 1
 		for r in rows(res) do 
			array[i] = r["id"] or ""
			array[i+1] = r["name"] or ""
			array[i+2] = r["addr"] or ""
			array[i+3] = r["onh"] or "0"
			array[i+4] = r["lum"] or "0"
			array[i+5] = r["onoff"] or "0"
			array[i+6] = r["uenl"] or "0"
			array[i+7] = r["watt"] or "0"
			_dbg(array[i] .. ", " .. array[i+1] .. ", " .. array[i+2] .. ", " .. array[i+3] .. ", " .. array[i+4])
			_dbg(array[5] .. ", " .. array[i+6] .. ", " .. array[i+7])
			printtab(r)
			i = i + 8
		end
		res:close()
	end 

	db:close()
	env:close()
	return array
end

function devices_loadelectrityanalyzebyaddr(self, iaddr)
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile)
	local sql, res, r, array, i

	sql = "SELECT id, name, addr, onh, offh, uenh, uenl, watt FROM devices WHERE addr = "..iaddr
	_dbg(sql)

	array = {}
	res = db:execute(sql)
	if res ~= nil then
		i = 1
 		for r in rows(res) do 
			array[i] = r["id"] or ""
			array[i+1] = r["name"] or ""
			array[i+2] = r["addr"] or ""
			array[i+3] = r["onh"] or "0"
			array[i+4] = r["offh"] or "0"
			array[i+5] = r["uenh"] or "0"
			array[i+6] = r["uenl"] or "0"
			array[i+7] = r["watt"] or "0"
			-- _dbg(array[i] .. ", " .. array[i+1] .. ", " .. array[i+2] .. ", " .. array[i+3] .. ", " .. array[i+4])
			-- _dbg(array[5] .. ", " .. array[i+6] .. ", " .. array[i+7]
			printtab(r)
			i = i + 8
		end
		res:close()
	end 

	db:close()
	env:close()
	return array
end

function testtmpdb(self)
	local dbfiletmp = "/tmp/zgw.db"
	local env = qlite3.sqlite3()
	local db = env:connect(dbfiletmp)
	local sql, res, r, array, i

	sql = "SELECT id, name, addr, onh, offh, uenh, uenl, watt FROM devices"
	_dbg(sql)

	array = {}
	res = db:execute(sql)
	if res ~= nil then
		i = 1
 		for r in rows(res) do 
			array[i] = r["id"] or ""
			array[i+1] = r["name"] or ""
			array[i+2] = r["addr"] or ""
			array[i+3] = r["onh"] or "0"
			array[i+4] = r["lum"] or "0"
			array[i+5] = r["onoff"] or "0"
			array[i+6] = r["uenl"] or "0"
			array[i+7] = r["watt"] or "0"
			_dbg(array[i] .. ", " .. array[i+1] .. ", " .. array[i+2] .. ", " .. array[i+3] .. ", " .. array[i+4])
			_dbg(array[5] .. ", " .. array[i+6] .. ", " .. array[i+7])
			printtab(r)
			i = i + 8
		end
		res:close()
	end 

	db:close()
	env:close()
	return array
end

-- testtmpdb();