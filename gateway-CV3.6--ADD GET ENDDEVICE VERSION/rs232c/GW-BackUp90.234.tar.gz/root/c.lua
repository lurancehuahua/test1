local db = require "ttdb"
local serial  = require "ttserial"

local V_LEVEL = 101
local V_CCT = 10
local V_HUE = 100

local ADDR = 32949

function resetuen(self)
	serial:d_resetenergy(ADDR)
end
-- resetuen(self)

function loadElectrityAnalyzebyaddr(self)
	db:devices_loadelectrityanalyzebyaddr(ADDR)
end
-- loadElectrityAnalyzebyaddr(self)

function permitjoin(self)
	local seconds = 30
	serial:permitjoin(seconds)
	os.execute("sleep " .. seconds)
end
-- permitjoin(self)

function setlevel(self)
	local i, v
	for i, v in pairs(arg) do
		if i == 1 then V_LEVEL = v end
    	print(i, v)
	end
	serial:setlum(V_LEVEL)
end
-- setlevel(self)

function setcct(self)
	local i, v
	for i, v in pairs(arg) do
		if i == 1 then V_CCT = v end
    	print(i, v)
	end
	serial:setcct(V_CCT)
end
setcct(self)


function sethue(self)
	local i, v
	for i, v in pairs(arg) do
		if i == 1 then V_HUE = v end
    	print(i, v)
	end
	serial:sethue(V_HUE)
end
-- sethue(self)

function setonoff(self)
	local i, v
	local onf = 1
	for i, v in pairs(arg) do
		if i == 1 then onf = v end
    	print(i, v)
	end
	serial:setonoff(onf)
end
-- setonoff(self)

function testrgbw(self)
	local i, v
	local hue, saturation, colortemp, color = 1, 1, 1, 1

	for i, v in pairs(arg) do
		if i == 1 then hue = v end
		if i == 2 then saturation = v end
		if i == 3 then colortemp = v end
		if i == 4 then color = v end
    	print(i, v)
	end

	serial:testrgbw_sethue(hue)
	serial:testrgbw_setsaturation(saturation)
	serial:testrgbw_setcolortemp(colortemp)
	serial:testrgbw_setcolor(color)
end
-- testrgbw(self)
