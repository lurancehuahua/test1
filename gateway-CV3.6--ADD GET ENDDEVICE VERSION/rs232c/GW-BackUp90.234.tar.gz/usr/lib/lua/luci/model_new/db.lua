--Copyright (c) 2018 Greeble 
--Chenheng <heng.chen@scjz-led.com>
--ZGW sql V0.0.3 20171023

local require = require

-- local nxo = require "nixio"
-- local nfs = require "nixio.fs"
-- local sys = require "luci.sys"
-- local utl = require "luci.util"
-- local dsp = require "luci.dispatcher"
-- local ipc = require "luci.ip"
-- local http = require "luci.http"
-- local uci = require "luci.model.uci"
-- local lng = require "luci.i18n"
-- local jsc = require "luci.jsonc"
local qlite3 = require "luasql.sqlite3"

module "luci.model.db"

local dbfile = "/root/zgw.db"

function printtab(t)
    -- for k,v in pairs(t) do  
    --    --print(k, " = ", v)
    -- end  
end  

function _dbg(...)
    --print(...)
end

function rows(cur)  
    return function(cur)  
        local t = {}  
        if(nil ~= cur:fetch(t, 'a')) then return t  
        else return nil end
    end, cur 
end  

-- function xprinttab(self,t)  
-- 	printtab(t)
-- end  
  
-- function xrows(self,cur)  
-- 	return rows(cur)
-- end  

--delete a record by id
function del(t,id)  
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile) 

	db:setautocommit(false)
	sql = "DELETE FROM " .. t .. " " .. " WHERE id = " .. id
	_dbg(sql);
    res = db:execute(sql)
	db:commit() 
    _dbg(res)

	db:close()
	env:close()
	return res  
end    

--set state to db
function setsta(t,id,ista)  
	local env = qlite3.sqlite3()  
	local db = env:connect(dbfile)

	db:setautocommit(false)  
	sql = "UPDATE " .. t .. " SET sta = \'" .. ista .. "\' WHERE id = " .. id
	_dbg(sql)
    res = db:execute(sql)
	db:commit()
	_dbg(res)

	db:close()  
	env:close() 
	return res  
end  
 
--set name to db
function setname(t,id,iname) 
	local env = qlite3.sqlite3()  
	local db = env:connect(dbfile) 

	db:setautocommit(false)  
	sql = "UPDATE " .. t .. " SET name = \'" .. iname .. "\' WHERE id = " .. id
	_dbg(sql)
    res = db:execute(sql)
	db:commit()
	_dbg(res)

	db:close()  
	env:close() 
	return res  
end  

--set onoff ott to db
function setonoff(t,id,ionoff,iott)  
	local env = qlite3.sqlite3() 
	local db = env:connect(dbfile) 

	db:setautocommit(false)  
	sql = "UPDATE " .. t .. " SET onoff = " .. ionoff .. " , ott = " .. iott .. " WHERE id = " .. id
	_dbg(sql) 
    res = db:execute(sql)
	db:commit()
	_dbg(res)

	db:close()  
	env:close() 
	return res
end

function setonoffall(t, ionoff, iott)
	local env = qlite3.sqlite3() 
	local db = env:connect(dbfile) 

	db:setautocommit(false)  
	sql = "UPDATE " .. t .. " SET onoff = " .. ionoff .. " , ott = " .. iott
	_dbg(sql) 
    res = db:execute(sql)
	db:commit()
	_dbg(res)

	db:close()
	env:close()
	return res
end

--set lum ltt to db
function setlum(t,id,ilum,iltt)
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile) 

	db:setautocommit(false)
	sql = "UPDATE " .. t .. " SET lum = " .. ilum .. " , ltt = " .. iltt .. " WHERE id = " .. id
	_dbg(sql) 
    res = assert (db:execute(sql))
	db:commit()
	_dbg(res)

	db:close() 
	env:close()
	return res  
end
  
--set ct ctt to db
function setctt(t,id,ict,ictt)  
	local env = qlite3.sqlite3() 
	local db = env:connect(dbfile)

	db:setautocommit(false)  
	sql = "UPDATE " .. t .. " SET ct = " .. ict .. " , ctt = " .. ictt .. " WHERE id = " .. id
	_dbg(sql)
    res = db:execute(sql)
	db:commit()
	_dbg(res)

	db:close()  
	env:close() 
	return res  
end
  
--set hue sat htt to db
function sethue(t,id,ihue,isat,ihtt)  
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile)

	db:setautocommit(false)  
	sql = "UPDATE " .. t .. " SET hue = " .. ihue .. " , htt = " .. ihtt .. " , sat = " .. isat .. " WHERE id = " .. id
	_dbg(sql)
    res = db:execute(sql)
	db:commit()
	_dbg(res)

	db:close()
	env:close()
	return res  
end

--set tag to db
function settag(t,id,itag)  
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile) 

	db:setautocommit(false)  
	sql = "UPDATE " .. t .. " SET tag = \'" .. itag .. "\' WHERE id = " .. id
	_dbg(sql)
    res = db:execute(sql)
	db:commit()
	_dbg(res)

	db:close()  
	env:close() 
	return res  
end  

--get tag by id
function gettag(t,id)
	local env = qlite3.sqlite3()  
	local db = env:connect(dbfile)

	sql = "SELECT * FROM " .. t .. " WHERE id = " .. id
	_dbg(sql)
    res = db:execute(sql)
 	for r in rows(res) do
        tag = r["tag"]
		printtab(r)
	end 	
	_dbg('tag=',tag)

	res:close()
	db:close()
	env:close()
	return tag  
end

function getidbytag(t, itag)
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile)

	sql = "SELECT * FROM " .. t .. " WHERE tag = " .. itag
	_dbg(sql)
	res = db:execute(sql)
	for r in rows(res) do  
        id = r["id"]
		printtab(r)
	end
	_dbg('id=',id)

	res:close()
	db:close()
	env:close()
	return id
end

--get hue sat htt by id
function gethue(t,id)  
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile)  

	sql = "SELECT * FROM " .. t .. " WHERE id = " .. id
	_dbg(sql)
    res = db:execute(sql)
	
 	for r in rows(res) do  
        hue = r["hue"]
        sat = r["sat"]
        htt = r["htt"]
		printtab(r)
	end 	
	_dbg('hue=',hue)
	_dbg('sat=',sat)
	_dbg('htt=',htt)

	res:close()
	db:close()
	env:close()
	return hue , sat , htt  
end

--get ct ctt by id
function getctt(t,id)  
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile) 

	sql = "SELECT * FROM " .. t .. " WHERE id = " .. id
	_dbg(sql)
    res = db:execute(sql)
	
 	for r in rows(res) do  
        ct = r["ct"]
        ctt = r["ctt"]
		printtab(r) 
	end 	
	_dbg('ct = ',ct)
	_dbg('ctt = ',ctt)
	res:close() 
	db:close()
	env:close()
	return ct , ctt  
end

--get lum ltt by id
function getlum(t,id)
	local env = qlite3.sqlite3() 
	local db = env:connect(dbfile)

	sql = "SELECT * FROM " .. t .. " WHERE id = " .. id
	_dbg(sql)
    res = db:execute(sql)
	
 	for r in rows(res) do  
        lum = r["lum"] 
        ltt = r["ltt"]
		printtab(r)
	end 	
	_dbg('lum = ',lum)
	_dbg('ltt = ',ltt)

	res:close() 
	db:close()
	env:close()
	return lum , ltt  
end

--get onoff ott by id
function getonoff(t,id)
	local env = qlite3.sqlite3()  
	local db = env:connect(dbfile)

	sql = "SELECT * FROM " .. t .. " WHERE id = " .. id
	_dbg(sql)
    res = db:execute(sql)
	
 	for r in rows(res) do
        onoff = r["onoff"]
        ott = r["ott"]
		printtab(r)  
	end 	
	_dbg('onoff = ',onoff)
	_dbg('ott = ',ott)

	res:close()
	db:close()
	env:close()
	return onoff , ott  
end

--get name by id
function getname(t,id)
	local env = qlite3.sqlite3() 
	local db = env:connect(dbfile)

	sql = "SELECT * FROM " .. t .. " WHERE id = " .. id 
	_dbg(sql)
    res = db:execute(sql)
	
 	for r in rows(res) do  
        name = r["name"]
		printtab(r)  
	end 	
	_dbg('name = ',name)

	res:close()
	db:close()
	env:close()
	return name  
end

--get state by id
function getsta(t,id)
	local env = qlite3.sqlite3() 
	local db = env:connect(dbfile)  

	sql = "SELECT * FROM " .. t .. " WHERE id = " .. id
	_dbg(sql)
    res = db:execute(sql)
	
 	for r in rows(res) do  
        sta = r["sta"]
		printtab(r)
	end 	
	_dbg('sta = ',sta)

	res:close()
	db:close()
	env:close()
	return sta  
end

function getfirstid(t)
	local env = qlite3.sqlite3()  
	local db = env:connect(dbfile)
	local id

	sql = "SELECT * FROM " .. t
	_dbg(sql)
    res = db:execute(sql)
 	for r in rows(res) do
        id = r["id"]
		printtab(r)
		break
	end 	
	_dbg('id=',id)

	res:close()
	db:close()
	env:close()
	return id 
end

function getnextid(t, id)
	local env = qlite3.sqlite3()  
	local db = env:connect(dbfile)
	local idx, flag

	sql = "SELECT * FROM " .. t
	_dbg(sql)
    res = db:execute(sql)
 	for r in rows(res) do
        idx = r["id"]
		printtab(r)
		if flag ~= nil then break end
		if idx == id then flag = 1 end
	end 	
	_dbg('id=',id)

	res:close()
	db:close()
	env:close()
	return id 
end

-- ROOM OPs
--add a record and set tag name
function rooms_add(self,itag,iname)
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile)

	db:setautocommit(false)
	sql = "INSERT INTO rooms (tag,name) VALUES (" .. itag .. ",\'" .. iname .. "\')"
	_dbg(sql)
    res = db:execute(sql)
	db:commit()
    _dbg(res)

	db:close()
	env:close()
	return res  
end    

--delete a record by id
function rooms_del(self,id)  
    res = del('rooms',id)
	return res  
end    

--set name to db
function rooms_setname(self,id,iname)
	res = setname('rooms',id,iname)
	return res  
end  

--get name by id
function rooms_getname(self,id)
	return getname('rooms',id)
end

--set tag to db
function rooms_settag(self,id,itag)
	res = settag('rooms',id,itag)
	return res
end  

--get tag by id
function rooms_gettag(self,id)  
	return gettag('rooms',id)  
end

--set state to db
function rooms_setsta(self,id,ista)
	res = setsta('rooms',id,ista)
	return res  
end

--get state by id
function rooms_getsta(self,id)
	return getsta('rooms',id)
end

function rooms_getidbytag(self, itag)
	return getidbytag('rooms',itag)
end

function rooms_getfirstid(self)
	return getfirstid('rooms')
end

function rooms_getnextid(self, id)
	return getnextid('rooms', id)
end

--set dids to db
function rooms_setsids(self,id,isids)  
	local env = qlite3.sqlite3()  
	local db = env:connect(dbfile) 

	db:setautocommit(false)  
	sql = "UPDATE rooms SET sids = " .. isids .. " WHERE id = " .. id
	_dbg(sql)
    res = db:execute(sql)
	db:commit()
	_dbg(res)

	db:close()  
	env:close() 
	return res  
end  

--get dids by id
function rooms_getsids(self,id)  
	local env = qlite3.sqlite3();  
	local db = env:connect(dbfile);  

	sql = "SELECT * FROM rooms WHERE id = " .. id
	_dbg(sql)
    res = db:execute(sql)
 	for r in rows(res) do  
        sids = r["sids"]
		printtab(r)
	end 	
	_dbg('sids = ',sids)

	res:close()
	db:close()
	env:close()
	return sids  
end

-- SCENCE OPs
--add a record and set tag name
function scences_add(self,itag,iname)
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile)

	db:setautocommit(false);
	sql = "INSERT INTO scenes (tag,name) VALUES (" .. itag .. ",\'" .. iname .. "\')"
	_dbg(sql)
    res = db:execute(sql)
	db:commit()
    _dbg(res)
	db:close()
	env:close()
	return res
end    

--delete a record by id
function scences_del(self,id)
    res = del('scenes',id)
	return res  
end    

--set name to db
function scences_setname(self,id,iname)
	res = setname('scenes',id,iname)
	return res  
end  

--get name by id
function scences_getname(self,id)  
	return getname('scenes',id)
end

--set tag to db
function scences_settag(self,id,itag)
	res = settag('scenes',id,itag)
	return res  
end  

--get tag by id
function scences_gettag(self,id)
	return gettag('scenes',id)
end

function scences_getidbytag(self, itag)
	return getidbytag('scenes',itag)
end

--set dids to db
function scences_setgids(self,id,igids)
	local env = qlite3.sqlite3()  
	local db = env:connect(dbfile)  

	db:setautocommit(false)  
	sql = "UPDATE scenes SET gids = " .. igids .. " WHERE id = " .. id
	_dbg(sql)  
    res = db:execute(sql)
	db:commit()
	_dbg(res)

	db:close()  
	env:close() 
	return res  
end  

--get dids by id
function scences_getgids(self,id)  
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile) 

	sql = "SELECT * FROM scenes WHERE id = " .. id
	_dbg(sql)
    res = db:execute(sql)
 	for r in rows(res) do  
        gids = r["gids"]
		printtab(r) 
	end 	
	_dbg('gids = ',gids)

	res:close()
	db:close() 
	env:close()
	return gids  
end

-- GROUP OPs
--add a record and set tag name
function groups_add(self,itag,iname)
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile)

	db:setautocommit(false)
	sql = "INSERT INTO groups (tag,name) VALUES (" .. itag .. ",\'" .. iname .. "\')"
	_dbg(sql)
    res = db:execute(sql)
	db:commit()
    _dbg(res)

	db:close()
	env:close()
	return res  
end    

--delete a record by id
function groups_del(self,id)  
    res = del('groups',id)
	return res  
end    
 
--set name to db
function groups_setname(self,id,iname)  
	res = setname('groups',id,iname)
	return res  
end  

--get name by id
function groups_getname(self,id)
	return getname('groups',id)
end

--set tag to db
function groups_settag(self,id,itag)
	res = settag('groups',id,itag)
	return res  
end

--get tag by id
function groups_gettag(self,id)  
	return gettag('groups',id) 
end

--set all groups onoff ott to db
function groups_setonoffall(self,ionoff,iott)  
	res = setonoffall('groups',ionoff,iott)
	return res  
end

--set onoff ott to db
function groups_setonoff(self,id,ionoff,iott)  
	res = setonoff('groups',id,ionoff,iott)
	return res  
end

--get onoff ott by id
function groups_getonoff(self,id)  
	return getonoff('groups',id) 
end

--set lum ltt to db
function groups_setlum(self,id,ilum,iltt)  
	res = setlum('groups',id,ilum,iltt)
	return res  
end

--get lum ltt by id
function groups_getlum(self,id)  
	return getlum('groups',id)
end

--set ct ctt to db
function groups_setctt(self,id,ict,ictt)  
	res = setctt('groups',id,ict,ictt)
	return res  
end

--get ct ctt by id
function groups_getctt(self,id)  
	return getctt('groups',id)
end

--set hue hdir htt to db
function groups_sethue(self,id,ihue,isat,ihtt)  
	res = sethue('groups',id,ihue,isat,ihtt)
	return res  
end

--get hue hdir htt by id
function groups_gethue(self,id)  
	return gethue('groups',id)  
end

--set state to db
function groups_setsta(self,id,ista)  
	res = setsta('groups',id,ista)
	return res  
end

--get state by id
function groups_getsta(self,id)  
	return getsta('groups',id)
end

function groups_getidbytag(self, itag)
	return getidbytag('groups',itag)
end

--set dids to db
function groups_setdids(self,id,idids)
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile)

	db:setautocommit(false)  
	sql = "UPDATE groups SET dids = " .. idids .. " WHERE id = " .. id
	_dbg(sql)
    res = db:execute(sql)
	db:commit()
	_dbg(res)

	db:close()
	env:close()
	return res
end  

--get dids by id
function groups_getdids(self,id)
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile)

	sql = "SELECT * FROM groups WHERE id = " .. id
	_dbg(sql)
    res = db:execute(sql)
	for r in rows(res) do
        dids = r["dids"]
		printtab(r)
	end 	
	_dbg('dids = ',dids)

	res:close()
	db:close()
	env:close()
	return dids
end

--set sid to db
function groups_setsid(self,id,isid)
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile)

	db:setautocommit(false)
	sql = "UPDATE groups SET sid = " .. isid .. " WHERE id = " .. id
	_dbg(sql);
    res = db:execute(sql)
	db:commit()
	_dbg(res)

	db:close()  
	env:close()
	return res  
end  

--get sid by id
function groups_getsid(self,id)  
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile) 

	sql = "SELECT * FROM groups WHERE id = " .. id
	_dbg(sql);
    res = db:execute(sql)
 	for r in rows(res) do  
        sid = r["sid"]
		printtab(r)
	end 	
	_dbg('sid = ',sid)

	res:close() 
	db:close()
	env:close()
	return sid  
end

-- DEVICE OPs
--add a record and set tag mac
function devices_add(self,itag,imac)  
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile)

	db:setautocommit(false)
	sql = "INSERT INTO devices (tag,mac) VALUES (" .. itag .. "," .. imac .. ")"
	_dbg(sql)
    res = db:execute(sql)
	db:commit()
    _dbg(res)

	db:close()
	env:close()
	return res  
end    

--delete a record by id
function devices_del(self,id)  
    res = del('devices',id)
	return res  
end    

--set name to db
function devices_setname(self,id,iname)  
	res = setname('devices',id,iname)
	return res  
end

--get name by id
function devices_getname(self,id)
	return getname('devices',id)
end

--set hue sat htt to db
function devices_sethue(self,id,ihue,isat,ihtt)
	res = sethue('devices',id,ihue,isat,ihtt)
	return res  
end

--get hue sat htt by id
function devices_gethue(self,id)  
	return gethue('devices',id) 
end

--set state to db
function devices_setsta(self,id,ista)  
	res = setsta('devices',id,ista)
	return res  
end  

--get state by id
function devices_getsta(self,id)  
	return getsta('devices',id)
end

--set all devices onoff ott to db
function devices_setonoffall(self,id,ionoff,iott)  
	res = setonoffall('devices',id,ionoff,iott)
	return res
end

--set onoff ott to db
function devices_setonoff(self,id,ionoff,iott)  
	res = setonoff('devices',id,ionoff,iott)
	return res
end  

--get onoff ott by id
function devices_getonoff(self,id)  
	return getonoff('devices',id) 
end

--set lum ltt to db
function devices_setlum(self,id,ilum,iltt)  
	res = setlum('devices',id,ilum,iltt)
	return res  
end

--get lum ltt by id
function devices_getlum(self,id)  
	return getlum('devices',id) 
end

--set ct ctt to db
function devices_setctt(self,id,ict,ictt)  
	res = setctt('devices',id,ict,ictt)
	return res  
end

--get ct ctt by id
function devices_getctt(self,id)  
	return getctt('devices',id)
end

--set tag to db
function devices_settag(self,id,itag)  
	res = settag('devices',id,itag)
	return res  
end  

--get tag by id
function devices_gettag(self,id)  
	return gettag('devices',id)
end

function devices_getidbytag(self, itag)
	return getidbytag('devices',itag)
end

--set pos to db
function devices_setpos(self,id,ipos)  
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile) 

	db:setautocommit(false)  
	sql = "UPDATE devices SET pos = " .. ipos .. " WHERE id = " .. id
	_dbg(sql) 
    res = db:execute(sql)
	db:commit()
	_dbg(res)

	db:close() 
	env:close()
	return res  
end  

--get pos by id
function devices_getpos(self,id)  
	local env = qlite3.sqlite3() 
	local db = env:connect(dbfile)

	sql = "SELECT * FROM devices WHERE id = " .. id
	_dbg(sql)
    res = db:execute(sql)
 	for r in rows(res) do  
        pos = r["pos"]
		printtab(r)
	end 	
	_dbg('pos = ',pos)

	res:close()
	db:close()
	env:close()
	return pos  
end