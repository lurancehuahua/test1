-- Copyright 2008 Steven Barth <steven@midlink.org>
-- Copyright 2011-2015 Jo-Philipp Wich <jow@openwrt.org>
-- Licensed to the public under the Apache License 2.0.
module("luci.controller.admin.zigbee", package.seeall)
local   http = require "luci.http"
local   jres = require "luci.model.jsonresponse"

local	txt = ""
local	sta = "{\""
local	en = "\"}"
local	nen = "}"
local	mop = "\":\""
local	dop = "\",\""
local	nmop = "\":"
local	ndop = ",\""
local   msgHeadGMAC = "\"GMAC"..mop.."123456789".."\""

function index()
	local fs = require "nixio.fs"

	entry({"admin", "zigbee"}, alias("admin", "zigbee", "room"), _("ZBweb"), 30).index = true

	entry({"admin", "zigbee", "room"}, template("admin_zigbee/room"), _("room"), 1)
	entry({"admin", "zigbee", "room_a"}, template("admin_zigbee/room_a"),nil)
	entry({"admin", "zigbee", "room", "jsonresponse"}, call("jsonresponse"), nil)

	-- scene label page --
	entry({"admin", "zigbee", "scene"}, template("admin_zigbee/scene"),nil)
	entry({"admin", "zigbee", "scene_modesetting"}, template("admin_zigbee/scene_modesetting"),nil)
	entry({"admin", "zigbee", "scene_objmodelist"}, template("admin_zigbee/scene_objmodelist"),nil)
	entry({"admin", "zigbee", "scene_objmodeadjust"}, template("admin_zigbee/scene_objmodeadjust"),nil)
	entry({"admin", "zigbee", "scene_objaddmode"}, template("admin_zigbee/scene_objaddmode"),nil)
	entry({"admin", "zigbee", "scene_schedule"}, template("admin_zigbee/scene_schedule"),nil)
	entry({"admin", "zigbee", "scene_adjustschedule"}, template("admin_zigbee/scene_adjustschedule"),nil)
	entry({"admin", "zigbee", "scene_adjustscheduleone"}, template("admin_zigbee/scene_adjustscheduleone"),nil)
	entry({"admin", "zigbee", "scene_analyze"}, template("admin_zigbee/scene_analyze"),nil)

	-- analyze label page --
	entry({"admin", "zigbee", "analyze"}, template("admin_zigbee/analyze"), nil)
	entry({"admin", "zigbee", "analysis_electricity"}, template("admin_zigbee/analysis_electricity"), nil)
	entry({"admin", "zigbee", "analysis_baddevice"}, template("admin_zigbee/analysis_baddevice"), nil)
	entry({"admin", "zigbee", "analysis_usedtime"}, template("admin_zigbee/analysis_usedtime"), nil)
	
	-- setting child : device setting --
	entry({"admin", "zigbee", "setting"}, template("admin_zigbee/setting"), nil)
	entry({"admin", "zigbee", "setting_gatewaylist"}, template("admin_zigbee/setting_gatewaylist"), nil)
	entry({"admin", "zigbee", "setting_addgateway"}, template("admin_zigbee/setting_addgateway"), nil)
	entry({"admin", "zigbee", "setting_devicelist"}, template("admin_zigbee/setting_devicelist"), nil)
	entry({"admin", "zigbee", "setting_adddevice"}, template("admin_zigbee/setting_adddevice"), nil)

	-- setting child: group setting --
	entry({"admin", "zigbee", "setting_grouplist"}, template("admin_zigbee/setting_grouplist"), nil)
	entry({"admin", "zigbee", "setting_addgroup"}, template("admin_zigbee/setting_addgroup"), nil)
	entry({"admin", "zigbee", "setting_objgroup"}, template("admin_zigbee/setting_objgroup"), nil)

	-- setting child: room setting
	entry({"admin", "zigbee", "setting_roomlist"}, template("admin_zigbee/setting_roomlist"), nil)
	entry({"admin", "zigbee", "setting_addroom"}, template("admin_zigbee/setting_addroom"), nil)
	entry({"admin", "zigbee", "setting_objroom"}, template("admin_zigbee/setting_objroom"), nil)
	entry({"admin", "zigbee", "setting_roomicon"}, template("admin_zigbee/setting_roomicon"), nil)

	-- setting child: room accessories
	entry({"admin", "zigbee", "setting_accessories"}, template("admin_zigbee/setting_accessories"), nil)
	entry({"admin", "zigbee", "setting_controll"}, template("admin_zigbee/setting_controll"), nil)
	entry({"admin", "zigbee", "setting_controllsix"}, template("admin_zigbee/setting_controllsix"), nil)

	-- setting child: room device update
	entry({"admin", "zigbee", "setting_deviceupdate"}, template("admin_zigbee/setting_deviceupdate"), nil)
	entry({"admin", "zigbee", "setting", "devctlone"}, template("admin_zigbee/devctlone"), nil)
	entry({"admin", "zigbee", "test_function"}, template("admin_zigbee/test_function"), nil)
	entry({"admin", "zigbee", "productDemo"}, template("admin_zigbee/productDemo"), nil)

	-- setting child: room about
	entry({"admin", "zigbee", "setting_about"}, template("admin_zigbee/setting_about"), nil)
	entry({"admin", "zigbee", "setting_aboutfunction"}, template("admin_zigbee/setting_aboutfunction"), nil)
	entry({"admin", "zigbee", "setting_aboutcopyright"}, template("admin_zigbee/setting_aboutcopyright"), nil)
	entry({"admin", "zigbee", "setting_aboutupdate"}, template("admin_zigbee/setting_aboutupdate"), nil)

	entry({"admin", "zigbee", "setting", "setjump"}, call("setjump"), nil)
	entry({"admin", "zigbee", "setting", "devctlone"}, template("admin_zigbee/devctlone"), nil)

	-- business web html
	entry({"admin", "zigbee", "bs_login"}, template("admin_zigbee/bs_login"),nil)
	entry({"admin", "zigbee", "bs_home"}, template("admin_zigbee/bs_home"),nil)
	entry({"admin", "zigbee", "bs_lightcontrol"}, template("admin_zigbee/bs_lightcontrol"),nil)
	entry({"admin", "zigbee", "bs_lightcontrol_child1"}, template("admin_zigbee/bs_lightcontrol_child1"),nil)
	entry({"admin", "zigbee", "bs_modesetting"}, template("admin_zigbee/bs_modesetting"),nil)
	entry({"admin", "zigbee", "bs_modesetting_add"}, template("admin_zigbee/bs_modesetting_add"),nil)
	entry({"admin", "zigbee", "bs_modesetting_adjust"}, template("admin_zigbee/bs_modesetting_adjust"),nil)
	entry({"admin", "zigbee", "bs_modesetting_list"}, template("admin_zigbee/bs_modesetting_list"),nil)
	entry({"admin", "zigbee", "bs_sceneschedule"}, template("admin_zigbee/bs_sceneschedule"),nil)
	entry({"admin", "zigbee", "bs_sceneschedule_adjust"}, template("admin_zigbee/bs_sceneschedule_adjust"),nil)
	entry({"admin", "zigbee", "bs_electricity_analysis"}, template("admin_zigbee/bs_electricity_analysis"),nil)
	entry({"admin", "zigbee", "bs_faultdetect"}, template("admin_zigbee/bs_faultdetect"),nil)
	entry({"admin", "zigbee", "bs_usedtime"}, template("admin_zigbee/bs_usedtime"),nil)
	entry({"admin", "zigbee", "bs_devicemanage"}, template("admin_zigbee/bs_devicemanage"),nil)
	entry({"admin", "zigbee", "bs_devicemanage_add"}, template("admin_zigbee/bs_devicemanage_add"),nil)
	entry({"admin", "zigbee", "bs_devicemanage_adjust"}, template("admin_zigbee/bs_devicemanage_adjust"),nil)
	entry({"admin", "zigbee", "bs_roommanage"}, template("admin_zigbee/bs_roommanage"),nil)
	entry({"admin", "zigbee", "bs_roomadd"}, template("admin_zigbee/bs_roomadd"),nil)
	entry({"admin", "zigbee", "bs_room_adjust"}, template("admin_zigbee/bs_room_adjust"),nil)
	entry({"admin", "zigbee", "bs_roomgroup_add"}, template("admin_zigbee/bs_roomgroup_add"),nil)
	entry({"admin", "zigbee", "bs_roomgroup_adjust"}, template("admin_zigbee/bs_roomgroup_adjust"),nil)
	entry({"admin", "zigbee", "bs_accessories_list"}, template("admin_zigbee/bs_accessories_list"),nil)
	entry({"admin", "zigbee", "bs_accessories_configure"}, template("admin_zigbee/bs_accessories_configure"),nil)

end


function snd2client(...)
	print("Content-Type: text/plain\n")
	print(...)
end

function jsonresponse()
	-- local http = require "luci.http"
	-- local jres = require "luci.model.jsonresponse"

	txt = ""
	sta = "{\""
	en = "\"}"
	nen = "}"
	mop = "\":\""
	dop = "\",\""
	nmop = "\":"
	ndop = ",\""

	local msgHeadGMAC = "\"GMAC"..mop.."123456789".."\""

	-- response JSON Date
	local loadRoom = tonumber(http.formvalue("loadRoom"))
	-------------------------    response to client message     -----------------------------------
	local allRoom = tonumber(http.formvalue("allRoom"))

	local groupNum = tonumber(http.formvalue("groupNum"))
	local roomSwitch = tonumber(http.formvalue("roomSwitch"))
	local roomLight = tonumber(http.formvalue("roomLight"))
	local roomModeName = http.formvalue("roomModeName")

	local deviceAddress = http.formvalue("deviceAddress")
	local deviceSwitch = tonumber(http.formvalue("deviceSwitch"))
	local deviceIdentify = tonumber(http.formvalue("deviceIdentify"))
	
	local slideLevel = tonumber(http.formvalue("slideLevel"))
	local slideTemp = tonumber(http.formvalue("slideTemp"))
	local slideColor = tonumber(http.formvalue("slideColor"))

	local groupNumList = http.formvalue("groupNumList")
	local sceneSwitch = tonumber(http.formvalue("sceneSwitch"))
	local sceneGroupNum = tonumber(http.formvalue("sceneGroupNum"))
	local addSceneName = http.formvalue("addSceneName")
	local addSceneSave = tonumber(http.formvalue("addSceneSave"))
	local addSceneNameOrg = http.formvalue("addSceneNameOrg")

	local delDevice = http.formvalue("delDevice")
	local settingRoomList = tonumber(http.formvalue("settingRoomList"))
	local settingRoomGN = tonumber(http.formvalue("settingRoomGN"))
	local delRoom = http.formvalue("delRoom")
	local delUserMode = http.formvalue("delUserMode")

	local addRoomSwitch = tonumber(http.formvalue("addRoomSwitch"))
	local devList = http.formvalue("devList")
	local addRoomSlideFlag = tonumber(http.formvalue("addRoomSlideFlag"))
	local selectDeviceFlag = tonumber(http.formvalue("selectDeviceFlag"))
	local saveRoomDateFlag = tonumber(http.formvalue("saveRoomDateFlag"))
	local devAddr = http.formvalue("devAddr")
	local addRoomName = http.formvalue("addRoomName")
	local addRoomIcon = tonumber(http.formvalue("addRoomIcon"))
	local roomOrgName = http.formvalue("roomOrgName")

	local loadUpdateDev = tonumber(http.formvalue("loadUpdateDev"))
	local updateDevList = http.formvalue("updateDevList")
	
	local checkAddSceneName = http.formvalue("checkAddSceneName")

	local devRename = tonumber(http.formvalue("devRename"))
	local devAddrList = http.formvalue("devAddrList")
	local devNameList = http.formvalue("devNameList")

	local addRoomNameCheck = http.formvalue("addRoomNameCheck")
	local CTL1 = http.formvalue("CTL1")
	local CTL2 = http.formvalue("CTL2")
	local CTL3 = http.formvalue("CTL3")
	local CTL4 = http.formvalue("CTL4")
	local CTL5 = http.formvalue("CTL5")
	local CTL6 = http.formvalue("CTL6")
	local loadRoomChild = tonumber(http.formvalue("loadRoomChild"))
	local loadScene = tonumber(http.formvalue("loadScene"))
	local loadModeAdjust = http.formvalue("loadModeAdjust")
	local loadAddScene = tonumber(http.formvalue("loadAddScene"))
	local loadDeviceList  = tonumber(http.formvalue("loadDeviceList"))
	local ctlNetStatus  = tonumber(http.formvalue("ctlNetStatus"))
	local newDeviceList = tonumber(http.formvalue("newDeviceList"))
	local loadAddRoom = tonumber(http.formvalue("loadAddRoom"))
	local loadRoomAdjust = tonumber(http.formvalue("loadRoomAdjust"))
	local loadAccessories = tonumber(http.formvalue("loadAccessories"))
	local loadControll = http.formvalue("loadControll")

	local threeSlideFlag = tonumber(http.formvalue("threeSlideFlag"))
	local switchONF = tonumber(http.formvalue("switchONF"))

	local loadSceneSchedule = tonumber(http.formvalue("loadSceneSchedule"))

	local scheduleId = tonumber(http.formvalue("scheduleId"))
	local CTLscheduleId = tonumber(http.formvalue("CTLscheduleId"))
	local scheID = tonumber(http.formvalue("scheID"))
	local scheTime = http.formvalue("scheTime")
	local LabelName = http.formvalue("LabelName")
	local scheRepeat = http.formvalue("scheRepeat")
	local roomGNList = http.formvalue("roomGNList")
	local sceneList = http.formvalue("sceneList")
	local delSchedule = tonumber(http.formvalue("delSchedule"))
	local clientSystemTime = http.formvalue("clientSystemTime")

	local testAloneColorR = tonumber(http.formvalue("testAloneColorR"))
	local testAloneColorG = tonumber(http.formvalue("testAloneColorG"))
	local testAloneColorB = tonumber(http.formvalue("testAloneColorB"))
	local testAloneColorW = tonumber(http.formvalue("testAloneColorW"))

	local MH = tonumber(http.formvalue("MH"))

	-- test Electricity page
	local testLevelElectricity = tonumber(http.formvalue("testLevelElectricity"))
	local testTempElectricity = tonumber(http.formvalue("testTempElectricity"))
	local testColorElectricity = tonumber(http.formvalue("testColorElectricity"))
	if (testLevelElectricity ~= nil) then
		txt = jres:b_setLum(testLevelElectricity)
	elseif (testTempElectricity ~= nil) then
		txt = jres:b_setCct(testTempElectricity)
	elseif (testColorElectricity ~= nil) then
		txt = jres:b_setHue(testColorElectricity)
	end


	if (testAloneColorR ~= nil) then
		jres:testrgbw_cr(testAloneColorR)
		txt = txt.." R:"..testAloneColorR
	end
	if (testAloneColorG ~= nil) then
		jres:testrgbw_cg(testAloneColorG)
		txt = txt.." G:"..testAloneColorG
	end
	if (testAloneColorB ~= nil) then
		jres:testrgbw_cb(testAloneColorB)
		txt = txt.." B:"..testAloneColorB
	end
	if (testAloneColorW ~= nil) then
		jres:testrgbw_cw(testAloneColorW)
		txt = txt.." W:"..testAloneColorW
	end

	if (MH ~= nil) then
		if (MH == 50) then txt = jres:controllScheduleONF(scheduleId, switchONF) -- controll schedule on/off
		elseif (MH == 51) then txt = jres:loadAddSchedulePage() -- load add schedule page
		elseif (MH == 52) then txt = jres:loadModificationSchedulePage(CTLscheduleId) -- load modification schedule page
		elseif (MH == 53) then txt = jres:saveSchedule(scheID, scheTime, LabelName, scheRepeat, roomGNList, sceneList) -- save schedule
		elseif (MH == 54) then txt = jres:deleteSchedule(delSchedule) -- delete schedule
		elseif (MH == 55) then txt = jres:loadAccessories() -- load Accessories list
		elseif (MH == 56) then txt = jres:loadAccessoriesPage(loadControll) -- load accessories page
		elseif (MH == 57) then txt = jres:saveControllDate() -- save controll date
		elseif (MH == 58) then txt = jres:loadDeviceSoftwareUpdatePage() -- load device sofe update page
		elseif (MH == 59) then txt = jres:updateDevice(updateDevList) -- update device
		elseif (MH == 60) then txt = jres:loadElectrityAnalyze() -- load Electrity Analyze
		elseif (MH == 61) then txt = jres:setSystemTime(clientSystemTime)
	    elseif (MH == 62) then txt = os.date("%a, %d %b %Y %X GMT", os.time())


		elseif (MH == 70) then txt = jres:bus_getHomepageData()
		elseif (MH == 71) then txt = jres:bus_loadGatewayList()
		elseif (MH == 72) then txt = jres:bus_loadRoomList()
		elseif (MH == 73) then local delRoomId = http.formvalue("delRoomId") txt = jres:bus_delRoom(delRoomId)
		elseif (MH == 74) then
			local gwMAC = http.formvalue("gwMAC")
			if (gwMAC ~= nil) then
				txt = jres:bus_loadDeviceList()
			end

		elseif (MH == 75) then
			local groupName = http.formvalue("groupName")
			local devList = http.formvalue("devList")
			txt = jres:bus_addGroup(groupName, devList)

		elseif (MH == 76) then txt = jres:bus_loadGroupInfo()

		elseif (MH == 77) then 
			local iconNum = tonumber(http.formvalue("iconNum"))
			local roomNA = http.formvalue("roomNA")
			local desp = http.formvalue("desp")
			local groupList = http.formvalue("groupList")
			txt = jres:bus_addRoom(iconNum, roomNA, desp, groupList)

		elseif (MH == 78) then 
			local roomId = tonumber(http.formvalue("roomId"))
			txt = jres:bus_loadRoomModeList(roomId)

		elseif (MH == 79) then 
			local delRoomId = tonumber(http.formvalue("delRoomId"))
			local delModeId = tonumber(http.formvalue("delModeId"))
			txt = jres:bus_delRoomMode(delRoomId, delModeId)

		elseif (MH == 80) then 
			local roomId = tonumber(http.formvalue("roomId"))
			txt = jres:bus_loadRoomGroupInfo(roomId)

		elseif (MH == 81) then 
			local GID = tonumber(http.formvalue("GID"))
			local SW = tonumber(http.formvalue("SW"))
			txt = jres:bus_ctrlOnoff(GID, SW)

		elseif (MH == 82) then 
			local roomId = tonumber(http.formvalue("roomId"))
			local sceneNA = http.formvalue("sceneNA")
			local SWL = http.formvalue("SWL")
			local DIML = http.formvalue("DIML")
			local CCTL = http.formvalue("CCTL")
			local RGBL = http.formvalue("RGBL")
			txt = jres:bus_addRoomMode(roomId, sceneNA, SWL, DIML, CCTL, RGBL)

		elseif (MH == 83) then 
			txt = jres:bus_loadRoomInfo()

		elseif (MH == 84) then 
			local roomId = tonumber(http.formvalue("roomId"))
			local sceneNA = http.formvalue("sceneNA")
			txt = jres:bus_loadRoomGroupListAndModeList(roomId, sceneNA)

		elseif (MH == 85) then 
			local GID = tonumber(http.formvalue("GID"))
			local DIM = tonumber(http.formvalue("DIM"))
			local CCT = tonumber(http.formvalue("CCT"))
			local RGB = tonumber(http.formvalue("RGB"))
			txt = jres:bus_ctrlGroup(GID, DIM, CCT, RGB)

		elseif (MH == 86) then
			-- start or stop object schedule function API
			local SW = tonumber(http.formvalue("SW"))
			local GID = tonumber(http.formvalue("GID"))
			txt = "MH="..MH.." GID="..GID.." SW="..SW

		elseif (MH == 87) then
			txt = sta.."RML".."\":["
			txt = txt..sta.."NA"..mop.."1F Bright"..dop.."ID"..mop.."12"..dop.."IC"..nmop.."21"..ndop.."REP"..mop..",1,2,3"..dop.."SW"..nmop.."1"..nen
			txt = txt..","..sta.."NA"..mop.."2F Bright"..dop.."ID"..mop.."13"..dop.."IC"..nmop.."22"..ndop.."REP"..mop..",1,2,3,4,5"..dop.."SW"..nmop.."0"..nen
			txt = txt..","..sta.."NA"..mop.."3F Bright"..dop.."ID"..mop.."14"..dop.."IC"..nmop.."23"..ndop.."REP"..mop..",6,7"..dop.."SW"..nmop.."1"..nen
			txt = txt..","..sta.."NA"..mop.."4F Bright"..dop.."ID"..mop.."52"..dop.."IC"..nmop.."24"..ndop.."REP"..mop..",1,2,3,4,5,6,7"..dop.."SW"..nmop.."0"..nen
			txt = txt.."]}"

		elseif (MH == 88) then
			txt = sta.."SCHE".."\":["
			txt = txt..sta.."NA"..mop.."Work"..dop.."ID"..mop.."12"..dop.."TM"..mop.."09:00:00"..dop.."ASE"..mop.."High Light"..dop.."SW"..nmop.."1"..nen
			txt = txt..","..sta.."NA"..mop.."Lunch break"..dop.."ID"..mop.."13"..dop.."TM"..mop.."12:00:00"..dop.."ASE"..mop.."Rest"..dop.."SW"..nmop.."0"..nen
			txt = txt..","..sta.."NA"..mop.."Meeting"..dop.."ID"..mop.."14"..dop.."TM"..mop.."13:00:00"..dop.."ASE"..mop.."Projection"..dop.."SW"..nmop.."1"..nen
			txt = txt..","..sta.."NA"..mop.."After work"..dop.."ID"..mop.."15"..dop.."TM"..mop.."18:00:00"..dop.."ASE"..mop.."After work"..dop.."SW"..nmop.."0"..nen
			txt = txt.."],"
			txt = txt.."\"".."SEG".."\":[\"".."High Light"..dop.."Rest"..dop.."Projection"..dop.."After work".."\"]"
			txt = txt.."}"

		elseif (MH == 89) then
			-- delete room schedule function API
			local roomId = http.formvalue("roomId")
			local scheduleId = http.formvalue("scheduleId")
			txt = "MH="..MH.." roomId="..roomId.." scheduleId="..scheduleId

		elseif (MH == 90) then
			-- save room schedule adjust function API
			local roomId = http.formvalue("roomId")
			local scheduleIdList = http.formvalue("scheduleIdList")
			local timeList = http.formvalue("timeList")
			local nameList = decodeURI(http.formvalue("nameList"))
			local sceneList = decodeURI(http.formvalue("sceneList"))
			local switchList = http.formvalue("switchList")
			local repeatList = http.formvalue("repeatList")
			txt = "roomId="..roomId.." scheduleIdList="..scheduleIdList.." timeList="..timeList
			txt = txt.."nameList="..nameList.." sceneList="..sceneList.." switchList="..switchList.." repeatList="..repeatList

		elseif (MH == 91) then
			local roomId = tonumber(http.formvalue("roomId"))
			local sceneNA = http.formvalue("sceneNA")
			txt = jres:bus_loadRoomGroupListAndModeList_Ctrl(roomId, sceneNA)

		elseif (MH == 92) then
			local roomId = http.formvalue("roomId")
			local scheduleId = http.formvalue("scheduleId")
			local SW = http.formvalue("SW")
			txt = "MH="..MH.." roomId="..roomId.." scheduleId="..scheduleId.." SW="..SW

		elseif (MH == 93) then
			local GID = http.formvalue("GID")
			txt = "{"
			txt = txt.."\"NA"..mop.."1F Office"..dop.."DES"..mop.."1F"..dop.."IC"..nmop.."21"..",\"".."SGPL".."\":[\"".."12"..dop.."13".."\"],"
			txt = txt.."\"GPL\":["
			txt = txt..sta.."NA"..mop.."CCT Group"..dop.."ID"..mop.."12"..dop.."CU"..nmop.."2"..nen
			txt = txt..","..sta.."NA"..mop.."RGB Group"..dop.."ID"..mop.."13"..dop.."CU"..nmop.."3"..nen
			txt = txt..","..sta.."NA"..mop.."DIM Group"..dop.."ID"..mop.."14"..dop.."CU"..nmop.."2"..nen
			txt = txt.."]}"

		elseif (MH == 94) then
			local iconNum = tonumber(http.formvalue("iconNum"))
			local roomNA = http.formvalue("roomNA")
			local desp = http.formvalue("desp")
			local groupList = http.formvalue("groupList")

			txt = "iconNum="..iconNum.." roomNA="..roomNA.." desp="..desp.." groupList="..groupList


		elseif (MH == 95) then
			local groupId = http.formvalue("groupId")
			txt = sta.."NA"..mop.."CCT Group"..dop.."GPL".."\":[\"".."1226"..dop.."1345".."\"]"
			txt = txt..",".."\"MAC"..mop.."12:5F:8B:4E:1A:52:6C"..dop.."GGPL".."\":["
			txt = txt..sta.."NA"..mop.."CCT Group"..dop.."TY"..nmop.."63"..ndop.."AD"..mop.."1226"..en
			txt = txt..","..sta.."NA"..mop.."RGB Group"..dop.."TY"..nmop.."64"..ndop.."AD"..mop.."1345"..en
			txt = txt..","..sta.."NA"..mop.."Dim Group"..dop.."TY"..nmop.."62"..ndop.."AD"..mop.."1486"..en
			txt = txt.."]}"

		elseif (MH == 96) then
			local groupId = http.formvalue("groupId")
			local groupName = decodeURI(http.formvalue("groupName"))
			local devList = http.formvalue("devList")

			txt = "MH="..MH.." groupId="..groupId.." groupName="..groupName.." devList="..devList

		elseif (MH == 97) then
			local start = http.formvalue("start")
			local stop = http.formvalue("stop")
			local roomIdList = http.formvalue("roomIdList")

			txt = sta.."NAL".."\":[\"".."1F office"..dop.."2F office".."\"]"..","
			txt = txt.."\"ROWU\":[".."1"..",".."2"..",".."3"..",".."4"..",".."5".."]"..","
			txt = txt.."\"RMD\":["..sta.."data".."\":[".."15"..",".."13"..",".."14"..",".."16"..",".."17".."]}"
			txt = txt..","..sta.."data".."\":[".."21"..",".."23"..",".."25"..",".."22"..",".."20".."]}"
			txt = txt.."],".."\"ARMD\""..":[".."36"..",".."36"..",".."39"..",".."38"..",".."37"
			txt = txt.."]}"

		elseif (MH == 98) then
			local roomIdList = http.formvalue("roomIdList")

			txt = sta.."AND".."\":[".."50"..",".."70"..",".."90"..",".."120"..",".."150"..",".."200"..",".."220"..",".."170"..",".."80"..",".."30".."],"
			txt = txt.."\"RGPL\":["
			txt = txt..sta.."RNA"..mop.."1F Office"..dop.."ADL".."\":[\"".."1201"..dop.."1202"..dop.."1203".."\"],"
			txt = txt.."\"NAL\":[\"".."RGB Light1"..dop.."RGB Light2"..dop.."CCT Light3".."\"],".."\"USTL\":[".."650"..",".."1225"..",".."3256".."]}"
			txt = txt..","..sta.."RNA"..mop.."2F Meeting"..dop.."ADL".."\":[\"".."2205"..dop.."2206"..dop.."2207".."\"],"
			txt = txt.."\"NAL\":[\"".."DIM Light1"..dop.."DIM Light2"..dop.."ONF Light3".."\"],".."\"USTL\":[".."1500"..",".."750"..",".."5210".."]}"
			txt = txt.."]}"

		elseif (MH == 99) then
			local zbgMac = http.formvalue("zbgMac")

			txt = sta.."ACL\":["
			txt = txt..sta.."NA"..mop.."office 86box"..dop.."IC"..nmop.."71"..ndop.."AD"..mop.."1226"..en
			txt = txt..","..sta.."NA"..mop.."meeting 86box"..dop.."IC"..nmop.."71"..ndop.."AD"..mop.."8655"..en
			txt = txt.."]}"

		elseif (MH == 100) then
			local zbgMac = http.formvalue("zbgMac")

			txt = sta.."RML\":["
			txt = txt..sta.."NA"..mop.."office"..dop.."IC"..nmop.."25"..ndop.."RID"..mop.."216"..en
			txt = txt..","..sta.."NA"..mop.."Meeting"..dop.."IC"..nmop.."23"..ndop.."RID"..mop.."216"..en.."]"
			txt = txt..",\"BTN\":[\"".."High Light"..dop.."Not set"..dop.."Not set".."\"]"
			txt = txt.."}"


		elseif (MH == 101) then
			local roomId = http.formvalue("roomId")
			local sceneId = http.formvalue("sceneId")
			local devAddr = http.formvalue("devAddr")
			local btn = http.formvalue("btn")

			txt = "1"


		elseif (MH == 1001 ) then
			local openNetTime = http.formvalue("OPN")
			jres:openNetworkTime(openNetTime)	
			txt = "{"..msgHeadGMAC..",".."\"STA\":".."3"..nen

		elseif (MH == 1002) then
			txt = "{"..msgHeadGMAC..",".."\"MID"..mop.."910D"..en

		elseif (MH == 1003) then
			txt = "{"..msgHeadGMAC..","..jres:requestDeviceList()

		elseif (MH == 1004) then
			local devAddr = http.formvalue("DEVA")
			jres:deviceIdentify(devAddr, 3)
			txt = "{"..msgHeadGMAC..",".."\"STA\":".."3"..nen

		elseif (MH == 1005) then
			local devAddr = http.formvalue("DEVA")
			
			txt = "{"..msgHeadGMAC..","..jres:cld_delDevice(devAddr)

		elseif (MH == 1006) then
			local groupNum = tonumber(http.formvalue("GN"))
			local devList = http.formvalue("DEVAL")
			local tm  = tonumber(http.formvalue("TM"))
			txt = "{"..msgHeadGMAC..","..jres:cld_add_or_update_group(groupNum, devList, tm)

		elseif (MH == 1007) then
			local groupNum = tonumber(http.formvalue("GN"))
			txt = "{"..msgHeadGMAC..","..jres:cld_delete_group(groupNum)

		elseif (MH == 1008) then
			local groupNum = tonumber(http.formvalue("GN"))
			local devList = http.formvalue("DEVAL")
			local tm  = tonumber(http.formvalue("TM"))
			txt = "{"..msgHeadGMAC..","..jres:cld_update_group(groupNum, devList, tm)

		elseif (MH == 1009) then
			local groupNum = tonumber(http.formvalue("GN"))
			local onf = tonumber(http.formvalue("ONF"))
			local lum = tonumber(http.formvalue("LUM"))
			local cct = tonumber(http.formvalue("CCT"))
			local rgb = tonumber(http.formvalue("RGB"))
			local tm  = tonumber(http.formvalue("TM"))
			txt = "{"..msgHeadGMAC..","..jres:cld_ctlgroup_parameter( groupNum, onf, lum, cct, rgb, tm )

		elseif (MH == 1011) then
			local groupNum = tonumber(http.formvalue("GN"))
			txt = "{"..msgHeadGMAC..","..jres:groupIdentify(groupNum, 3)

		elseif (MH == 1012) then
			local groupNum = tonumber(http.formvalue("GN"))
			local devList = http.formvalue("DEVAL")
			local tid = http.formvalue("TID")
			txt = "{"..msgHeadGMAC..","..jres:cld_add_group_task(groupNum, devList, tid)

		elseif (MH == 1013) then
			local tid = http.formvalue("TID")
			local gid = tonumber(http.formvalue("GN"))
			txt = "{"..msgHeadGMAC..","..jres:cld_delete_group_task(tid, gid)

		elseif (MH == 1014) then
			local tid = http.formvalue("TID")
			txt = "{"..msgHeadGMAC..","..jres:cld_delete_task(tid)

		elseif (MH == 1015) then
			local tid = http.formvalue("TID")
			txt = "{"..msgHeadGMAC..","..jres:cld_get_task_status(tid)

		elseif (MH == 1016) then
			local tid = http.formvalue("TID")
			local sta = tonumber(http.formvalue("STA"))
			txt = "{"..msgHeadGMAC..","..jres:cld_updata_group_task(tid, sta)

		elseif (MH == 1017) then
			local tid = http.formvalue("TID")
			local dev = http.formvalue("DEVAL")
			txt = "{"..msgHeadGMAC..","..jres:cld_get_deviceListLQI_task(tid, dev)

		elseif (MH == 1018) then
			local tid = http.formvalue("TID")
			local dev = http.formvalue("DEVA")
			txt = "{"..msgHeadGMAC..","..jres:cld_get_onedeviceLQI_task(tid, dev)



		elseif (MH == 5001) then
			-- set/reset progress status
			local markId = tonumber(http.formvalue("MID"))
			local ctlStatus = tonumber(http.formvalue("PSTA"))
			txt = "{".."\"PROGRESS\":"..jres:cld_reset_progress_status(markId, ctlStatus).."}"

		elseif (MH == 5002) then
			-- get progress status
			local markId = tonumber(http.formvalue("MID"))
			txt = "{".."\"PROGRESS\":"..jres:cld_get_progress_status(markId).."}"

			

		elseif (MH == 1011) then
			-- Group Identify


		end
	end
	
	-- scene schedule list
	if (loadSceneSchedule ~= nil) then txt = jres:loadSceneSchedule() end
	-- if (loadSceneSchedule ~= nil) then txt = "hello, this is loadSceneSchedule response message!" end

	if (loadRoom ~= nil) then txt = jres:loadRoom() end

	if (delUserMode ~= nil) then 
		delUserMode = decodeURI(delUserMode)
		txt = jres:delUserMode(delUserMode) 
	end

	if (checkAddSceneName ~= nil) then 
		checkAddSceneName = decodeURI(checkAddSceneName)
		txt = jres:checkAddSceneName(checkAddSceneName) 
	end
	
	if (allRoom ~= nil) then txt = jres:allRoom(allRoom) end

	if (groupNum ~= nil) then                     -- room page
		if (roomSwitch ~= nil) then txt = jres:roomSwitch(groupNum, roomSwitch)
		elseif (slideLevel ~= nil) then txt = jres:roomLevel(groupNum, slideLevel)
		elseif (roomModeName ~= nil) then 
			roomModeName = decodeURI(roomModeName)
			txt = jres:roomModeName(groupNum, roomModeName) 
		end
	elseif (deviceAddress ~= nil) then            -- room_a page
		if (deviceSwitch ~= nil) then txt = jres:deviceSwitch(deviceAddress, deviceSwitch)
		elseif (slideLevel ~= nil) then txt = jres:deviceLevel(deviceAddress, slideLevel)
		elseif (slideTemp ~= nil) then txt = jres:deviceTemp(deviceAddress, slideTemp)
		elseif (slideColor ~= nil) then txt = jres:deviceColor(deviceAddress, slideColor)
		elseif (deviceIdentify ~= nil) then txt = jres:deviceIdentify(deviceAddress, deviceIdentify) end
	-- elseif (sceneSwitch ~= nil or threeSlideFlag ~= nil) then    -- add scene page
	elseif (addSceneSave ~= nil) then
		if (addSceneNameOrg ~= nil) then
			addSceneNameOrg = decodeURI(addSceneNameOrg)
		end
		if (addSceneName ~= nil) then
			addSceneName = decodeURI(addSceneName)
		end

		txt = jres:addSceneSave(addSceneSave, groupNumList, sceneGroupNum, addSceneName, sceneSwitch, slideLevel, slideTemp, slideColor, addSceneNameOrg)
	end

	-- three slide or switch controll
	if (threeSlideFlag ~= nil) then 
		txt = jres:addSceneSave(addSceneSave, groupNumList, sceneGroupNum, addSceneName, sceneSwitch, slideLevel, slideTemp, slideColor, addSceneNameOrg)
	end


	if (delDevice ~= nil) then txt = jres:delDevice(delDevice) end
	-- room setting page controll response
	if (settingRoomGN ~= nil) and (roomSwitch ~= nil) then txt = jres:roomSwitch(settingRoomGN, roomSwitch) end

	if (delRoom ~= nil) then txt = jres:delRoom(delRoom) end
	if (devRename ~= nil)     then 
		if (devNameList ~= nil) then
			devNameList = decodeURI(devNameList)
		end
		txt = jres:devRename(devAddrList, devNameList) 
	end
	if (addRoomSwitch ~= nil) then txt = jres:addRoomSwitch(addRoomSwitch, devList) end

	-- if (addRoomSlideFlag ~= nil) then txt = jres:addRoomSlideFlag(addRoomSlideFlag, slideLevel, slideTemp, slideColor, devList) end
	if (addRoomSlideFlag ~= nil) then txt = jres:addRoomSlideFlag(slideLevel, slideTemp, slideColor, devList) end

	if (selectDeviceFlag ~= nil) then txt = jres:selectDeviceFlag(selectDeviceFlag, devAddr, switchONF, slideLevel, slideTemp, slideColor) end

	if (saveRoomDateFlag ~= nil) then 
		if (addRoomName ~= nil) then
			addRoomName = decodeURI(addRoomName)
		end
		if (roomOrgName ~= nil) then
			roomOrgName = decodeURI(roomOrgName)
		end

		txt = jres:saveRoomDateFlag(saveRoomDateFlag, addRoomName, addRoomIcon, devList, roomOrgName) 
	end	
	if (addRoomNameCheck ~= nil) then 
		addRoomNameCheck = decodeURI(addRoomNameCheck)
		txt = jres:addRoomNameCheck(addRoomNameCheck) 
	end	

	-------------------------    room child page comment     ---------------------------------
	if (loadRoomChild ~= nil) then txt = jres:loadRoomChild(loadRoomChild) end

	-------------------------     scene list comment     ----------------------------------------------
	if (loadScene ~= nil) then txt = jres:loadScene() end

	------------------------       scene adjust  comment    ------------------------------------------------
	-- txt = decodeURI(loadModeAdjust)	
	if (loadModeAdjust ~= nil) then 
		loadModeAdjust = decodeURI(loadModeAdjust)
		txt = jres:loadModeAdjust(loadModeAdjust) 
	end

	------------------------    add scene comment    ------------------------------------------------------
	if (loadAddScene ~= nil) then txt = jres:loadAddScene() end

	----------------------     setting device list page   --------------------------------
	if (loadDeviceList ~= nil) then txt = jres:loadDeviceList() end

	-----------------------     setting open net page   --------------------------------------
	if (ctlNetStatus ~= nil) then txt = jres:ctlNetStatus(ctlNetStatus) end
	if (newDeviceList ~= nil) then txt = jres:newDeviceList() end

	---------------------    setting room list page     ---------------------------
	if (settingRoomList ~= nil) then txt = jres:settingRoomList() end

	---------------------    load  addroom page     ---------------------------
	if (loadAddRoom ~= nil or loadRoomAdjust ~= nil) then txt = jres:loadAddRoom(loadRoomAdjust) end

	--print(txt)
	snd2client(txt)
end


function decodeURI(s)
    s = string.gsub(s, '%%(%x%x)', function(h) return string.char(tonumber(h, 16)) end)
    return s
end

-- In this way, all API must to test
function testAPI(self, MH)

		if (MH == 1001 ) then
			--local openNetTime = http.formvalue("OPN")
			jres:openNetworkTime(15)	
			txt = "{"..msgHeadGMAC..",".."\"STA\":".."3"

		elseif (MH == 1002) then
			txt = "{"..msgHeadGMAC..",".."\"MID"..mop.."910D"..en

		elseif (MH == 1003) then
			txt = "{"..msgHeadGMAC..","..jres:requestDeviceList()

		elseif (MH == 1004) then
			--local devAddr = http.formvalue("DEVA")
			jres:deviceIdentify(9793, 3)
			txt = "{"..msgHeadGMAC..",".."\"STA\":".."3"

		elseif (MH == 1005) then
		--local devAddr = http.formvalue("DEVA")
		txt = "{"..msgHeadGMAC..","..jres:cld_delDevice(37567)

		elseif (MH == 1006) then
			local groupNum = tonumber(28)
			local devList = ',32259,16674'
			local tm = tonumber(3)
			txt = "{"..msgHeadGMAC..","..jres:cld_add_or_update_group(groupNum, devList, tm)

		elseif (MH == 1007) then
			--local groupNum = tonumber(http.formvalue("GN"))
			txt = "{"..msgHeadGMAC..","..jres:cld_delete_group(101)

		elseif (MH == 1008) then
			--local groupNum = tonumber(http.formvalue("GN"))
			--local devList = tonumber(http.formvalue("DEVEL"))
			txt = "{"..msgHeadGMAC..","..jres:cld_update_group(108, ',9793')

		elseif (MH == 1009) then
			 local groupNum = tonumber(109)
			 local onf = tonumber(1)
			 local lum = tonumber(nil)
			 local cct = tonumber(nil)
			 local rgb = tonumber(nil)
			 local tm  = tonumber(nil)
			txt = "{"..msgHeadGMAC..","..jres:cld_ctlgroup_parameter( groupNum, onf, lum, cct, rgb, tm )

		elseif (MH == 1011) then
			local groupNum = tonumber(27)
			txt = "{"..msgHeadGMAC..","..jres:groupIdentify(groupNum, 3)
		
		--OK
		elseif (MH == 1012) then
			local groupNum = tonumber(191)
			local devList = ',32259,16674'
			local tid = 'b1234567890b1234567890'
			txt = "{"..msgHeadGMAC..","..jres:cld_add_group_task(groupNum, devList, tid)

		--OK
		elseif (MH == 1013) then
			local tid = 'c1234567890b1234567890'
			local gid = tonumber(181)
			txt = "{"..msgHeadGMAC..","..jres:cld_delete_group_task(tid, gid)

		--OK
		elseif (MH == 1014) then
			local tid = 'a1234567890b1234567890'
			txt = "{"..msgHeadGMAC..","..jres:cld_delete_task(tid)

		--OK
		elseif (MH == 1015) then
			local tid = 'k1234567890b1234567890'
			txt = "{"..msgHeadGMAC..","..jres:cld_get_task_status(tid)

		--OK
		elseif (MH == 1016) then
			local tid = 'b1234567890b1234567890'
			local sta = tonumber(2)
			txt = "{"..msgHeadGMAC..","..jres:cld_updata_group_task(tid, sta)
		--OK
		elseif (MH == 1017) then
			local tid = 'r1234567890b1234567890'
			local dev = ',54813'
			txt = "{"..msgHeadGMAC..","..jres:cld_get_deviceListLQI_task(tid, dev)
		--OK
		-- elseif (MH == 1018) then
		-- 	local tid = 's1234567890b1234567890'
		-- 	local dev = ',54813'
		-- 	txt = "{"..msgHeadGMAC..","..jres:cld_get_onedeviceLQI_task(tid, dev)

		elseif (MH == 5001) then
			-- set/reset progress status
			local markId = tonumber(1)
			local ctlStatus = tonumber(3)
			txt = "{"..msgHeadGMAC..","..jres:cld_reset_progress_status(markId, ctlStatus)

		elseif (MH == 5002) then
			-- get progress status
			local markId = tonumber(1)
			txt = "{"..msgHeadGMAC..","..jres:cld_get_progress_status(markId)

		end

	print(txt)
end
--testAPI(self, 1018)
