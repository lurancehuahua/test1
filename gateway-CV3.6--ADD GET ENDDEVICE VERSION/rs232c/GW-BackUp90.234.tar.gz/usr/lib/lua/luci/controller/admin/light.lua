-- Copyright 2008 Steven Barth <steven@midlink.org>
-- Copyright 2011-2015 Jo-Philipp Wich <jow@openwrt.org>
-- Licensed to the public under the Apache License 2.0.
module("luci.controller.admin.light", package.seeall)

function index()
	local fs = require "nixio.fs"

	entry({"admin", "light"}, alias("admin", "light", "light"), _("Light"), 30).index = true
	entry({"admin", "light", "light"}, template("admin_light/light"), _("Light"), 1)
	entry({"admin", "light", "lightconf"}, call("action_lightconf"), _("Light Configuration"), 2)
	entry({"admin", "light", "lightMose"}, template("admin_light/lightMose"), _("LightMose"), 3)
	entry({"admin", "light", "test"}, template("admin_light/test"), _("test"), 4)
	entry({"admin", "light", "lightconf", "lightFun"}, call("action_lightFun"),nil)
	entry({"admin", "light", "test1"}, template("admin_light/test1"), _("Test1"), 5)
	entry({"admin", "light", "autoPage"}, template("admin_light/autoPage"), _("autoPage"), 6)
	entry({"admin", "light", "scene"}, template("admin_light/scene"), _("scene"), 7)

end

function action_lightconf()
	luci.template.render("admin_light/lightconf")
end

function action_lightFun()
	local http = require "luci.http"
	local rs232 = require("luars232")
	local e, p = rs232.open("/dev/ttyS1")
	p:set_baud_rate(rs232.RS232_BAUD_115200)
	p:set_data_bits(rs232.RS232_DATA_8)
	p:set_parity(rs232.RS232_PARITY_NONE)
	p:set_stop_bits(rs232.RS232_STOP_1)
	p:set_flow_control(rs232.RS232_FLOW_OFF)

	local fv = tonumber(http.formvalue("para")) 

	local msg = '\255\204' .. string.char(fv)
	p:write(msg, 500)
	p:close()
	http.redirect(luci.dispatcher.build_url('admin/light/lightMose'))
end
