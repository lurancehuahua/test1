-- Copyright 2017-11-14 N Lottie

local require = require

local nxo = require "nixio"
local nfs = require "nixio.fs"
local sys = require "luci.sys"
local utl = require "luci.util"
local dsp = require "luci.dispatcher"
local ipc = require "luci.ip"
local http = require "luci.http"
local uci = require "luci.model.uci"
local lng = require "luci.i18n"
local jsc = require "luci.jsonc"
local coroutine = require "coroutine"

local rs232 = require("luars232")

local p = p

module "luci.model.light"

local _uci

function _initSerialPort()
	local e, p = rs232.open("/dev/ttyS1")
	p:set_baud_rate(rs232.RS232_BAUD_115200)
	p:set_data_bits(rs232.RS232_DATA_8)
	p:set_parity(rs232.RS232_PARITY_NONE)
	p:set_stop_bits(rs232.RS232_STOP_1)
	p:set_flow_control(rs232.RS232_FLOW_OFF)
	print("_initSerialPort done")
	return p
end

function init(cursor)
	_uci = cursor or _uci or uci.cursor()
	p = p or _initSerialPort()
	return _M
end

function term(cursor)
	p:cloase()
end

function sendCmd(self, ...)
	p:write(...)
end

function receiveCmd(self, ...)
	p:read(...)
end