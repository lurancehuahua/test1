--Copyright (c) 2018 Greeble 
--Chenheng <heng.chen@scjz-led.com>
--ZGW sql V0.0.3 20171023

local require = require

local qlite3 = require "luasql.sqlite3"

module ("luci.model.db", package.seeall)

-- local dbfile = "/root/zgw.db"
local dbfile = "/tmp/zgw.db"

function _dbg(...)
	 --print(...)
end

function printtab(t)
	local k, v
	for k,v in pairs(t) do  
		_dbg(k, " = ", v)
	end  
end  

function mac2gid(mac64s)
	local gid = math.mod(tonumber(mac64s), 16384) * 4
	_dbg("mac64s = "..mac64s..", gid = "..gid)
	return gid
end

function rows(cur)  
    return function(cur)  
        local t = {}  
        if(nil ~= cur:fetch(t, 'a')) then return t  
        else return nil end
    end, cur 
end  

-- function xprinttab(self,t)  
-- 	printtab(t)
-- end  
  
-- function xrows(self,cur)  
-- 	return rows(cur)
-- end  

--delete a record by id
function del(t,id)
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile) 
	local sql, res

	sql = "DELETE FROM " .. t .. " " .. " WHERE id = " .. id
	_dbg(sql)

	db:setautocommit(false)
	res = db:execute(sql)
	db:commit() 
	_dbg(res)

	db:close()
	env:close()
	return res  
end    

function getidbyname(t, iname)
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile) 
	local sql, res, r, id

	sql = "SELECT id FROM " .. t .. " WHERE name = " .. "\'" .. iname .. "\'"
	_dbg(sql)

	res = db:execute(sql)
	if res ~= nil then
		for r in rows(res) do
			id = r["id"]
			printtab(r)
		end
		res:close()
	end

	_dbg(id)

	db:close()
	env:close()
	return id
end

function getavailableids(t)
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile) 
	local sql, res, r, i, ids

	sql = "SELECT * FROM " .. t
	_dbg(sql)

	res = db:execute(sql)
	if res ~= nil then 
		i = 1
		ids = {}
 		for r in rows(res) do
			ids[i] = r["id"]
			i = i + 1
			printtab(r)
		end
		res:close()
	end 	

	printtab(ids)

	db:close()
	env:close()
	return ids
end

function getavailableidsbytag(t, itag)
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile) 
	local sql, res, r, i, ids

	sql = "SELECT * FROM " .. t .. " WHERE tag = " .. itag
	_dbg(sql);

	res = db:execute(sql)
	if res ~= nil then 
		i = 1
		ids = {}
 		for r in rows(res) do
			ids[i] = r["id"]
			i = i + 1
			printtab(r)
		end
		res:close()
	end 	

	printtab(ids)

	db:close()
	env:close()
	return ids
end

--set state to db
function setsta(t,id,ista)  
	local env = qlite3.sqlite3()  
	local db = env:connect(dbfile)
	local sql, res

	sql = "UPDATE " .. t .. " SET sta = \'" .. ista .. "\' WHERE id = " .. id
	_dbg(sql)

	db:setautocommit(false)
	res = db:execute(sql)
	db:commit()
	_dbg(res)

	db:close()  
	env:close()
	return res 
end  

--get state by id
function getsta(t,id)  
	local env = qlite3.sqlite3() 
	local db = env:connect(dbfile)
	local sql, res, r, sta

	sql = "SELECT * FROM " .. t .. " WHERE id = " .. id
	_dbg(sql)

	res = db:execute(sql)
	if res ~= nil then
 		for r in rows(res) do  
			sta = r["sta"] or "0"
			printtab(r)
		end
		res:close()
	end 

	_dbg('sta = ',sta)

	db:close()
	env:close()
	return sta  
end

--set onoff ott to db
function setonoff(t,id,ionoff,iott)  
	local env = qlite3.sqlite3() 
	local db = env:connect(dbfile) 
	local sql, res

	sql = "UPDATE " .. t .. " SET onoff = " .. ionoff .. " , ott = " .. iott .. " WHERE id = " .. id
	_dbg(sql)

	db:setautocommit(false)  
	res = db:execute(sql)
	db:commit()

	_dbg(res)

	db:close()  
	env:close() 
	return res
end

--get onoff ott by id
function getonoff(t,id)
	local env = qlite3.sqlite3()  
	local db = env:connect(dbfile)
	local sql, res, r, onoff, ott

	sql = "SELECT * FROM " .. t .. " WHERE id = " .. id
	_dbg(sql)

	res = db:execute(sql)
	if res ~= nil then
 		for r in rows(res) do
			onoff = r["onoff"] or "1"
			ott = r["ott"] or "0"
			printtab(r)  
		end 
		res:close()
	end	

	_dbg('onoff = ', onoff)
	_dbg('ott = ', ott)

	db:close()
	env:close()
	return onoff , ott  
end

function setonoffall(t, ionoff, iott)
	local env = qlite3.sqlite3() 
	local db = env:connect(dbfile) 
	local sql, res

	-- sql = "UPDATE " .. t .. " SET onoff = " .. ionoff .. " , ott = " .. iott
	sql = "UPDATE " .. t .. " SET onoff = " .. ionoff

	_dbg(sql) 

	db:setautocommit(false)  
	res = db:execute(sql)
	db:commit()

	_dbg(res)

	db:close()
	env:close()
	return res
end

--set ct ctt to db
function setcct(t,id,ict,ictt)  
	local env = qlite3.sqlite3() 
	local db = env:connect(dbfile)
	local sql, res

	-- sql = "UPDATE " .. t .. " SET ct = " .. ict .. " , ctt = " .. ictt .. " WHERE id = " .. id
	sql = "UPDATE " .. t .. " SET ct = " .. ict .. " WHERE id = " .. id

	_dbg(sql)

	db:setautocommit(false)  
	res = db:execute(sql)
	db:commit()

	_dbg(res)

	db:close()  
	env:close() 
	return res  
end

--get ct ctt by id
function getcct(t,id)  
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile) 
	local sql, res, r, ct, ctt

	sql = "SELECT * FROM " .. t .. " WHERE id = " .. id
	_dbg(sql)

	res = db:execute(sql)
	if res ~= nil then
 		for r in rows(res) do  
			ct = r["ct"] or "30"
			ctt = r["ctt"] or "0"
			printtab(r) 
		end
		res:close()
	end

	_dbg('ct = ',ct)
	_dbg('ctt = ',ctt)

	db:close()
	env:close()
	return ct , ctt  
end

--set tag to db
function settag(t,id,itag)  
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile)
	local sql, res

	sql = "UPDATE " .. t .. " SET tag = \'" .. itag .. "\' WHERE id = " .. id
	_dbg(sql)

	db:setautocommit(false)  
	res = db:execute(sql)
	db:commit()

	_dbg(res)

	db:close()  
	env:close() 
	return res  
end  

--get tag by id
function gettag(t,id)  
	local env = qlite3.sqlite3()  
	local db = env:connect(dbfile)
	local sql, res, r, tag

	sql = "SELECT * FROM " .. t .. " WHERE id = " .. id
	_dbg(sql)

	res = db:execute(sql)
	if res ~= nil then
 		for r in rows(res) do  
			tag = r["tag"] or ""
			printtab(r)
		end
		res:close()
	end

	_dbg('tag=',tag)

	db:close()
	env:close()
	return tag
end

function checktag(t, itag)
	local env = qlite3.sqlite3()  
	local db = env:connect(dbfile)
	local sql, res, r, tag

	sql = "SELECT * FROM " .. t .. " WHERE tag = " .. itag
	_dbg(sql)

	res = db:execute(sql)
	if res ~= nil then
 		for r in rows(res) do
			tag = r["tag"] or ""
			printtab(r)
		end
		res:close()
	end

	_dbg('tag=',tag)

	db:close()
	env:close()

	if tag == itag then return 1 else return 0 end
	-- return tag
end

--set hue sat htt to db
function sethue(t,id,ihue,isat,ihtt)  
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile)
	local sql, res

	-- sql = "UPDATE " .. t .. " SET hue = " .. ihue .. " , htt = " .. ihtt .. " , sat = " .. isat .. " WHERE id = " .. id
	sql = "UPDATE " .. t .. " SET hue = " .. ihue .. " WHERE id = " .. id

	_dbg(sql)

	db:setautocommit(false)  
	res = db:execute(sql)
	db:commit()

	_dbg(res)

	db:close()
	env:close()
	return res  
end

--get hue sat htt by id
function gethue(t,id)  
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile)  
	local sql, res, r, hue, sat, htt

	sql = "SELECT * FROM " .. t .. " WHERE id = " .. id
	_dbg(sql)

	res = db:execute(sql)
	if res ~= nil then
 		for r in rows(res) do  
			hue = r["hue"] or "130"
			sat = r["sat"] or "0"
			htt = r["htt"] or "0"
			printtab(r)
		end 
		res:close()
	end

	_dbg('hue=',hue)
	_dbg('sat=',sat)
	_dbg('htt=',htt)

	db:close()
	env:close()
	return hue , sat , htt  
end

--set lum ltt to db
function setlum(t,id,ilum,iltt)  
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile) 
	local sql, res

	-- sql = "UPDATE " .. t .. " SET lum = " .. ilum .. " , ltt = " .. iltt .. " WHERE id = " .. id
	sql = "UPDATE " .. t .. " SET lum = " .. ilum .. " WHERE id = " .. id

	_dbg(sql) 

	db:setautocommit(false)
	res = assert (db:execute(sql))
	db:commit()

	_dbg(res)

	db:close() 
	env:close()
	return res  
end

--get lum ltt by id
function getlum(t,id)
	local env = qlite3.sqlite3() 
	local db = env:connect(dbfile)
	local sql, res, r, lum, ltt

	sql = "SELECT * FROM " .. t .. " WHERE id = " .. id
	_dbg(sql)

	res = db:execute(sql)
	if res ~= nil then
 		for r in rows(res) do  
			lum = r["lum"] or "100"
			ltt = r["ltt"] or "5"
			printtab(r)
		end 
		res:close()
	end

	_dbg('lum = ',lum)
	_dbg('ltt = ',ltt)

	db:close()
	env:close()
	return lum , ltt  
end

--set name to db
function setname(t,id,iname) 
	local env = qlite3.sqlite3()  
	local db = env:connect(dbfile) 
	local sql, res

	sql = "UPDATE " .. t .. " SET name = \'" .. iname .. "\' WHERE id = " .. id
	_dbg(sql)

	db:setautocommit(false)  
	res = db:execute(sql)
	db:commit()

	_dbg(res)

	db:close()  
	env:close() 
	return res  
end

--get name by id
function getname(t,id)
	local env = qlite3.sqlite3() 
	local db = env:connect(dbfile)
	local sql, res, r, name

	sql = "SELECT * FROM " .. t .. " WHERE id = " .. id
	_dbg(sql)

	res = db:execute(sql)
	if res ~= nil then
 		for r in rows(res) do  
			name = r["name"] or ""
			printtab(r) 
		end 
		res:close()
	end 

	_dbg('name = ',name)

	db:close()
	env:close()
	return name  
end

-- ROOM OPs
--add a record and set tag name
function rooms_add(self,itag,iname)  
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile)
	local sql, res

	sql = "INSERT INTO rooms (tag,name) VALUES (" .. itag .. ",\'" .. iname .. "\')"
	_dbg(sql)

	db:setautocommit(false)
	res = db:execute(sql)
	db:commit()

	_dbg(res)

	db:close()
	env:close()
	return res  
end    

--delete a record by id
function rooms_del(self,id)  
	return del('rooms',id)
end    

--set name to db
function rooms_setname(self,id,iname)
	return setname('rooms',id,iname)
end  

--get name by id
function rooms_getname(self,id)  
	return getname('rooms',id)
end

--set tag to db
function rooms_settag(self,id,itag)  
	return settag('rooms',id,itag)
end  

--get tag by id
function rooms_gettag(self,id)  
	return gettag('rooms',id)  
end

--set state to db
function rooms_setsta(self,id,ista)  
	return setsta('rooms',id,ista)
end

--get state by id
function rooms_getsta(self,id)
	return getsta('rooms',id)
end

function rooms_getavailableids(self)
	return getavailableids('rooms')
end

--set dids to db
function rooms_setsids(self,id,isids)  
	local env = qlite3.sqlite3()  
	local db = env:connect(dbfile) 
	local sql, res

	sql = "UPDATE rooms SET sids = " .. isids .. " WHERE id = " .. id
	_dbg(sql)

	db:setautocommit(false)  
	res = db:execute(sql)
	db:commit()

	_dbg(res)

	db:close()  
	env:close() 
	return res  
end  

--get dids by id
function rooms_getsids(self,id)  
	local env = qlite3.sqlite3();  
	local db = env:connect(dbfile);  
	local sql, res, r, sids

	sql = "SELECT * FROM rooms WHERE id = " .. id
	_dbg(sql)

	res = db:execute(sql)
	if res ~= nil then
 		for r in rows(res) do  
			sids = r["sids"] or "0"
			printtab(r)
		end
		res:close()
	end 

	_dbg('sids = ',sids)

	db:close()
	env:close()
	return sids  
end

-- SCENCE OPs
--add a record and set tag name
function scenes_add(self,itag,iname)  
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile)
	local sql, res

	sql = "INSERT INTO scenes (tag,name) VALUES (" .. itag .. ",\'" .. iname .. "\')"
	_dbg(sql)

	db:setautocommit(false);
	res = db:execute(sql)
	db:commit()

	_dbg(res)

	db:close()
	env:close()
	return res  
end    

--delete a record by id
function scenes_del(self,id)
	return del('scenes',id)
end    

--set name to db
function scenes_setname(self,id,iname)  
	return setname('scenes',id,iname) 
end  

--get name by id
function scenes_getname(self,id)  
	return getname('scenes',id)
end

--set tag to db
function scenes_settag(self,id,itag)  
	return settag('scenes',id,itag)
end  

--get tag by id
function scenes_gettag(self,id)  
	return gettag('scenes',id)  
end

function scenes_getavailableids(self)
	return getavailableids('scenes')
end

--set gids to db
function scenes_setgids(self,id,igids)  
	local env = qlite3.sqlite3()  
	local db = env:connect(dbfile)  
	local sql, res

	sql = "UPDATE scenes SET gids = " .. igids .. " WHERE id = " .. id
	_dbg(sql) 

	db:setautocommit(false)  
	res = db:execute(sql)
	db:commit()

	_dbg(res)

	db:close()  
	env:close() 
	return res  
end  

--get gids by id
function scenes_getgids(self,id)  
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile) 
	local sql, res, r, gids

	sql = "SELECT * FROM scenes WHERE id = " .. id
	_dbg(sql)

	res = db:execute(sql)
	if res ~= nil then
 		for r in rows(res) do  
			gids = r["gids"] or "0"
			printtab(r) 
		end
		res:close()
	end 

	_dbg('gids = ',gids)

	db:close() 
	env:close()
	return gids  
end

-- GROUP OPs
--add a record and set tag name
function groups_add(self,itag,iname)
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile)
	local sql, res

	sql = "INSERT INTO groups (tag,name) VALUES (" .. itag .. ",\'" .. iname .. "\')"
	_dbg(sql)

	db:setautocommit(false)
	res = db:execute(sql)
	db:commit()

	_dbg(res)

	db:close()
	env:close()
	return res  
end    

--delete a record by id
function groups_del(self,id)  
	return del('groups',id)
end 
 
--set name to db
function groups_setname(self,id,iname)  
	return setname('groups',id,iname)
end  

--get name by id
function groups_getname(self,id)  
	return getname('groups',id)
end

--set tag to db
function groups_settag(self,id,itag)  
	return settag('groups',id,itag)
end

--get tag by id
function groups_gettag(self,id)  
	return gettag('groups',id) 
end

--check tag
function groups_checktag(self,itag)  
	return checktag('groups',itag) 
end

--set all groups onoff ott to db
function groups_setonoffall(self,ionoff,iott)  
	return setonoffall('groups',ionoff,iott)
end

--set onoff ott to db
function groups_setonoff(self,id,ionoff,iott)  
	return setonoff('groups',id,ionoff,iott)
end  

--get onoff ott by id
function groups_getonoff(self,id)  
	return getonoff('groups',id) 
end

--set lum ltt to db
function groups_setlum(self,id,ilum,iltt)  
	return setlum('groups',id,ilum,iltt)
end

--get lum ltt by id
function groups_getlum(self,id)  
	return getlum('groups',id)
end

--set ct ctt to db
function groups_setcct(self,id,ict,ictt)  
	return setcct('groups',id,ict,ictt)
end

--get ct ctt by id
function groups_getcct(self,id)  
	return getcct('groups',id)
end

--set hue hdir htt to db
function groups_sethue(self,id,ihue,isat,ihtt)  
	return sethue('groups',id,ihue,isat,ihtt)
end

--get hue hdir htt by id
function groups_gethue(self,id)  
	return gethue('groups',id)  
end

--set state to db
function groups_setsta(self,id,ista)  
	return setsta('groups',id,ista)
end

--get state by id
function groups_getsta(self,id)  
	return getsta('groups',id)
end

function groups_getavailableids(self)
	return getavailableids('groups')
end

function groups_getavailableidsbytag(self, itag)
	return getavailableidsbytag('groups',itag)
end

function groups_getidbyname(self, iname)
	return getidbyname('groups',iname)
end

--set dids to db
function groups_setdids(self,id,idids)
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile)
	local sql, res

	sql = "UPDATE groups SET dids = " .. idids .. " WHERE id = " .. id
	_dbg(sql)

	db:setautocommit(false)  
	res = db:execute(sql)
	db:commit()

	_dbg(res)

	db:close()
	env:close()
	return res
end  

--get dids by id
function groups_getdids(self,id)
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile)
	local sql, res, r, dids

	sql = "SELECT * FROM groups WHERE id = " .. id
	_dbg(sql)

	res = db:execute(sql)
	if res ~= nil then
		for r in rows(res) do
			dids = r["dids"] or "0"
			printtab(r)
		end
		res:close()
	end 

	_dbg('dids = ',dids)

	db:close()
	env:close()
	return dids
end

--set sid to db
function groups_setsid(self,id,isid)
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile)
	local sql, res

	sql = "UPDATE groups SET sid = " .. isid .. " WHERE id = " .. id
	_dbg(sql);

	db:setautocommit(false)
	res = db:execute(sql)
	db:commit()

	_dbg(res)

	db:close()  
	env:close()
	return res  
end  

--get sid by id
function groups_getsid(self,id)  
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile) 
	local sql, res, r, sid

	sql = "SELECT * FROM groups WHERE id = " .. id
	_dbg(sql);

	res = db:execute(sql)
	if res ~= nil then
 		for r in rows(res) do  
			sid = r["sid"] or "0"
			printtab(r)
		end
		res:close()
	end 

	_dbg('sid = ',sid)

	db:close()
	env:close()
	return sid  
end

-- DEVICE OPs
--add a record and set tag mac
function devices_add(self,itag,imac)  
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile)
	local sql, res

	sql = "INSERT INTO devices (tag,mac) VALUES (" .. itag .. "," .. imac .. ")"
	_dbg(sql)

	db:setautocommit(false)
	res = db:execute(sql)
	db:commit()

	_dbg(res)

	db:close()
	env:close()
	return res  
end    

--delete a record by id
function devices_del(self,id)  
	return del('devices',id)  
end    

--set name to db
function devices_setname(self,id,iname)  
	return setname('devices',id,iname)
end

--get name by id
function devices_getname(self,id)
	return getname('devices',id)
end

--set hue sat htt to db
function devices_sethue(self,id,ihue,isat,ihtt)
	return sethue('devices',id,ihue,isat,ihtt) 
end

--get hue sat htt by id
function devices_gethue(self,id)  
	return gethue('devices',id) 
end

--set state to db
function devices_setsta(self,id,ista)  
	return setsta('devices',id,ista)
end  

--get state by id
function devices_getsta(self,id)  
	return getsta('devices',id)
end

--set all devices onoff ott to db
function devices_setonoffall(self,id,ionoff,iott)  
	return setonoffall('devices',id,ionoff,iott)
end

--set onoff ott to db
function devices_setonoff(self,id,ionoff,iott)  
	return setonoff('devices',id,ionoff,iott)
end  

--get onoff ott by id
function devices_getonoff(self,id)  
	return getonoff('devices',id) 
end

--set lum ltt to db
function devices_setlum(self,id,ilum,iltt)  
	return setlum('devices',id,ilum,iltt)  
end

--get lum ltt by id
function devices_getlum(self,id)  
	return getlum('devices',id) 
end

--set ct ctt to db
function devices_setcct(self,id,ict,ictt)  
	return setcct('devices',id,ict,ictt)
end

--get ct ctt by id
function devices_getcct(self,id)  
	return getcct('devices',id)
end

--set tag to db
function devices_settag(self,id,itag)  
	return settag('devices',id,itag)
end  

--get tag by id
function devices_gettag(self,id)  
	return gettag('devices',id)
end

function devices_getavailableids(self)
	return getavailableids('devices')
end

function devices_getavailableaddrs(self)
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile) 
	local sql, res, r, i, addrs

	sql = "SELECT addr FROM devices"
	_dbg(sql)

	res = db:execute(sql)
	if res ~= nil then 
		i = 1
		addrs = {}
 		for r in rows(res) do
			addrs[i] = r["addr"]
			i = i + 1
			printtab(r)
		end
		res:close()
	end 	

	printtab(addrs)

	db:close()
	env:close()
	return addrs
end

--set pos to db
function devices_setpos(self,id,ipos)  
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile) 
	local sql, res

	sql = "UPDATE devices SET pos = " .. ipos .. " WHERE id = " .. id
	_dbg(sql) 

	db:setautocommit(false)  
	res = db:execute(sql)
	db:commit()

	_dbg(res)

	db:close() 
	env:close()
	return res  
end  

--get pos by id
function devices_getpos(self,id)  
	local env = qlite3.sqlite3() 
	local db = env:connect(dbfile)
	local sql, res, r, pos

	sql = "SELECT * FROM devices WHERE id = " .. id
	_dbg(sql)

	res = db:execute(sql)
	if res ~= nil then
 		for r in rows(res) do  
			pos = r["pos"] or "0"
			printtab(r)
		end
		res:close()
	end 

	_dbg('pos = ',pos)

	db:close()
	env:close()
	return pos  
end

--get addr by id
function devices_getaddr(self, id)
	local env = qlite3.sqlite3() 
	local db = env:connect(dbfile)
	local sql, res, r, addr

	sql = "SELECT * FROM devices WHERE id = " .. id
	_dbg(sql)

	res = db:execute(sql)
	if res ~= nil then
 		for r in rows(res) do  
			addr = r["addr"] or "0"
			printtab(r)
		end
		res:close()
	end 

	_dbg('addr = ',addr)

	db:close()
	env:close()
	return addr
end

--get mac by id
function devices_getmac(self, id)
	local env = qlite3.sqlite3() 
	local db = env:connect(dbfile)
	local sql, res, r, mach, macl

	-- sql = "SELECT mac FROM devices WHERE id = " .. id
	sql = "SELECT ltt, mac FROM devices WHERE id = " .. id

	_dbg(sql)

	res = db:execute(sql)
	if res ~= nil then
 		for r in rows(res) do  
 			mach = r["ltt"] or "0"
			macl = r["mac"] or "0"
			printtab(r)
		end
		res:close()
	end 

	_dbg('mach, macl = '.. mach .. macl)

	db:close()
	env:close()
	return mach, macl
end

--get id by addr
function devices_getidbyaddr(self,iaddr)  
	local env = qlite3.sqlite3() 
	local db = env:connect(dbfile)
	local sql, res, r, id

	sql = "SELECT * FROM devices WHERE addr = " .. iaddr
	_dbg(sql)

	res = db:execute(sql)
	if res ~= nil then
 		for r in rows(res) do  
			id = r["id"]
			printtab(r)
		end
		res:close()
	end 

	if (id ~= nil) then
		_dbg('id = ' .. id)
	end	

	--res:close()
	db:close()
	env:close()
	return id  
end

function devices_delbyaddr(self, iaddr)
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile)
	local sql, res

	sql = "DELETE FROM devices WHERE addr = " .. iaddr
	_dbg(sql)

	db:setautocommit(false)
	res = db:execute(sql)
	db:commit() 
	_dbg(res)

	db:close()
	env:close()
end

--set name to db
function devices_setnamebyaddr(t,iaddr,iname) 
	local env = qlite3.sqlite3()  
	local db = env:connect(dbfile) 
	local sql, res

	sql = "UPDATE devices SET name = \'" .. iname .. "\' WHERE addr = " .. iaddr
	_dbg(sql)

	db:setautocommit(false)
	res = db:execute(sql)
	db:commit()

	_dbg(res)

	db:close()  
	env:close() 
	return res  
end

function devices_load(self)
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile)
	local sql, res, r, array, i

	sql = "SELECT id, tag, name, addr FROM devices"
	_dbg(sql)

	array = {}
	res = db:execute(sql)
	if res ~= nil then
		i = 1
 		for r in rows(res) do 
			array[i] = r["id"] or ""
			array[i+1] = r["tag"] or ""
			array[i+2] = r["name"] or ""
			array[i+3] = r["addr"] or ""
			_dbg(array[i] .. ", " .. array[i+1] .. ", " .. array[i+2] .. ", " .. array[i+3])
			printtab(r)
			i = i + 4
		end
		res:close()
	end 

	db:close()
	env:close()
	return array
end

function devices_checkid(self, id)
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile)
	local sql, res, flag

	sql = "SELECT id FROM devices WHERE id = " .. id
	_dbg(sql)

	flag = 0
	res = db:execute(sql)
	if res ~= nil then
		for r in rows(res) do 
			flag = 1
			printtab(r)
		end
		res:close()
	end

	_dbg(flag)

	db:close()
	env:close()
	return flag
end


function devices_checkaddr(self, iaddr)
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile)
	local sql, res, flag

	sql = "SELECT id FROM devices WHERE addr = " .. iaddr
	_dbg(sql)

	flag = 0
	res = db:execute(sql)
	if res ~= nil then
		for r in rows(res) do 
			flag = 1
			printtab(r)
		end
		res:close()
	end

	_dbg(flag)

	db:close()
	env:close()
	return flag
end


function devices_getdetail(self, id)
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile)
	local sql, res, name, tag, addr

	sql = "SELECT * FROM devices WHERE id = " .. id
	_dbg(sql)

	res = db:execute(sql)
	if res ~= nil then
		for r in rows(res) do 
			name = r["name"] or ""
			tag = r["tag"] or ""
			addr = r["addr"] or ""
			printtab(r)
		end
		res:close()
	end

	db:close()
	env:close()
	return name, tag, addr
end


function devices_getdetailbyaddr(self, iaddr)
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile)
	local sql, res, name, tag, addr

	sql = "SELECT * FROM devices WHERE addr = " .. iaddr
	_dbg(sql)

	res = db:execute(sql)
	if res ~= nil then
		for r in rows(res) do 
			name = r["name"] or ""
			tag = r["tag"] or ""
			addr = r["addr"] or ""
			printtab(r)
		end
		res:close()
	end

	db:close()
	env:close()
	return name, tag, addr
end


function devices_getgid(self, id)
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile)
	local sql, res, gid

	sql = "SELECT * FROM devices WHERE id = " .. id
	_dbg(sql)

	res = db:execute(sql)
	if res ~= nil then
		for r in rows(res) do 
			if r["mac"] ~= nil then
				gid = mac2gid(r["mac"])
				_dbg(gid)
			end
			printtab(r)
		end
		res:close()
	end

	db:close()
	env:close()
	return gid
end


function devices_getprofile(self, iaddr)
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile)
	local sql, res, onh, offh, uen

	sql = "SELECT onh, offh, uen FROM devices WHERE addr = " .. iaddr
	_dbg(sql)
	res = db:execute(sql)
	if res ~= nil then
		for r in rows(res) do 
			onh = r["onh"] or "0"
			offh = r["offh"] or "0"
			uen = r["uen"] or "0"
			printtab(r)
		end
		res:close()
	end
	db:close()
	env:close()
	return onh, offh, uen
end

function devices_getlightnumber(self)
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile)
	local lightnumber = 0

	sql = "SELECT tag FROM devices WHERE tag between 61 and 64"
	_dbg(sql)
	res = db:execute(sql)
	if res ~= nil then
		for r in rows(res) do 
			lightnumber = lightnumber + 1
			printtab(r)
		end
		res:close()
	end

	_dbg(lightnumber)

	db:close()
	env:close()
	return lightnumber
end

function devices_getlightonnumber(self)
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile)
	local lightonnumber = 0

	sql = "SELECT tag FROM devices WHERE onoff = 1 and tag between 61 and 64"
	_dbg(sql)
	res = db:execute(sql)
	if res ~= nil then
		for r in rows(res) do 
			lightonnumber = lightonnumber + 1
			printtab(r)
		end
		res:close()
	end

	_dbg(lightonnumber)

	db:close()
	env:close()
	return lightonnumber
end

function devices_gettotalwatt(self)
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile)
	local totalwatt = 0

	sql = "SELECT watt FROM devices"
	_dbg(sql)
	res = db:execute(sql)
	if res ~= nil then
		for r in rows(res) do 
			totalwatt = totalwatt + tonumber(r["watt"])
			printtab(r)
		end
		res:close()
	end

	_dbg(totalwatt)

	db:close()
	env:close()
	return totalwatt
end

-- multi-api, rooms, scenes add as a group
-- use state to sign it is a room-group
function grooms_add(self, itag, iname)
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile)
	local sql, res

	-- return if the same name grooms is exist already
	sql = "SELECT * FROM groups WHERE sta = 55 AND name = " .. "\'" .. iname .. "\'"
	_dbg(sql)
	res = db:execute(sql)
	if res ~= nil then
		for r in rows(res) do 
			printtab(r)
			res:close()
			db:close()
			env:close()
			return 0
		end
		res:close()
	end

	sql = "INSERT INTO groups (tag,name,sta,onoff,lum) VALUES (" .. itag .. ",\'" .. iname .. "\', 55, 0, 0)"
	_dbg(sql)
	db:setautocommit(false);
	res = db:execute(sql)
	db:commit()
	_dbg(res)

	db:close()
	env:close()
	return res 
end

function grooms_modify(self, inameorg, itag, iname)
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile)
	local sql, res, id

	-- return if the same name grooms is exist already
	sql = "SELECT id FROM groups WHERE sta = 55 AND name = " .. "\'" .. inameorg .. "\'"
	_dbg(sql)
	res = db:execute(sql)
	if res ~= nil then
 		for r in rows(res) do
 			id =  r["id"] or ""
			printtab(r)
		end
		res:close()
	end

	if id ~= nil then
		sql = "UPDATE groups SET name = " .. "\'" .. iname .. "\', tag = " .. itag .. " WHERE sta = 55 AND id = " .. id
		_dbg(sql)
		db:setautocommit(false)
		res = db:execute(sql)
		db:commit()
		_dbg(res)
	end

	db:close()
	env:close()
	return res 
end

function grooms_del(self, id)
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile)
	local sql, res

	sql = "DELETE FROM groups WHERE sta = 55 and id = " .. id
	_dbg(sql)

	db:setautocommit(false)
	res = db:execute(sql)
	db:commit() 
	_dbg(res)

	db:close()
	env:close()
	return res
end

-- ret: array = {id, tag, name, scence_name, onoff, lum} * n
function grooms_load(self)
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile)
	local sql, res, r, array, i

	sql = "SELECT id, tag, name, sid, onoff, lum FROM groups WHERE sta = 55"
	_dbg(sql)

	array = {}
	res = db:execute(sql)
	if res ~= nil then
		i = 1
 		for r in rows(res) do 
			array[i] = r["id"] or ""
			array[i+1] = r["tag"] or "1"
			array[i+2] = r["name"] or ""
			array[i+3] = r["sid"] or "0"
			array[i+4] = r["onoff"] or "1"
			array[i+5] = r["lum"] or "100"
			_dbg(array[i] .. " " .. array[i+1] .. " " .. array[i+2] .. " " .. array[i+3] .. " " .. array[i+4] .. " " .. array[i+5])
			printtab(r)
			i = i + 6
		end
		res:close()
	end 

	-- get scence name by sid and replace array[i+3] which store sid before.
	if i > 1 then
		i = 1
		while (array[i] ~= nil) do
			sql = "SELECT name FROM groups WHERE id = " .. array[i+3]
			res = db:execute(sql)
			array[i+3] = ""
			if res ~= nil then
				for r in rows(res) do 
					array[i+3] = r["name"] or ""
					printtab(r)
				end
				res:close()
			end
			_dbg(array[i] .. " " .. array[i+1] .. " " .. array[i+2] .. " " .. array[i+3] .. " " .. array[i+4] .. " " .. array[i+5])
			i = i + 6
		end
	end

	db:close()
	env:close()
	return array
end

-- ret: array = {id, tag, name} * n
function grooms_loadtagname(self)
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile)
	local sql, res, r, array, i

	sql = "SELECT id, tag, name FROM groups WHERE sta = 55"
	_dbg(sql)

	array = {}
	res = db:execute(sql)
	if res ~= nil then
		i = 1
 		for r in rows(res) do 
 			array[i] = r["id"] or ""
			array[i+1] = r["tag"] or ""
			array[i+2] = r["name"] or ""
			_dbg(array[i] .. " " .. array[i+1] .. " " .. array[i+2])
			printtab(r)
			i = i + 3
		end
		res:close()
	end 

	db:close()
	env:close()
	return array
end

-- ret: room's scence list, array = {id, tag, name}
function grooms_loadscenes(self, id)
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile)
	local sql, res, r, array, i, array2, j, splitlist, k, v

	-- get all scences' list
	sql = "SELECT id, tag, name, dids FROM groups WHERE sta = 44"
	_dbg(sql)
	array = {}
	res = db:execute(sql)
	if res ~= nil then
		i = 1
 		for r in rows(res) do 
 			array[i] = r["id"] or ""
			array[i+1] = r["tag"] or ""
			array[i+2] = r["name"] or ""
			array[i+3] = r["dids"] or "0"
			_dbg(array[i] .. " " .. array[i+1] .. " " .. array[i+2] .. " " .. array[i+3])
			printtab(r)
			i = i + 4
		end
		res:close()
	end 

	-- check every scence's dids if content param id
	i = 1
	j = 1
	array2 = {}
	while (array[i] ~= nil) do
		splitlist = {}
		string.gsub(array[i+3], '[^,]+', function(w) table.insert(splitlist, w) end ) 
		for k,v in ipairs(splitlist) do
			if tonumber(v) == id then 
				array2[j] = array[i]
				array2[j+1] = array[i+1]
				array2[j+2] = array[i+2]
				_dbg(array2[j] .. " " .. array2[j+1] .. " " .. array2[j+2])
				j = j + 3
			end
		end
		i = i + 4
	end

	db:close()
	env:close()
	return array2
end

-- ret: room's devices list, array = {addr, tag, name, onoff, lum, ct, hue}
function grooms_loaddevices(self, id)
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile)
	local sql, res, r, dids, array, i, splitlist, k, v

	-- get room's dids(devices list)
	sql = "SELECT dids FROM groups WHERE id = " .. id
	_dbg(sql)

	res = db:execute(sql)
	if res ~= nil then
 		for r in rows(res) do 
 			dids = r["dids"]
			printtab(r)
		end
		res:close()
	end 

	-- get every device's details
	if dids ~= nil then
		splitlist = {}
		string.gsub(dids, '[^,]+', function(w) table.insert(splitlist, w) end ) 

		array = {}
		i = 1
		for k,v in ipairs(splitlist) do
			sql = "SELECT addr, tag, name, onoff, lum, ct, hue FROM devices WHERE addr = " .. v
			res = db:execute(sql)
			if res ~= nil then
 				for r in rows(res) do 
 					array[i] = r["addr"] or ""
 					array[i+1] = r["tag"] or ""
 					array[i+2] = r["name"] or ""
 					array[i+3] = r["onoff"] or "1"
 					array[i+4] = r["lum"] or "100"
 					array[i+5] = r["ct"] or "30"
 					array[i+6] = r["hue"] or "130"
 					_dbg(array[i] .. " " .. array[i+1] .. " " .. array[i+2] .. " " .. array[i+3] .. " " .. array[i+4] .. " " .. array[i+5] .. " " .. array[i+6])
					printtab(r)
 					i = i + 7
				end
				res:close()
			end 
		end
	end

	db:close()
	env:close()
	return array
end

-- ret: room's scene's name
function grooms_loadcurscenesname(self, id)
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile)
	local sql, res, r, sid, s_name

	-- get room's sid
	sql = "SELECT sid FROM groups WHERE id = " .. id
	_dbg(sql)

	res = db:execute(sql)
	if res ~= nil then
 		for r in rows(res) do 
 			sid = r["sid"] or "0"
			printtab(r)
		end
		res:close()
	end 

	-- get scence's name by sid
	if sid ~= nil then
		sql = "SELECT name FROM groups WHERE id = " .. sid
		res = db:execute(sql)
		s_name = ""
		if res ~= nil then
			for r in rows(res) do
				s_name = r["name"]
				printtab(r)
			end
			res:close()
		end
	end

	_dbg(s_name)

	db:close()
	env:close()
	return s_name
end

-- ret: devices list, array = {addr, tag, name, onoff, lum, ct, hue}
-- ret: scence list, array = {id, tag, name}
-- ret: current scene's name
function grooms_loadchild(self, id)
	local devices = {}
	local scenes = {}
	local s_name, i

	devices = grooms_loaddevices(self, id)
	scenes = grooms_loadscenes(self, id)
	s_name = grooms_loadcurscenesname(self, id)

	_dbg("------------grooms_loadchild---------------")
	if devices ~= nil then
		i = 1
		while (devices[i] ~= nil) do
			_dbg(devices[i] .. " " .. devices[i+1] .. " " .. devices[i+2] .. " " .. devices[i+3] .. " " .. devices[i+4] .. " " .. devices[i+5] .. " " .. devices[i+6])
			i = i + 7
		end
	end

	if scenes ~= nil then
		i = 1
		while (scenes[i] ~= nil) do
			_dbg(scenes[i] .. " " .. scenes[i+1] .. " " .. scenes[i+2])
			i = i + 3
		end
	end

	_dbg(s_name)
	_dbg("------------grooms_loadchild end---------------")

	return devices, scenes, s_name
end

function grooms_loaddids(self)
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile)
	local sql, res, r, dids, didsall

	sql = "SELECT dids FROM groups WHERE sta = 55"
	_dbg(sql)

	didsall = "0"
	res = db:execute(sql)
	if res ~= nil then
 		for r in rows(res) do 
 			dids = r["dids"] or "0"
 			didsall = didsall..","..dids
			printtab(r)
		end
		res:close()
	end 

	_dbg(dids)

	db:close()
	env:close()
	return dids
end

function grooms_loadbydid(self, idid)
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile)
	local sql, res, r, array, i, dids, splitlist, k, v, txt

	sql = "SELECT id, dids FROM groups WHERE sta = 55"
	_dbg(sql)

	array = {}
	txt = ""
	res = db:execute(sql)
	if res ~= nil then
		i = 1
 		for r in rows(res) do 
 			dids = r["dids"]
 			if dids ~= nil then
 				splitlist = {}
 				string.gsub(dids, '[^,]+', function(w) table.insert(splitlist, w) end )
 				for k, v in ipairs(splitlist) do
 					if idid == tonumber(v) then
 						array[i] = r["id"]
 						txt = txt..i.." "..array[i].." "
 						i = i + 1
 					end
				end
 			end
			printtab(r)
		end
		res:close()
	end 

	_dbg(txt)

	db:close()
	env:close()
	return array
end

-- ret flag: 1-the name is already exist, 0-the name is not exist yet
function grooms_checkname(self, iname)
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile)
	local sql, res, flag

	sql = "SELECT name FROM groups WHERE sta = 55 AND name = " .. "\'" .. iname .. "\'"
	_dbg(sql)

	flag = 0
	res = db:execute(sql)
	if res ~= nil then
		for r in rows(res) do 
			flag = 1
			printtab(r)
		end
		res:close()
	end

	_dbg(flag)

	db:close()
	env:close()
	return flag
end

-- ret flag: 1-the id is available, 0-the id is unavailable
function grooms_checkid(self, id)
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile)
	local sql, res, flag

	sql = "SELECT id FROM groups WHERE sta = 55 AND id = " .. id
	_dbg(sql)

	flag = 0
	res = db:execute(sql)
	if res ~= nil then
		for r in rows(res) do 
			flag = 1
			printtab(r)
		end
		res:close()
	end

	_dbg(flag)

	db:close()
	env:close()
	return flag
end

-- ret id: nil or id
function grooms_getidbyname(self, iname)
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile) 
	local sql, res, r, id

	sql = "SELECT id FROM groups WHERE sta = 55 AND name = " .. "\'" .. iname .. "\'"
	_dbg(sql)

	res = db:execute(sql)
	if res ~= nil then
		for r in rows(res) do
			id = r["id"] or ""
			printtab(r)
		end
		res:close()
	end

	_dbg(id)

	db:close()
	env:close()
	return id
end

function grooms_getroomnumber(self)
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile) 
	local sql, res, r, roomnumber

	roomnumber = 0
	sql = "SELECT id FROM groups WHERE sta = 55"
	_dbg(sql)

	res = db:execute(sql)
	if res ~= nil then
		for r in rows(res) do
			roomnumber = roomnumber + 1
			printtab(r)
		end
		res:close()
	end

	_dbg(roomnumber)

	db:close()
	env:close()
	return roomnumber
end

function grooms_setdids(self,id,idaddrs)
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile)
	local sql, res, i, splitlist, k, v, temp, tag

	tag = 61
	if idaddrs ~= nil then
		array = {}
		i = 1
		splitlist = {}
		string.gsub(idaddrs, '[^,]+', function(w) table.insert(splitlist, w) end ) 
		for k, v in ipairs(splitlist) do
			sql = "SELECT tag FROM devices WHERE addr = " .. v
			_dbg(sql)
			res = db:execute(sql)
			if res ~= nil then
 				for r in rows(res) do
 					temp = tonumber(r["tag"])
 					if tag < temp then tag = temp end
					printtab(r)
				end
				res:close()
			end 
		end
	end

	if tag == 61 then tag = 1 
	elseif tag == 62 then tag = 2
	elseif tag == 63 then tag = 3
	elseif tag == 64 then tag = 4 
	else tag = 1 end

	sql = "UPDATE groups SET "
	sql = sql .. "ott = \'" .. tag .. "\'"
	sql = sql .. ", dids = \'" .. idaddrs .."\'"
	sql = sql .. " WHERE sta = 55 AND id = " .. id
	_dbg(sql)

	db:setautocommit(false)  
	res = db:execute(sql)
	db:commit()

	_dbg(res)

	db:close()
	env:close()
	return res
end 

function gscenes_add(self,itag,iname,igids,ilum,ict,ihue)
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile)
	local sql, res, r, sid, splitlist, k, v

	-- return if the same name scenes is exist already
	sql = "SELECT * FROM groups WHERE sta = 44 AND name = " .. "\'" .. iname .. "\'"
	_dbg(sql)
	res = db:execute(sql)
	if res ~= nil then
		for r in rows(res) do 
			printtab(r)
			res:close()
			db:close()
			env:close()
			return 0
		end
		res:close()
	end

	-- add a scenes-group
	sql = "INSERT INTO groups (tag,name,sta,dids,lum,ct,hue) VALUES "
	sql = sql .. "(" .. itag .. ",\'" .. iname .. "\', 44,\'" .. igids .. "\'," .. ilum .. "," .. ict .. "," .. ihue .. ")"
	_dbg(sql)
	db:setautocommit(false)
	res = db:execute(sql)
	db:commit()
	_dbg(res)

	-- get the scenes-group's id added above
	sql = "SELECT id FROM groups WHERE sta = 44 AND name = " .. "\'" .. iname .. "\'"
	_dbg(sql)
	res = db:execute(sql)
	if res ~= nil then
 		for r in rows(res) do
 			sid =  r["id"] or ""
			printtab(r)
		end
		res:close()
	end 

	if sid ~= nil then 
		-- gids is the room-group ids, update the room-group's sid
		if (igids ~= nil) then
			splitlist = {}
			string.gsub(igids, '[^,]+', function(w) table.insert(splitlist, w) end) 
			for k,v in ipairs(splitlist) do
				sql = "UPDATE groups SET sid = " .. sid .. " WHERE sta = 55 AND id = " .. v
				_dbg(sql)
				res = db:execute(sql)
				db:commit()
				_dbg(res)
			end
		end
	end

	db:close()
	env:close()
	return res 
end 

-- test function
function gscenes_setdefault(self)
	gscenes_add(self, 0, 'Watching movie', '1', 150, 1, 0)
	gscenes_add(self, 0, 'Meet visitor', '1', 150, 1, 0)
	gscenes_add(self, 0, 'Reading book', '1', 150, 1, 0)
	gscenes_add(self, 0, 'Normal', '1', 150, 1, 0)
	gscenes_add(self, 0, 'Cleaning', '1', 150, 1, 0)
	gscenes_add(self, 0, 'Wake up', '1', 150, 1, 0)
end


function gscenes_modify(self,inameorg,itag,iname,igids,ilum,ict,ihue)
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile)
	local sql, res, r, sid, splitlist, k, v

	-- find the scene's id by name
	sql = "SELECT id FROM groups WHERE sta = 44 AND name = " .. "\'" .. inameorg .. "\'"
	_dbg(sql)
	res = db:execute(sql)
	if res ~= nil then
 		for r in rows(res) do
 			sid =  r["id"] or ""
			printtab(r)
		end
		res:close()
	end

	if sid ~= nil then
		-- update name,dids,lum,ct,hue
		-- sql = "UPDATE groups SET name = " .. "\'" .. iname .. "\', dids = " .. "\'" .. igids .. "\', lum = " .. ilum .. ", ct = " .. ict .. ", hue = " .. ihue .. " WHERE sta = 44 AND id = " .. sid
		sql = "UPDATE groups SET "
		sql = sql .. "name = \'" .. iname .. "\'"
		sql = sql .. ", dids = \'" .. igids .."\'"
		sql = sql .. ", lum = " .. ilum
		sql = sql .. ", ct = " .. ict
		sql = sql .. ", hue = " .. ihue
		sql = sql .. " WHERE sta = 44 AND id = " .. sid

		_dbg(sql)
		db:setautocommit(false)
		res = db:execute(sql)
		db:commit()
		_dbg(res)

		-- set room-group's which sid is above to 0
		sql = "SELECT id FROM groups WHERE sta = 55 AND sid = " .. sid
		_dbg(sql)
		res = db:execute(sql)
		if res ~= nil then
			for r in rows(res) do
				sql = "UPDATE groups SET sid = 0 WHERE sta = 55 AND id = " .. r["id"]
				_dbg(sql)
				res = db:execute(sql)
				db:commit()
				_dbg(res)
			end
		end

		-- gids is the room-group ids, update the room-group's sid
		if (igids ~= nil) then
			splitlist = {}
			string.gsub(igids, '[^,]+', function(w) table.insert(splitlist, w) end) 
			for k,v in ipairs(splitlist) do
				sql = "UPDATE groups SET sid = " .. sid .. " WHERE sta = 55 AND id = " .. v
				_dbg(sql)
				res = db:execute(sql)
				db:commit()
				_dbg(res)
			end
		end
	end
	
	db:close()
	env:close()
	return res 
end

-- ret scenes list, array = {name, tag} * n
function gscenes_load(self)
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile)
	local sql, res, r, array, i

	-- get scence's list
	-- sql = "SELECT name, tag FROM scenes"
	sql = "SELECT name, tag FROM groups WHERE sta = 44"
	_dbg(sql)

	array = {}
	res = db:execute(sql)
	if res ~= nil then
		i = 1
 		for r in rows(res) do  
			array[i] = r["name"]
			array[i+1] = r["tag"]
			_dbg(array[i] .. " " .. array[i+1])
			printtab(r)
			i = i + 2
		end
		res:close()
	end 

	db:close()
	env:close()
	return array
end


-- get scenes' more info
-- ret: onoff, lum, ct, hue
function gscenes_loadmore(self, id)
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile)
	local sql, res, r, onoff, lum, ct, hue

	-- sql = "SELECT name, tag FROM scenes"
	sql = "SELECT onoff, lum, ct, hue FROM groups WHERE sta = 44 AND id = "..id
	_dbg(sql)

	res = db:execute(sql)
	if res ~= nil then
 		for r in rows(res) do  
			onoff = r["onoff"] or "1"
			lum = r["lum"] or "100"
			ct = r["ct"] or "30"
			hue = r["hue"] or "130"
			printtab(r)
		end
		res:close()
	end 

	db:close()
	env:close()
	return onoff, lum, ct, hue
end

-- ret flag: 1-the name is already exist, 0-the name is not exist yet
function gscenes_checkname(self, iname)
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile)
	local sql, res, flag

	sql = "SELECT name FROM groups WHERE sta = 44 AND name = " .. "\'" .. iname .. "\'"
	_dbg(sql)

	flag = 0
	res = db:execute(sql)
	if res ~= nil then
		for r in rows(res) do 
			flag = 1
			printtab(r)
		end
		res:close()
	end

	_dbg(flag)

	db:close()
	env:close()
	return flag
end

-- get id according to the param name
-- ret id: nil or id
function gscenes_getidbyname(self, iname)
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile) 
	local sql, res, r, id

	sql = "SELECT id FROM groups WHERE sta = 44 AND name = " .. "\'" .. iname .. "\'"
	_dbg(sql)

	res = db:execute(sql)
	if res ~= nil then
		for r in rows(res) do
			id = r["id"]
			printtab(r)
		end
		res:close()
	end

	_dbg(id)

	db:close()
	env:close()
	return id
end

-- del user defined scence. not judge wheather it is user defined or not here, judged by up layer(web) functions.
function gscenes_deluserdef(self, iname)
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile)
	local sql, res, sid

	-- find the scene's id by name
	sql = "SELECT id FROM groups WHERE sta = 44 AND name = " .. "\'" .. iname .. "\'"
	_dbg(sql)

	res = db:execute(sql)
	if res ~= nil then
		for r in rows(res) do 
			sid = r["id"]
			printtab(r)
		end
		res:close()
	end

	_dbg(sid)

	-- del the scene by id & reset the room's sid if the sid is the deleted scene.
	if sid ~= nil then
		sql = "DELETE FROM groups WHERE id = " .. sid
		_dbg(sql)

		db:setautocommit(false)
		res = db:execute(sql)
		db:commit() 
		_dbg(res)

		sql = "UPDATE groups SET sid = 0 WHERE sta = 55 AND sid = " .. sid
		_dbg(sql)

		res = db:execute(sql)
		db:commit()
		_dbg(res)
	end

	db:close()
	env:close()
end


function timers_addschedule(self, id, iname, itime, irt, irids, isids)
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile)
	local sql, res, r

	if id == nil then
		-- add a timer
		sql = "INSERT INTO timers (tag,name,onf,time,rt,rids,sids) VALUES "
		sql = sql .. "(0,\'" .. iname .. "\', 0,\'" .. itime .. "\',\'" .. irt .. "\',\'" .. irids .. "\',\'" .. isids .. "\')"
		_dbg(sql)
		db:setautocommit(false)
		res = db:execute(sql)
		db:commit()
		_dbg(res)
	else
		-- update a timer
		sql = "UPDATE timers SET "
		sql = sql .. "name = \'" .. iname .. "\'"
		sql = sql .. ", time = \'" .. itime .. "\'"
		sql = sql .. ", rt = \'" .. irt .. "\'"
		sql = sql .. ", rids = \'" .. irids .. "\'"
		sql = sql .. ", sids = \'" .. isids .. "\'"
		sql = sql .. " WHERE id = " .. id
		_dbg(sql)
		db:setautocommit(false)
		res = db:execute(sql)
		db:commit()
		_dbg(res)
	end

	db:close()
	env:close()
	return res 
end 

function timers_deleteschedule(self, id)
	return del('timers',id)
end

-- timer
function timers_loadschedule(self)
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile)
	local sql, res, r, array, i

	sql = "SELECT * FROM timers"
	_dbg(sql)

	array = {}
	res = db:execute(sql)
	if res ~= nil then
		i = 1
 		for r in rows(res) do 
			array[i] = r["id"] or ""
			array[i+1] = r["name"] or ""
			array[i+2] = r["time"] or ""
			array[i+3] = r["rt"] or ""
			array[i+4] = r["onf"] or "0"
			_dbg(array[i] .. " " .. array[i+1] .. " " .. array[i+2] .. " " .. array[i+3] .. " " .. array[i+4])
			printtab(r)
			i = i + 5
		end
		res:close()
	end

	db:close()
	env:close()
	return array
end

function timers_setonf(self,id,ionf)  
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile)
	local sql, res

	sql = "UPDATE timers SET onf = \'" .. ionf .. "\' WHERE id = " .. id
	_dbg(sql)

	db:setautocommit(false)  
	res = db:execute(sql)
	db:commit()

	_dbg(res)

	db:close()  
	env:close() 
	return res  
end

function timers_loadaddschedule(self, id)
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile)
	local sql, res, r, array, i, rarray, ri, sarray, si, splitlist, k, v, rids, sids, rsarray, rsi

	-- get all rooms' list
	sql = "SELECT id, tag, name FROM groups WHERE sta = 55"
	_dbg(sql)

	rarray = {}
	res = db:execute(sql)
	if res ~= nil then
		i = 1
 		for r in rows(res) do 
 			rarray[i] = r["id"] or ""
			rarray[i+1] = r["tag"] or ""
			rarray[i+2] = r["name"] or ""
			_dbg(rarray[i] .. " " .. rarray[i+1] .. " " .. rarray[i+2])
			printtab(r)
			i = i + 3
		end
		res:close()
	end 

	-- get all scences' list
	sql = "SELECT id, tag, name, dids FROM groups WHERE sta = 44"
	_dbg(sql)
	sarray = {}
	res = db:execute(sql)
	if res ~= nil then
		i = 1
 		for r in rows(res) do 
 			sarray[i] = r["id"] or ""
			sarray[i+1] = r["tag"] or ""
			sarray[i+2] = r["name"] or ""
			sarray[i+3] = r["dids"] or "0"
			_dbg(sarray[i] .. " " .. sarray[i+1] .. " " .. sarray[i+2] .. " " .. sarray[i+3])
			printtab(r)
			i = i + 4
		end
		res:close()
	end

	-- get id - rids -sids
	if id ~= nil then
		sql = "SELECT * FROM timers WHERE id = " .. id
		_dbg(sql)
		res = db:execute(sql)
		if res ~= nil then
			for r in rows(res) do 
				rids = r["rids"] or ""
				sids = r["sids"] or ""
				rsarray = {}
				splitlist = {}
				string.gsub(rids, '[^,]+', function(w) table.insert(splitlist, w) end )
				i = 1
				for k, v in ipairs(splitlist) do
					rsarray[i] = v
					i = i + 2
				end
				splitlist = {}
				string.gsub(sids, '[^,]+', function(w) table.insert(splitlist, w) end )
				i = 2
				for k, v in ipairs(splitlist) do
					rsarray[i] = v
					-- si = 1
					-- while (sarray[si] ~= nil) do
					-- 	if tonumber(sarray[si]) == tonumber(v) then rsarray[i] = sarray[si+2] end
					-- 	si = si + 4
					-- end
					i = i + 2
				end
			end
			res:close()
		end
	end

	-- check every scence's dids if content param id
	i, ri, si = 1, 1, 1
	array = {}
	while (rarray[ri] ~= nil) do
		array[i] = rarray[ri]
		array[i+1] = rarray[ri+2]
		array[i+2] = "\""
		array[i+3] = ""
		while (sarray[si] ~= nil) do
			splitlist = {}
			string.gsub(sarray[si+3], '[^,]+', function(w) table.insert(splitlist, w) end ) 
			for k,v in ipairs(splitlist) do
				if tonumber(v) == tonumber(rarray[ri]) then 
					if si == 1 then
						array[i+2] = array[i+2] .. sarray[si+2]
					else
						array[i+2] = array[i+2] .. "\",\"" .. sarray[si+2]
					end
				end
			end
			si = si + 4
		end
		array[i+2] = array[i+2] .. "\""

		if rsarray ~= nil then
			rsi = 1
			while (rsarray[rsi] ~= nil) do
				if tonumber(rsarray[rsi]) == tonumber(array[i]) then array[i+3] = rsarray[rsi+1] end
				if tonumber(array[i+3]) == 0 then array[i+3] = "" end 
				rsi = rsi + 2
			end
		end

		_dbg(array[i] .. " " .. array[i+1] .. " " .. array[i+2] .. " " .. array[i+3])
		i = i + 4
		ri = ri + 3
	end

	db:close()
	env:close()
	return array
end

function devices_loadelectrityanalyze(self)
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile)
	local sql, res, r, array, i

	sql = "SELECT id, name, addr, onh, offh, uenh, uenl, watt FROM devices"
	_dbg(sql)

	array = {}
	res = db:execute(sql)
	if res ~= nil then
		i = 1
 		for r in rows(res) do 
			array[i] = r["id"] or ""
			array[i+1] = r["name"] or ""
			array[i+2] = r["addr"] or ""
			array[i+3] = r["onh"] or "0"
			array[i+4] = r["offh"] or "0"
			array[i+5] = r["uenh"] or "0"
			array[i+6] = r["uenl"] or "0"
			array[i+7] = r["watt"] or "0"
			_dbg(array[i] .. ", " .. array[i+1] .. ", " .. array[i+2] .. ", " .. array[i+3] .. ", " .. array[i+4])
			_dbg(array[5] .. ", " .. array[i+6] .. ", " .. array[i+7])
			printtab(r)
			i = i + 8
		end
		res:close()
	end 

	db:close()
	env:close()
	return array
end

function devices_loadelectrityanalyzebyaddr(self, iaddr)
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile)
	local sql, res, r, array, i

	sql = "SELECT id, name, addr, onh, offh, uenh, uenl, watt FROM devices WHERE addr = "..iaddr
	_dbg(sql)

	array = {}
	res = db:execute(sql)
	if res ~= nil then
		i = 1
 		for r in rows(res) do 
			array[i] = r["id"] or ""
			array[i+1] = r["name"] or ""
			array[i+2] = r["addr"] or ""
			array[i+3] = r["onh"] or "0"
			array[i+4] = r["offh"] or "0"
			array[i+5] = r["uenh"] or "0"
			array[i+6] = r["uenl"] or "0"
			array[i+7] = r["watt"] or "0"
			-- _dbg(array[i] .. ", " .. array[i+1] .. ", " .. array[i+2] .. ", " .. array[i+3] .. ", " .. array[i+4])
			-- _dbg(array[5] .. ", " .. array[i+6] .. ", " .. array[i+7]
			printtab(r)
			i = i + 8
		end
		res:close()
	end 

	db:close()
	env:close()
	return array
end

function testtmpdb(self)
	local dbfiletmp = "/tmp/zgw.db"
	local env = qlite3.sqlite3()
	local db = env:connect(dbfiletmp)
	local sql, res, r, array, i

	sql = "SELECT id, name, addr, onh, offh, uenh, uenl, watt FROM devices"
	_dbg(sql)

	array = {}
	res = db:execute(sql)
	if res ~= nil then
		i = 1
 		for r in rows(res) do 
			array[i] = r["id"] or ""
			array[i+1] = r["name"] or ""
			array[i+2] = r["addr"] or ""
			array[i+3] = r["onh"] or "0"
			array[i+4] = r["lum"] or "0"
			array[i+5] = r["onoff"] or "0"
			array[i+6] = r["uenl"] or "0"
			array[i+7] = r["watt"] or "0"
			_dbg(array[i] .. ", " .. array[i+1] .. ", " .. array[i+2] .. ", " .. array[i+3] .. ", " .. array[i+4])
			_dbg(array[5] .. ", " .. array[i+6] .. ", " .. array[i+7])
			printtab(r)
			i = i + 8
		end
		res:close()
	end 

	db:close()
	env:close()
	return array
end

-- business web 20180302 by EmmaZheng
-- BUS_ROOM: GroupList(dids)? ScenceID(sid), sta = 33 = new
-- BUS_GROUP: DevList(dids), sta = 55 = grooms
-- BUS_SCENCE: RoomID(sid), ParaList(dids), sta = 45 != gscenes
function bus_grooms_add(self, itag, iname, igids, idesc)
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile)
	local sql, res

	sql = "INSERT INTO groups (tag,name,dids,note,sta) VALUES ("
	sql = sql .. itag .. ",\'" .. iname .. "\',\'" .. igids .. "\',\'" .. idesc ..  "\', 33)"
	_dbg(sql)
	db:setautocommit(false);
	res = db:execute(sql)
	db:commit()
	_dbg(res)

	db:close()
	env:close()
	return res 
end

function bus_grooms_del(self, id)
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile)
	local sql, res

	sql = "DELETE FROM groups WHERE sta = 33 AND id = " .. id
	_dbg(sql)

	db:setautocommit(false)
	res = db:execute(sql)
	db:commit() 
	_dbg(res)

	-- tbd: weather to delete the scences of this room?

	db:close()
	env:close()
	return res
end


function bus_grooms_load(self)
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile)
	local sql, res, r, array, i, gids, dids, splitlist, k, v, dsplitlist, dk, dv,number
	local arrayitem = 5

	sql = "SELECT id, tag, name, dids, note FROM groups WHERE sta = 33"
	_dbg(sql)

	array = {}
	res = db:execute(sql)
	if res ~= nil then
		i = 1
 		for r in rows(res) do 
			array[i] = r["id"] or ""
			array[i+1] = r["tag"] or ""
			array[i+2] = r["name"] or ""
			array[i+3] = r["dids"]
			array[i+4] = r["note"] or ""
			_dbg(array[i] .. " " .. array[i+1] .. " " .. array[i+2] .. " " .. array[i+3] .. " " .. array[i+4])
			printtab(r)
			i = i + arrayitem
		end
		res:close()
	end 

	-- get device number of each groups that belong to the room
	if i > 1 then
		i = 1
		while (array[i] ~= nil) do
			gids = array[i+3]
			array[i+3] = ""
			number = 0
			splitlist = {}
			if gids ~= nil then 
				string.gsub(gids, '[^,]+', function(w) table.insert(splitlist, w) end ) 
			end
			for k, v in ipairs(splitlist) do
				sql = "SELECT dids FROM groups WHERE sta = 55 and id = " .. v
				res = db:execute(sql)
				if res ~= nil then
					for r in rows(res) do 
						dids = r["dids"]
						if dids ~= nil then 
							dsplitlist = {}
							string.gsub(dids, '[^,]+', function(w) table.insert(dsplitlist, w) end ) 
							for dk, dv in ipairs(dsplitlist) do
								number = number + 1
							end
						end
						printtab(r)
					end
				end
				res:close()
			end
			array[i+3] = number
			_dbg(array[i] .. " " .. array[i+1] .. " " .. array[i+2] .. " " .. array[i+3] .. " " .. array[i+4])
			i = i + arrayitem
		end
	end

	db:close()
	env:close()
	-- array: id, tag, name, devNumber, desc
	return array
end

function bus_grooms_loadctrl(self)
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile)
	local sql, res, r, array, i, sid
	local arrayitem = 6

	sql = "SELECT id, tag, name, sid, onoff, lum FROM groups WHERE sta = 33"
	_dbg(sql)

	array = {}
	res = db:execute(sql)
	if res ~= nil then
		i = 1
 		for r in rows(res) do 
			array[i] = r["id"] or ""
			array[i+1] = r["tag"] or ""
			array[i+2] = r["name"] or ""
			array[i+3] = r["sid"]
			array[i+4] = r["onoff"] or "0"
			array[i+5] = r["lum"] or "254"
			printtab(r)
			i = i + arrayitem
		end
		res:close()
	end 

	-- get the name of scenes from sid
	if i > 1 then
		i = 1
		while (array[i] ~= nil) do
			if array[i+3] ~= nil then
				sid = array[i+3]
				sql = "SELECT name FROM groups WHERE sta = 45 and id = " .. sid
				_dbg(sql)
				res = db:execute(sql)
				if res ~= nil then
					for r in rows(res) do 
						array[i+3] = r["name"]
						printtab(r)
					end
				res:close()
			end
			else array[i+3] = ""
			end
			if array[i+3] == 0 then _dbg("0:" .. array[i+3]) array[i+3] = "" end
			i = i + arrayitem
		end
	end

	db:close()
	env:close()
	-- array: id, tag, name, s_name, onoff, lum
	return array
end

function bus_grooms_loadgroupandscenes(self, iroomid, iscenesname)
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile)
	local sql, res, r, array, s_array, values, i, j, gids, splitlist, k, v, number
	local arrayitem = 7
	local d_array, di

	sql = "SELECT dids FROM groups WHERE sta = 33 and id = " .. iroomid
	_dbg(sql)
	res = db:execute(sql)
	if res ~= nil then
 		for r in rows(res) do 
 			gids = r["dids"]
			printtab(r)
		end
		res:close()
	end 

	splitlist = {}
	if gids ~= nil then
		string.gsub(gids, '[^,]+', function(w) table.insert(splitlist, w) end ) 
	end
	array = {}
	d_array = {}
	i = 1
	di = 1
	number = 0
	for k, v in ipairs(splitlist) do
		sql = "SELECT id, name, ott, onoff, lum, ct, hue, dids FROM groups WHERE sta = 55 and id = " .. v
		_dbg(sql)
		res = db:execute(sql)
		if res ~= nil then
			for r in rows(res) do
				array[i] = r["id"]
				array[i+1] = r["name"]
				array[i+2] = r["ott"] or "1"
				array[i+3] = r["onoff"] or "0"
				array[i+4] = r["lum"] or "-1"
				array[i+5] = r["ct"] or "-1"
				array[i+6] = r["hue"] or "-1"
				d_array[di] = r["dids"]
				number = number + 1
				printtab(r)
			end
			res:close()
		end
		i = i + arrayitem
		di = di + 1
	end

	sql = "SELECT name FROM groups WHERE sta = 45 and sid = " .. iroomid
	_dbg(sql)
	s_array = "\""
	i = 1
	res = db:execute(sql)
	if res ~= nil then
 		for r in rows(res) do
 			if i == 1 then
 				s_array = s_array .. r["name"]
 			else
 				s_array = s_array .. "\",\"" .. r["name"]
 			end
			printtab(r)
			i = i + 1
		end
		s_array = s_array .. "\""
		res:close()
	end 

	if iscenesname ~= "-1" then
		sql = "SELECT dids FROM groups WHERE sta = 45 and name = \'" .. iscenesname .. "\'"
		_dbg(sql)
		res = db:execute(sql)
		if res ~= nil then
			for r in rows(res) do
				values = r["dids"]
				printtab(r)
			end
			res:close()
		end
		if values ~= nil then
			i = 1
			j = 0
			splitlist = {}
			string.gsub(values, '[^,]+', function(w) table.insert(splitlist, w) end ) 
			for k, v in ipairs(splitlist) do
				j = j + 1
				if j <= number then
					array[i+3] = v
				elseif j <= 2*number then
					array[i+4] = v
				elseif j <= 3*number then
					array[i+5] = v
				elseif j <= 4*number then
					array[i+6] = v
				end
				i = i + arrayitem
				if math.mod(j, number) == 0 then i = 1 end
			end
		end
	else
		if d_array ~= nil then
			i = 1
			di = 1
			while (d_array[di] ~= nil) do
				splitlist = {}
				string.gsub(d_array[di], '[^,]+', function(w) table.insert(splitlist, w) end ) 
				for k, v in ipairs(splitlist) do
					sql = "SELECT onoff, lum, ct, hue FROM devices WHERE addr = " .. v
					_dbg(sql)
					res = db:execute(sql)
					if res ~= nil then
						for r in rows(res) do 
							array[i+3] = r["onoff"] or "0"
							array[i+4] = r["lum"] or "254"
							array[i+5] = r["ct"] or "1"
							array[i+6] = r["hue"] or "1"
							printtab(r)
						end
						res:close()
					end
					break
				end
				i = i + arrayitem
				di = di +1
			end
		end
	end

	db:close()
	env:close()

	-- array: id, name, tag, onoff, lum, ct, hue
	return array, s_array
end

function bus_grooms_getnumber(self)
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile)
	local sql, res, r, number

	number = 0
	sql = "SELECT id FROM groups WHERE sta = 33"
	_dbg(sql)
	res = db:execute(sql)
	if res ~= nil then
 		for r in rows(res) do 
 			number = number + 1
			printtab(r)
		end
		res:close()
	end 

	db:close()
	env:close()

	-- array: id, name, tag, onoff, lum, ct, hue
	return number
end

function bus_grooms_setsid(self, id, isid)
	local env = qlite3.sqlite3()  
	local db = env:connect(dbfile)
	local sql, res

	sql = "UPDATE groups SET sid = " .. isid .. " WHERE sta = 33 and id = " .. id
	_dbg(sql)

	db:setautocommit(false)
	res = db:execute(sql)
	db:commit()
	_dbg(res)

	db:close()  
	env:close()
	return res 
end

function bus_grooms_setonoff(self, id, ionoff)
	local env = qlite3.sqlite3()  
	local db = env:connect(dbfile)
	local sql, res

	sql = "UPDATE groups SET onoff = " .. ionoff .. " WHERE sta = 33 and id = " .. id
	_dbg(sql)

	db:setautocommit(false)
	res = db:execute(sql)
	db:commit()
	_dbg(res)

	db:close()  
	env:close()
	return res
end

function bus_grooms_setlum(self, id, ilum)
	local env = qlite3.sqlite3()  
	local db = env:connect(dbfile)
	local sql, res

	sql = "UPDATE groups SET lum = " .. ilum .. " WHERE sta = 33 and id = " .. id
	_dbg(sql)

	db:setautocommit(false)
	res = db:execute(sql)
	db:commit()
	_dbg(res)

	db:close()  
	env:close()
	return res
end

function bus_ggroups_add(self,iname,idaddrs)
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile)
	local sql, res, splitlist, k, v, temp, tag

	tag = 61
	if idaddrs ~= nil then
		array = {}
		i = 1
		splitlist = {}
		string.gsub(idaddrs, '[^,]+', function(w) table.insert(splitlist, w) end ) 
		for k, v in ipairs(splitlist) do
			sql = "SELECT tag FROM devices WHERE addr = " .. v
			_dbg(sql)
			res = db:execute(sql)
			if res ~= nil then
 				for r in rows(res) do
 					temp = tonumber(r["tag"])
 					if tag < temp then tag = temp end
					printtab(r)
				end
				res:close()
			end 
		end
	end

	if tag == 61 then tag = 1 
	elseif tag == 62 then tag = 2
	elseif tag == 63 then tag = 3
	elseif tag == 64 then tag = 4 
	else tag = 1 end

	sql = "INSERT INTO groups (name,dids,ott,tag,sta) VALUES (\'" 
	sql = sql .. iname .. "\',\'" .. idaddrs .. "\'," .. tag .. ", 1, 55)"
	_dbg(sql)

	db:setautocommit(false)
	res = db:execute(sql)
	db:commit()

	_dbg(res)

	db:close()
	env:close()
	return res  
end 


function bus_ggroups_load(self)
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile)
	local sql, res, r, array, i, dids, splitlist, k, v
	local arrayitem = 3

	sql = "SELECT id, name, dids FROM groups WHERE sta = 55"
	_dbg(sql)

	array = {}
	res = db:execute(sql)
	if res ~= nil then
		i = 1
 		for r in rows(res) do 
			array[i] = r["id"] or ""
			array[i+1] = r["name"] or ""
			array[i+2] = 0
			dids = r["dids"]
			-- caculate the device number from dids
			if dids ~= nil then 
				splitlist = {}
				string.gsub(dids, '[^,]+', function(w) table.insert(splitlist, w) end ) 
				for k, v in ipairs(splitlist) do
					array[i+2] = array[i+2] + 1
				end
			end
			_dbg(array[i] .. " " .. array[i+1] .. " " .. array[i+2])
			printtab(r)
			i = i + arrayitem
		end
		res:close()
	end 
	db:close()
	env:close()
	-- array: id, name, devNumber
	return array
end

function bus_ggroups_loadbyroomid(self, iroomid)
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile)
	local sql, res, r, array, i, dids, splitlist, k, v
	local arrayitem = 7

	sql = "SELECT dids FROM groups WHERE sta = 33 and id = " .. iroomid
	_dbg(sql)

	res = db:execute(sql)
	if res ~= nil then
 		for r in rows(res) do 
 			dids = r["dids"]
			printtab(r)
		end
		res:close()
	end 

	-- caculate the device number from dids
	if dids ~= nil then 
		array = {}
		i = 1
		splitlist = {}
		string.gsub(dids, '[^,]+', function(w) table.insert(splitlist, w) end ) 
		for k, v in ipairs(splitlist) do
			sql = "SELECT id, name, ott, onoff, lum, ct, hue FROM groups WHERE sta = 55 and id = " .. v
			_dbg(sql)
			res = db:execute(sql)
			if res ~= nil then
 				for r in rows(res) do
 					array[i] = r["id"] or ""
 					array[i+1] = r["name"] or ""
 					array[i+2] = r["ott"] or "1"
 					array[i+3] = r["onoff"] or "0"
 					array[i+4] = r["lum"] or "254"
 					array[i+5] = r["ct"] or "1"
 					array[i+6] = r["hue"] or "0"
					printtab(r)
				end
				res:close()
			end 
			i = i + arrayitem
		end
	end

	db:close()
	env:close()
	-- array: id, name, tag, onoff, lum, ct, lue
	return array
end

function bus_gscenes_add(self, iname, isid, idids)
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile)
	local sql, res, ott

	-- get bus_grooms' ott, the ott is used to be the scence's id which will store in the light
	sql = "SELECT ott FROM groups WHERE sta = 33 AND id = " .. isid
	_dbg(sql)
	res = db:execute(sql)
	if res ~= nil then
 		for r in rows(res) do 
 			ott = r["ott"]
			printtab(r)
		end
		res:close()
	end 

	if ott == nil then ott = 0 end
	ott = ott + 1

	-- update bus_grooms' ott
	sql = "UPDATE groups SET ott = " .. ott .. " WHERE sta = 33 and id = " .. isid
	_dbg(sql)
	db:setautocommit(false)
	res = db:execute(sql)
	db:commit()
	_dbg(res)

	sql = "INSERT INTO groups (name,dids,sid,ott,sta) VALUES (\'" 
	sql = sql .. iname .. "\',\'" .. idids .. "\'," .. isid .. ", " .. ott .. ", 45)"
	_dbg(sql)

	res = db:execute(sql)
	db:commit()

	_dbg(res)

	db:close()
	env:close()
	return res  
end

function bus_gscenes_del(self, irid, id)
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile)
	local sql, res, sid

	sql = "SELECT sid FROM groups WHERE sta = 33 AND id = " .. irid
	_dbg(sql)
	res = db:execute(sql)
	if res ~= nil then
 		for r in rows(res) do 
 			sid = r["sid"]
			printtab(r)
		end
		res:close()
	end 

	sql = "DELETE FROM groups WHERE sta = 45 AND id = " .. id
	_dbg(sql)

	db:setautocommit(false)
	res = db:execute(sql)
	db:commit() 
	_dbg(res)

	-- tbd: weather to delete the scences of this room?
	if tonumber(sid) == id then
		sql = "UPDATE groups SET sid = 0 WHERE sta = 33 and id = " .. irid
		_dbg(sql)
		res = db:execute(sql)
		db:commit()
		_dbg(res)
	end

	db:close()
	env:close()
	return res
end

function bus_gscenes_loadbyroomid(self, iroomid)
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile)
	local sql, res, r, array, i
	local arrayitem = 2

	sql = "SELECT id, name FROM groups WHERE sta = 45 and sid = " .. iroomid
	_dbg(sql)

	array = {}
	res = db:execute(sql)
	if res ~= nil then
		i = 1
 		for r in rows(res) do 
			array[i] = r["id"] or ""
			array[i+1] = r["name"] or ""
			_dbg(array[i] .. " " .. array[i+1])
			printtab(r)
			i = i + arrayitem
		end
		res:close()
	end 
	db:close()
	env:close()
	-- array: id, name
	return array
end

function bus_gscenes_getidbyname(self, iname)
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile)
	local sql, res, r, id

	sql = "SELECT id FROM groups WHERE sta = 45 and name = " .. "\'" .. iname .. "\'"
	_dbg(sql)
	res = db:execute(sql)
	if res ~= nil then
		i = 1
 		for r in rows(res) do
 			id = r["id"] 
			printtab(r)
		end
		res:close()
	end 
	db:close()
	env:close()

	return id
end

function bus_gscenes_getnumbyroomid(self, id)
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile)
	local sql, res, r, number

	number = 0
	sql = "SELECT id FROM groups WHERE sta = 45 and sid = " .. id
	_dbg(sql)
	res = db:execute(sql)
	if res ~= nil then
		i = 1
 		for r in rows(res) do
 			number = number + 1
 			id = r["id"] 
			printtab(r)
		end
		res:close()
	end 
	db:close()
	env:close()

	return number
end

function bus_gscenes_getott(self, id)
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile)
	local sql, res, r, ott

	ott = 0
	sql = "SELECT ott FROM groups WHERE sta = 45 and id = " .. id
	_dbg(sql)
	res = db:execute(sql)
	if res ~= nil then
		i = 1
 		for r in rows(res) do
 			ott = r["ott"] or 0
			printtab(r)
		end
		res:close()
	end 
	db:close()
	env:close()

	return ott
end

function bus_devices_load(self)
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile)
	local sql, res, r, array, i
	local arrayitem = 3

	sql = "SELECT name, tag, addr FROM devices"
	_dbg(sql)

	array = {}
	res = db:execute(sql)
	if res ~= nil then
		i = 1
 		for r in rows(res) do 
			array[i] = r["name"] or ""
			array[i+1] = r["tag"] or ""
			array[i+2] = r["addr"] or ""
			_dbg(array[i] .. ", " .. array[i+1] .. ", " .. array[i+2])
			printtab(r)
			i = i + arrayitem
		end
		res:close()
	end 

	db:close()
	env:close()
	return array
end

--
--
--  Next code is cloud server API
--  
--

-- MH == 1003
function  requestDeviceList( self )
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile)
	local sql, res, r, array, i

	sql = "SELECT tag, addr, mac, ltt, lqi FROM devices"
	_dbg(sql)

	array = {}
	res = db:execute(sql)
	if res ~= nil then
		i = 1
		for r in rows(res) do
			array[i]   = r["tag"] or ""
			array[i+1] = r["addr"] or ""
			array[i+2] = r["mac"] or ""
			array[i+3] = r["ltt"] or ""
			array[i+4] = r["lqi"] or 0
			printtab(r)
			i = i + 5
		end
		res:close()
	end

	db:close()
	env:close()

	return array
end

-- return :
-- 1: exist gid on table     
-- 0: not exist gid on table
function  cld_check_gid_exist( self, gid )
	local env = qlite3.sqlite3()
	local db  = env:connect(dbfile)
	local sql, res, count = 0

	sql = "SELECT gid FROM groups WHERE gid = "..gid
	_dbg(sql)

	res = db:execute(sql)

	count = 0
	for r in rows(res) do
		count = count + 1
	end

	res:close()
	db:close()
	env:close()

	_dbg(count)
	if (count > 0) then
		return 1
	end
	
	return 0
end
--cld_check_gid_exist( self, 99 )

-- return :
-- nil: insert error  >=1 insert row count
function  cld_add_group_data(self, gid, devList)
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile)
	local sql, res

	sql = "INSERT INTO groups (gid,dids) VALUES (" .. gid .. ",\'" .. devList .. "\')"
	_dbg(sql)

	db:setautocommit(false)  -- false , we control commit to database time, but we must use commit()
	res = db:execute(sql)
	db:commit()

	_dbg(res)


	db:close()
	env:close()
	return res 
end
--cld_add_group_data(self, 2, ",1,2,3")

function cld_group_list(self)
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile)
	local sql, res

	sql = "SELECT * FROM groups"
	_dbg(sql)

	res = db:execute(sql)
	for r in rows(res) do
		printtab(r)
	end

	res:close()
	db:close()
	env:close()
end
--cld_group_list(self)

-- paraType: 0: int  , 1: text
-- return :
-- 0: delete error  >=1 delete row count
function delete_recode_by_tablename_and_content(self, tableName, titleName, content, paraType)
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile)
	local sql, res

	if (paraType == 0) then
		sql = "DELETE FROM " .. tableName .. " WHERE " .. titleName .. " = " .. content
	elseif (paraType == 1) then
		sql = "DELETE FROM " .. tableName .. " WHERE " .. titleName .. " = " .. "\'" .. content .. "\'"
	end	
	_dbg(sql)

	db:setautocommit(false)
	res = db:execute(sql)
	db:commit()
	_dbg(res)

	db:close()
	env:close()
	return res
end
--delete_recode_by_tablename_and_content(self, 'grouptask', 'tid', 3, 0)

-- paraType:   paraType  |  update title type  |  src title type
--                 0              int                int
--				   1              int                text
--                 2              text               int
--                 3              text               text
-- return :
-- 0: update error  >=1 update row count
function update_recode_by_tablename_and_content(self, tableName, updateTitleName, updateContent, srcTitleName, srcContent, paraType)
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile)
	local sql, res

	if (paraType == 0) then
		sql = "UPDATE " .. tableName .. " SET " .. updateTitleName .. " = " .. updateContent .. " WHERE " 
		sql = sql .. srcTitleName .. " = " ..  srcContent
	elseif (paraType == 1) then
		sql = "UPDATE " .. tableName .. " SET " .. updateTitleName .. " = " .. updateContent .. " WHERE " 
		sql = sql .. srcTitleName .. " = \'" ..  srcContent .. "\'"
	elseif (paraType == 2) then
		sql = "UPDATE " .. tableName .. " SET " .. updateTitleName .. " = \'" .. updateContent .. "\' WHERE " 
		sql = sql .. srcTitleName .. " = " ..  srcContent 
	elseif (paraType == 3) then
		sql = "UPDATE " .. tableName .. " SET " .. updateTitleName .. " = \'" .. updateContent .. "\' WHERE " 
		sql = sql .. srcTitleName .. " = \'" ..  srcContent .. "\'"
	end	
	_dbg(sql)

	db:setautocommit(false)
	res = db:execute(sql)
	db:commit()
	_dbg(res)

	db:close()
	env:close()
	return res
end

-- paraType:  0: int    1: text
-- return value
-- not get: nil     
-- get: integer or text
function select_recode_by_tablename_and_content(self, tableName, resultTitleName, ifTitleName, ifValue, paraType)
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile)
	local sql, res, r, resultValue

	if (paraType == 0) then
		sql = "SELECT ".. resultTitleName .." FROM ".. tableName .." WHERE ".. ifTitleName .. " = " .. ifValue
	elseif (paraType == 1) then
		sql = "SELECT ".. resultTitleName .." FROM ".. tableName .." WHERE ".. ifTitleName .. " = \'" .. ifValue .. "\'"
	end
	_dbg(sql)

	res = db:execute(sql)

	for r in rows(res) do 
		resultValue = r[resultTitleName]
		printtab(r)
	end

	_dbg(resultValue)

	res:close()
	db:close()
	env:close()
	return resultValue
end

function cld_delete_group_data(self, gid)
	return delete_recode_by_tablename_and_content(self, 'groups', 'gid', gid, 0)
end
--cld_delete_group(self, 10)


function cld_updata_group_data(self, gid, devList)
	return update_recode_by_tablename_and_content(self, 'groups', 'dids', devList, 'gid', gid, 2)
end
--cld_updata_group_data(self, 4, ',7,8,9')


function cld_reset_progress_status_db(self, markId, ctlStatus)
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile)
	local sql, res, count, r

	
	sql = "SELECT id FROM progress WHERE id = " .. markId
	_dbg(sql)

	res = db:execute(sql)

	count = 0
	for r in rows(res) do
		count = count + 1
	end
	_dbg(sql)
	res:close()

	-- 1. check id exist (exist then update, no exist then add)
	if (count == 0) then
		-- no exist
		sql = "INSERT INTO progress (id,psta) VALUES (" .. markId .. "," .. ctlStatus .. ")"
	else
		-- exist
		sql = "UPDATE progress SET psta = " .. ctlStatus .. " WHERE id = " .. markId 
	end

	_dbg(sql)
	db:setautocommit(false)  -- false , we control commit to database time, but we must use commit()
	res = db:execute(sql)
	db:commit()
	_dbg(res)

	
	db:close()
	env:close()
	return res
end
--cld_reset_progress_status_db(self, 1, 2)


-- return value
-- not get: nil     
-- get: integer
function cld_get_progress_status_db(self, markId)
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile)
	local sql, res, r, progressStatus

	sql = "SELECT psta FROM progress WHERE id = " .. markId
	_dbg(sql)

	res = db:execute(sql)

	for r in rows(res) do 
		progressStatus = r["psta"]
		printtab(r)
	end

	_dbg(progressStatus)

	res:close()
	db:close()
	env:close()
	return progressStatus
end
--cld_get_progress_status_db(self, 3)

-- ctlType: 1:add  2:update 3:delete
-- return value: nil:insert error   >=1 : insert count
function cld_ctlgroup_task(self, gid, devl, tid, ctlType)
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile)
	local sql, res

	sql = "INSERT INTO grouptask (tid,gid,devl,cfg,tsta) VALUES ("
	sql = sql .. "\'".. tid .. "\',".. gid .. ",\'" .. devl .. "\'," .. ctlType ..  ",1)"

	_dbg(sql)
	db:setautocommit(false)  -- false , we control commit to database time, but we must use commit()
	res = db:execute(sql)
	db:commit()
	_dbg(res)

	db:close()
	env:close()
	return res
end
--cld_ctlgroup_task(self, 181, ',123,234,345', 3, 1)

function cld_updata_group_task_db(self, tid, tsta)
	return update_recode_by_tablename_and_content(self, 'grouptask', 'tsta', tsta, 'tid', tid, 1)
end

function cld_get_task_status_db(self, tid)
	local env = qlite3.sqlite3()
	local db = env:connect(dbfile)
	local sql, res, r, array, i

	sql = "SELECT tsta, errl FROM grouptask WHERE tid = \'" .. tid .. "\'"
	_dbg(sql)

	array = {}
	res = db:execute(sql)
	if res ~= nil then
		i = 1
		for r in rows(res) do
			array[i]   = r["tsta"] or ""
			array[i+1] = r["errl"] or ""
			printtab(r)
		end
		res:close()
	end

	db:close()
	env:close()

	return array
end