--Copyright (c) 2018 Greeble 
--Chenheng <heng.chen@scjz-led.com>
--ZGW sql V0.0.3 20171023

module("zgw.sql", package.seeall)
qlite3 = require "luasql.sqlite3"  
  
function printtab(t)  
  
         for k,v in pairs(t) do  
  
                   print(k, " = ", v)  
  
         end  
  
end  
  
function rows(cur)  
  
         return function(cur)  
  
                   local t = {}  
  
                   if(nil ~= cur:fetch(t, 'a')) then return t  
  
                   else return nil end  
  
         end , cur  
  
end  

function xprinttab(self,t)  

	printtab(t);   
  
end  
  
function xrows(self,cur)  

	return rows(cur);

end  

--delete a record by id
function del(self,t,id)  
	local env = assert(qlite3.sqlite3());  
	local db = assert(env:connect("zgw.db"));  

	db:setautocommit(false);

	sql = "DELETE FROM " .. t .. " " .. " WHERE id = " .. id;
	print(sql);
    res = assert (db:execute(sql));
	
	assert(db:commit()); 
    print(res);
	db:close();
	env:close(); 
	return res  
end    

--set state to db
function SetSta(self,t,id,ista)  
	local env = assert(qlite3.sqlite3())  
	local db = assert(env:connect("zgw.db"))  

	db:setautocommit(false)  

	sql = "UPDATE " .. t .. " SET sta = \'" .. ista .. "\' WHERE id = " .. id;
	print(sql);  
    res = assert (db:execute(sql));

	assert(db:commit()); 

	print(res);
	db:close()  
	env:close() 
	return res  
end  
 
--set name to db
function SetName(self,t,id,iname)  
	local env = assert(qlite3.sqlite3())  
	local db = assert(env:connect("zgw.db"))  

	db:setautocommit(false)  

	sql = "UPDATE " .. t .. " SET name = \'" .. iname .. "\' WHERE id = " .. id;
	print(sql);  
    res = assert (db:execute(sql));

	assert(db:commit()); 

	print(res);
	db:close()  
	env:close() 
	return res  
end  

--set onoff ott to db
function SetOnOff(self,t,id,ionoff,iott)  
	local env = assert(qlite3.sqlite3())  
	local db = assert(env:connect("zgw.db"))  

	db:setautocommit(false)  

	sql = "UPDATE " .. t .. " SET onoff = " .. ionoff .. " , ott = " .. iott .. " WHERE id = " .. id;
	print(sql);  
    res = assert (db:execute(sql));

	assert(db:commit()); 

	print(res);
	db:close()  
	env:close() 
	return res  
end  

--set lum ltt to db
function SetLum(self,t,id,ilum,iltt)  
	local env = assert(qlite3.sqlite3());  
	local db = assert(env:connect("zgw.db"));  

	db:setautocommit(false);  

	sql = "UPDATE " .. t .. " SET lum = " .. ilum .. " , ltt = " .. iltt .. " WHERE id = " .. id;
	print(sql);  
    res = assert (db:execute(sql));

	assert(db:commit()); 

	print(res);
	db:close();  
	env:close(); 
	return res  
end
  
--set ct ctt to db
function SetCT(self,t,id,ict,ictt)  
	local env = assert(qlite3.sqlite3())  
	local db = assert(env:connect("zgw.db"))  

	db:setautocommit(false)  

	sql = "UPDATE " .. t .. " SET ct = " .. ict .. " , ctt = " .. ictt .. " WHERE id = " .. id;
	print(sql);  
    res = assert (db:execute(sql));

	assert(db:commit()); 

	print(res);
	db:close()  
	env:close() 
	return res  
end
  
--set hue sat htt to db
function SetHue(self,t,id,ihue,isat,ihtt)  
	local env = assert(qlite3.sqlite3());
	local db = assert(env:connect("zgw.db"));  

	db:setautocommit(false);  

	sql = "UPDATE " .. t .. " SET hue = " .. ihue .. " , htt = " .. ihtt .. " , sat = " .. isat .. " WHERE id = " .. id;
	print(sql);  
    res = assert (db:execute(sql));

	assert(db:commit()) ;

	print(res);
	db:close();  
	env:close(); 
	return res  
end

--set tag to db
function SetTag(self,t,id,itag)  
	local env = assert(qlite3.sqlite3())  
	local db = assert(env:connect("zgw.db"))  

	db:setautocommit(false)  

	sql = "UPDATE " .. t .. " SET tag = \'" .. itag .. "\' WHERE id = " .. id;
	print(sql);  
    res = assert (db:execute(sql));

	assert(db:commit()); 

	print(res);
	db:close()  
	env:close() 
	return res  
end  

--get tag by id
function GetTag(self,t,id)  
	local env = assert(qlite3.sqlite3());  
	local db = assert(env:connect("zgw.db"));  

	sql = "SELECT * FROM " .. t .. " WHERE id = " .. id; 
	print(sql);
    res = assert (db:execute(sql));
	
 	for r in rows(res) do  
        tag = r["tag"] ; 
		printtab(r);  
	end 	
	print('tag=',tag);
	res:close();  
	db:close();  
	env:close(); 
	return tag  
end

--get hue sat htt by id
function GetHue(self,t,id)  
	local env = assert(qlite3.sqlite3());  
	local db = assert(env:connect("zgw.db"));  

	sql = "SELECT * FROM " .. t .. " WHERE id = " .. id; 
	print(sql);
    res = assert (db:execute(sql));
	
 	for r in rows(res) do  
        hue = r["hue"] ; sat = r["sat"] ; htt = r["htt"];
		printtab(r);  
	end 	
	print('hue=',hue);
	print('sat=',sat);
	print('htt=',htt);
	res:close();  
	db:close();  
	env:close(); 
	return hue , sat , htt  
end

--get ct ctt by id
function GetCT(self,t,id)  
	local env = assert(qlite3.sqlite3());  
	local db = assert(env:connect("zgw.db"));  

	sql = "SELECT * FROM " .. t .. " WHERE id = " .. id; 
	print(sql);
    res = assert (db:execute(sql));
	
 	for r in rows(res) do  
        ct = r["ct"] ; ctt = r["ctt"];
		printtab(r);  
	end 	
	print('ct = ',ct);
	print('ctt = ',ctt);
	res:close();  
	db:close();  
	env:close(); 
	return ct , ctt  
end

--get lum ltt by id
function GetLum(self,t,id)  
	local env = assert(qlite3.sqlite3());  
	local db = assert(env:connect("zgw.db"));  

	sql = "SELECT * FROM " .. t .. " WHERE id = " .. id; 
	print(sql);
    res = assert (db:execute(sql));
	
 	for r in rows(res) do  
        lum = r["lum"] ; ltt = r["ltt"];
		printtab(r);  
	end 	
	print('lum = ',lum);
	print('ltt = ',ltt);
	res:close();  
	db:close();  
	env:close(); 
	return lum , ltt  
end

--get onoff ott by id
function GetOnOff(self,t,id)  
	local env = assert(qlite3.sqlite3());  
	local db = assert(env:connect("zgw.db"));  

	sql = "SELECT * FROM " .. t .. " WHERE id = " .. id; 
	print(sql);
    res = assert (db:execute(sql));
	
 	for r in rows(res) do  
        onoff = r["onoff"] ; ott = r["ott"];
		printtab(r);  
	end 	
	print('onoff = ',onoff);
	print('ott = ',ott);
	res:close();  
	db:close();  
	env:close(); 
	return onoff , ott  
end

--get name by id
function GetName(self,t,id)  
	local env = assert(qlite3.sqlite3());  
	local db = assert(env:connect("zgw.db"));  

	sql = "SELECT * FROM " .. t .. " WHERE id = " .. id; 
	print(sql);
    res = assert (db:execute(sql));
	
 	for r in rows(res) do  
        name = r["name"] ;
		printtab(r);  
	end 	
	print('name = ',name);
	res:close();  
	db:close();  
	env:close(); 
	return name  
end

--get state by id
function GetSta(self,t,id)  
	local env = assert(qlite3.sqlite3());  
	local db = assert(env:connect("zgw.db"));  

	sql = "SELECT * FROM " .. t .. " WHERE id = " .. id; 
	print(sql);
    res = assert (db:execute(sql));
	
 	for r in rows(res) do  
        sta = r["sta"] ;
		printtab(r);  
	end 	
	print('sta = ',sta);
	res:close();  
	db:close();  
	env:close(); 
	return sta  
end


