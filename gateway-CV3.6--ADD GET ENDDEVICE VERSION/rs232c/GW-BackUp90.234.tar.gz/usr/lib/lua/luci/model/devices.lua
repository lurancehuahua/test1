--Copyright (c) 2018 Greeble 
--Chenheng <heng.chen@scjz-led.com>
--ZGW devices V0.0.3 20171023

module("zgw.devices", package.seeall)
qlite3 = require "luasql.sqlite3"  
fsql = require "zgw.sql"  

--add a record and set tag mac
function add(self,itag,imac)  
	local env = assert(qlite3.sqlite3());  
	local db = assert(env:connect("zgw.db"));  

	db:setautocommit(false);

	sql = "INSERT INTO devices (tag,mac) VALUES (" .. itag .. "," .. imac .. ")";
	print(sql);
    res = assert (db:execute(sql));
	
	assert(db:commit()); 
    print(res);
	db:close();
	env:close(); 
	return res  
end    

--set pos to db
function SetPos(self,id,ipos)  
	local env = assert(qlite3.sqlite3())  
	local db = assert(env:connect("zgw.db"))  

	db:setautocommit(false)  

	sql = "UPDATE devices SET pos = " .. ipos .. " WHERE id = " .. id;
	print(sql);  
    res = assert (db:execute(sql));

	assert(db:commit()); 

	print(res);
	db:close();  
	env:close(); 
	return res  
end  

--get pos by id
function GetPos(self,id)  
	local env = assert(qlite3.sqlite3());  
	local db = assert(env:connect("zgw.db"));  

	sql = "SELECT * FROM devices WHERE id = " .. id; 
	print(sql);
    res = assert (db:execute(sql));
	
 	for r in fsql:xrows(res) do  
        pos = r["pos"] ;
		fsql:xprinttab(r);  
	end 	
	print('pos = ',pos);
	res:close();  
	db:close();  
	env:close(); 
	return pos  
end

--delete a record by id
function del(self,id)  
    res = fsql:del('devices',id);
	return res  
end    

--set state to db
function SetSta(self,id,ista)  
	res = fsql:SetSta('devices',id,ista);
	return res  
end  
 
--set name to db
function SetName(self,id,iname)  
	res = fsql:SetName('devices',id,iname);
	return res  
end  

--set onoff ott to db
function SetOnOff(self,id,ionoff,iott)  
	res = fsql:SetOnOff('devices',id,ionoff,iott);
	return res  
end  

--set lum ltt to db
function SetLum(self,id,ilum,iltt)  
	res = fsql:SetLum('devices',id,ilum,iltt);
	return res  
end
  
--set ct ctt to db
function SetCT(self,id,ict,ictt)  
	res = fsql:SetCT('devices',id,ict,ictt);
	return res  
end
  
--set hue sat htt to db
function SetHue(self,id,ihue,isat,ihtt)  
	res = fsql:SetHue('devices',id,ihue,isat,ihtt);
	return res  
end

--set tag to db
function SetTag(self,id,itag)  
	res = fsql:SetTag('devices',id,itag);
	return res  
end  

--get tag by id
function GetTag(self,id)  
	return fsql:GetTag('devices',id)  
end

--get hue sat htt by id
function GetHue(self,id)  
	return fsql:GetHue('devices',id)  
end

--get ct ctt by id
function GetCT(self,id)  
	return fsql:GetCT('devices',id);  
end

--get lum ltt by id
function GetLum(self,id)  
	return fsql:GetLum('devices',id);  
end

--get onoff ott by id
function GetOnOff(self,id)  
	return fsql:GetOnOff('devices',id);  
end

--get name by id
function GetName(self,id)  
	return fsql:GetName('devices',id);  
end

--get state by id
function GetSta(self,id)  
	return fsql:GetSta('devices',id);  
end


