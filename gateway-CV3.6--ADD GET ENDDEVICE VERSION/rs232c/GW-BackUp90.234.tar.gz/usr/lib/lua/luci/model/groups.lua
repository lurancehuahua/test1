--Copyright (c) 2018 Greeble 
--Chenheng <heng.chen@scjz-led.com>
--ZGW groups V0.0.3 20171023

module("zgw.groups", package.seeall)
qlite3 = require "luasql.sqlite3"  
fsql = require "zgw.sql"  

--add a record and set tag name
function add(self,itag,iname)  
	local env = assert(qlite3.sqlite3());  
	local db = assert(env:connect("zgw.db"));  

	db:setautocommit(false);

	sql = "INSERT INTO groups (tag,name) VALUES (" .. itag .. ",\'" .. iname .. "\')";
	print(sql);
    res = assert (db:execute(sql));
	
	assert(db:commit()); 
    print(res);
	db:close();
	env:close(); 
	return res  
end    

--set dids to db
function SetDids(self,id,idids)  
	local env = assert(qlite3.sqlite3())  
	local db = assert(env:connect("zgw.db"))  

	db:setautocommit(false)  

	sql = "UPDATE groups SET dids = " .. idids .. " WHERE id = " .. id;
	print(sql);  
    res = assert (db:execute(sql));

	assert(db:commit()); 

	print(res);
	db:close()  
	env:close() 
	return res  
end  

--get dids by id
function GetDids(self,id)  
	local env = assert(qlite3.sqlite3());  
	local db = assert(env:connect("zgw.db"));  

	sql = "SELECT * FROM groups WHERE id = " .. id; 
	print(sql);
    res = assert (db:execute(sql));
	
 	for r in fsql:xrows(res) do  
        dids = r["dids"] ;
		fsql:xprinttab(r);  
	end 	
	print('dids = ',dids);
	res:close();  
	db:close();  
	env:close(); 
	return dids  
end

--set sid to db
function SetSid(self,id,isid)  
	local env = assert(qlite3.sqlite3())  
	local db = assert(env:connect("zgw.db"))  

	db:setautocommit(false)  

	sql = "UPDATE groups SET sid = " .. isid .. " WHERE id = " .. id;
	print(sql);  
    res = assert (db:execute(sql));

	assert(db:commit()); 

	print(res);
	db:close()  
	env:close() 
	return res  
end  

--get sid by id
function GetSid(self,id)  
	local env = assert(qlite3.sqlite3());  
	local db = assert(env:connect("zgw.db"));  

	sql = "SELECT * FROM groups WHERE id = " .. id; 
	print(sql);
    res = assert (db:execute(sql));
	
 	for r in fsql:xrows(res) do  
        sid = r["sid"] ;
		fsql:xprinttab(r);  
	end 	
	print('sid = ',sid);
	res:close();  
	db:close();  
	env:close(); 
	return sid  
end

--delete a record by id
function del(self,id)  
    res = fsql:del('groups',id);
	return res  
end    

--set state to db
function SetSta(self,id,ista)  
	res = fsql:SetSta('groups',id,ista);
	return res  
end  
 
--set name to db
function SetName(self,id,iname)  
	res = fsql:SetName('groups',id,iname);
	return res  
end  

--set onoff ott to db
function SetOnOff(self,id,ionoff,iott)  
	res = fsql:SetOnOff('groups',id,ionoff,iott);
	return res  
end  

--set lum ltt to db
function SetLum(self,id,ilum,iltt)  
	res = fsql:SetLum('groups',id,ilum,iltt);
	return res  
end
  
--set ct ctt to db
function SetCT(self,id,ict,ictt)  
	res = fsql:SetCT('groups',id,ict,ictt);
	return res  
end
  
--set hue hdir htt to db
function SetHue(self,id,ihue,isat,ihtt)  
	res = fsql:SetHue('groups',id,ihue,isat,ihtt);
	return res  
end

--set tag to db
function SetTag(self,id,itag)  
	res = fsql:SetTag('groups',id,itag);
	return res  
end  

--get tag by id
function GetTag(self,id)  
	return fsql:GetTag('groups',id)  
end
  
--get hue hdir htt by id
function GetHue(self,id)  
	return fsql:GetHue('groups',id)  
end

--get ct ctt by id
function GetCT(self,id)  
	return fsql:GetCT('groups',id);  
end

--get lum ltt by id
function GetLum(self,id)  
	return fsql:GetLum('groups',id);  
end

--get onoff ott by id
function GetOnOff(self,id)  
	return fsql:GetOnOff('groups',id);  
end

--get name by id
function GetName(self,id)  
	return fsql:GetName('groups',id);  
end

--get state by id
function GetSta(self,id)  
	return fsql:GetSta('groups',id);  
end


