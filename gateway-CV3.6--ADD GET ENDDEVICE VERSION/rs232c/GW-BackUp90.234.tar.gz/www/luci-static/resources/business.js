/*
    \file: business.js

    COPYRIGHT (C) 2018,ShenZhen JiuZhou   \n
    All rights reserved.       \n\n

    \brief: This file is business web js API and variable
    \details: 

    \version: Ver1.0.0
    \date:    2018010
    \author:  liang jia jun<jj.liang@scjz-led.com>

    \note:    Created
*/


/*
*     Define public variable area
*/
var bs_onfTimerFlag = 0;
var timerCount = 0;
var bs_deviceGroupMsg;
var bs_stdJsGather;
var bs_stdCount = 0;






/*
*     Define public function API area
*/
/*
* function name: draw_chart_7index(obj_id, titleName, colUnit, lineColor, selectName, rowUnit, rowDate)
* describe:      draw a chart on HTML 
* parameter:     obj_id : this is HTML container id, it object must have width and height, like: <div id="mainChart" style="width: 60%; height: 400px;"></div>
*                titleName    : the chart title name
*                colUnit  : the chart col unit
*                lineColor: the chart line color
*                selectName: the chart select index show date name
*                rowUnit: the chart row unit
*                rowDate: the chart row unit date
*                 
* example:        draw_chart_7index("mainChart", "Weekly distribution of electricity", '(KW.h)', "green", "Total Power", "Sun,Mon,Tue,Wed,Thu,Fri,Sat", "10, 110.2, 108.5, 113.8, 114.0, 116.3, 78.1");
*/
function draw_chart_7index(obj_id, titleName, colUnit, lineColor, selectName, rowUnit, rowDate)
{
var arrIndex = new Array();
var arrDate = new Array();

arrIndex = rowUnit.split(",");      // dismantel string to array by ","
arrDate = rowDate.split(",");

//   Initialize the echarts instance based on the prepared DOM
var myChart = echarts.init(document.getElementById(obj_id));

var option = {
    title: {
        text: titleName
        ,subtext: 'Unit: ' + colUnit
    },
    tooltip: {
        trigger: 'axis',
        axisPointer: {
            type: 'cross'
        }
    },
    toolbox: {
        show: false,          // if true will show saveAsPicture button
        feature: {
            saveAsImage: {}
        }
    },
    xAxis:  {
        type: 'category',
        boundaryGap: false,
        data: [arrIndex[0], arrIndex[1], arrIndex[2], arrIndex[3], arrIndex[4], arrIndex[5], arrIndex[6]]
    },
    yAxis: {
        type: 'value',
        axisLabel: {
            formatter: '{value} '
        },
        axisPointer: {
            snap: true
        }
    },
    visualMap: {
        show: false,
        dimension: 0,
        pieces: [{
            lte: 1,
            color: lineColor
        },{
            gt: 1,
            lte: 2,
            color: lineColor
        },{
            gt: 2,
            color: lineColor
        }]
    },
    series: [
        {
            name:selectName,
            type:'line',
            smooth: true,
            data: [arrDate[0], arrDate[1], arrDate[2], arrDate[3], arrDate[4], arrDate[5], arrDate[6]]
        }
    ]
};
// Use the newly specified configuration items and data to display the chart
myChart.setOption(option);
}


/*
* function name: bs_get_system_weekday()
* describe:      get system weekday
* parameter:     null
*                 
* example:       bs_get_system_weekday()
*/
function bs_get_system_weekday()
{
    var resentDate = new Date();

    return (resentDate.getDay());
}

/*
* function name: bs_get_system_weekday()
* describe:      get system weekday
* parameter:     null
*                 
* example:       bs_get_system_weekday()
*/
function bs_return_weekchart_rolPara()
{
    switch (bs_get_system_weekday())
    {
        case 0: return "Mon,Tue,Wed,Thu,Fri,Sat,Sun"; break;
        case 1: return "Tue,Wed,Thu,Fri,Sat,Sun,Mon"; break;
        case 2: return "Wed,Thu,Fri,Sat,Sun,Mon,Tue"; break;
        case 3: return "Thu,Fri,Sat,Sun,Mon,Tue,Wed"; break;
        case 4: return "Fri,Sat,Sun,Mon,Tue,Wed,Thu"; break;
        case 5: return "Sat,Sun,Mon,Tue,Wed,Thu,Fri"; break;
        case 6: return "Sun,Mon,Tue,Wed,Thu,Fri,Sat"; break;
    }
}

    


/*
* function name: jump2new_page(pageAddr)
* describe:      jump to other html page 
* parameter:     pageAddr:     jump to html file address by system
*                 
* example:       onclick='jump2new_page("bs_lightcontrol_child1")'
*/
function jump2new_page(pageAddr)
{
    location.href = pageAddr;
}


/*
* function name: jump2new_page_carryUrl(pageAddr, carryBuf)
* describe:      jump to new page and carry buf to new page url
* parameter:     pageAddr:  jump to new page address
*                carryBuf:  carry to url buf content
*                 
* example:       jump2new_page_carryUrl("bs_modesetting", "ID=1")
*/
function jump2new_page_carryUrl(pageAddr, carryBuf)
{
    location.href = pageAddr + "?" + carryBuf;
}

/*
* function name: bs_common_switch(objId, sendMsg, repType, repIndexId)
* describe:      common switch control API 
* parameter:     objId:        switch img id
*                msgHead:      send to server message head
*                repType:      server response message later select call Type
*                repIndexId:   server response message show on index id
*                 
* example:       bs_common_switch(objId, sendMsg, repType, repIndexId)
*/
function bs_common_switch(objId, msgHead, repType, repIndexId)
{
    var sw = document.getElementById(objId);
    var sendMsg = "MH=" + msgHead;
    sendMsg += "&GID=" + objId;

    cancelBubble();  // stop bubble
    if (sw.src.match("/luci-static/resources/icon/001.png"))
    {
        sw.src = "/luci-static/resources/icon/002.png";    
        sendMsg += "&SW=1";
        
        loadNrp("/cgi-bin/luci/admin/zigbee/room/jsonresponse", sendMsg, repType, repIndexId);
    }
    else
    {
        sw.src = "/luci-static/resources/icon/001.png";
        sendMsg += "&SW=0";
       
        loadNrp("/cgi-bin/luci/admin/zigbee/room/jsonresponse", sendMsg, repType, repIndexId);
    }
}


/*
* function name: only_select_lightcontrol(objHeadName, objId)
* describe:      alone select on more scene from lightcontrol_child
* parameter:     objId:             object img id
*                 
* example:       onclick='only_select_lightcontrol("scene", id)'
*/
function only_select_lightcontrol(objId)
{
    for (var i=0; i<bs_stdJsGather.SEL.length; i++)
    {
        document.getElementById("SEL" + i).src = "/luci-static/resources/icon/NO_B.png";
    }
    document.getElementById(objId).src = "/luci-static/resources/icon/YES.png";
    // change_url_para(test, "SE", bs_stdJsGather.SEL[objId.substr(3)]);
    history.pushState("","title",change_url_para(window.location.href, "SE", encodeURI(encodeURI(bs_stdJsGather.SEL[objId.substr(3)]))));

   var requestMsg = "MH=84";
   requestMsg += "&roomId=" + getUrlData("RID");
   requestMsg += "&sceneNA=" + encodeURI(encodeURI(decodeURI(getUrlData("SE"))));
   loadNrp("/cgi-bin/luci/admin/zigbee/room/jsonresponse", requestMsg, 84);
}



/*
* function name: change_url_para(url, par, par_value) 
* describe:      change url parameter and return new url content
*                if no exist parameter ID , this will add parameter
* parameter:     url:             need to modification url buffer
*                par:             url parameter ID
*                par_value:       modification parameter ID value
*                 
* example:       change_url_para(url, par, par_value) 
*/
function change_url_para(url, par, par_value) 
{ 
    var pattern = par+'=([^&]*)'; 
    var replaceText = par+'='+par_value; 

    if (url.match(pattern)) 
    { 
        var tmp = '/\\'+par+'=[^&]*/'; 
        tmp = url.replace(eval(tmp), replaceText); 
        return (tmp); 
    } 
    else 
    { 
        if (url.match('[\?]')) 
        { 
            return url+'&'+ replaceText; 
        } 
        else 
        { 
            return url+'?'+replaceText; 
        } 
    } 
    return url+'\n'+par+'\n'+par_value; 
} 


/*
* function name: more_function_timer(loopStatus, timeUsed, callbackFunction, cv1, cv2, cv3)
* describe:      define timer, this API have more function
*                1. using public variable: bs_onfTimerFlag control timer start or stop
*                2. control timer loop
*                3. control timer loop time
*                4. set callback function and callback funcion parameter
*
* parameter:     bs_onfTimerFlag:        public variable, 1:start 0:stop timer
*                loopStatus:          auto loop timer: 1:loop   0: just run one way
*                timeUsed:            time used loop
*                callbackFunction:    callback function name
*                cv1,cv2,cv3:         callback function parameter
*                 
* example:       onclick='only_select_lightcontrol("scene", id)'
*/
function more_function_timer(loopStatus, timeUsed, callbackFunction, cv1, cv2, cv3)
{
  if (bs_onfTimerFlag)     // 1: start    0: stop
  {
     setTimeout(function(){
        callbackFunction(cv1, cv2, cv3);

        if (loopStatus)
        {
          more_function_timer(loopStatus, timeUsed, callbackFunction, cv1, cv2, cv3);
        }
    }, timeUsed);
  }
}


/*
* function name: home_request()
* describe:      home page request
* parameter:     null
*                 
* example:       home_request()
*/ 
function home_request()
{
    var sendMsg = "MH=70";
    loadNrp("/cgi-bin/luci/admin/zigbee/room/jsonresponse", sendMsg, 70);
}


/*
* function name: home_server_response(xmlhttp)
* describe:      home page server response update date
* parameter:     xmlhttp     :   ajax response flag
*                 
* example:       home_server_response(xmlhttp)
*/ 
function home_server_response(xmlhttp)
{
    var jsontxt = xmlhttp.responseText;
    var obj = eval("(" + jsontxt + ")");                // json transform JS 

    update_home(obj.HOME[0], obj.HOME[1], obj.HOME[2], obj.HOME[3], obj.HOME[4]);
}

/*
* function name: update_home(roomCount, lightCount, lightOnCount, breakdownCount, powerCount)
* describe:      update home parameter
* parameter:     roomCount :     room count number
*                lightCount    : light count number
*                lightOnCount  : light on count number
*                breakdownCount: breakdown count number
*                powerCount:     power count number
*                 
* example:        update_home(7, 4, 4, 0, 20)
*/ 
function update_home(roomCount, lightCount, lightOnCount, breakdownCount, powerCount)
{
    document.getElementById("roomCountId").innerHTML = roomCount;
    document.getElementById("lightCountId").innerHTML = lightCount;
    document.getElementById("lightOnCountId").innerHTML = lightOnCount;
    document.getElementById("breakdownCountId").innerHTML = breakdownCount;
    document.getElementById("powerId").innerHTML = powerCount + "W";
}


/*
* function name: bs_load_gateway_list(xmlhttp)
* describe:      get server data to load gateway date list page
* parameter:     xmlhttp:     server response flag
*                 
* example:       bs_load_gateway_list(xmlhttp)
*/ 
function bs_load_gateway_list(xmlhttp)
{
    var jsontxt = xmlhttp.responseText;
    var obj = eval("(" + jsontxt + ")");                // json transform JS 
    var msg = "";


    for (var i=0; i<obj.GAWL.length; i++)
    {
        // real HTML 
        // <div class="am-g device-container"> 
        //   <div class="am-u-sm-2 mart17-5" >B2 Garge</div>
        //   <div class="am-u-sm-2 mart17-5" >192.168.125.220</div>
        //   <div class="am-u-sm-2 mart17-5" >01:F2:35:4F:5A:61:20</div>
        //   <div class="am-u-sm-2 mart17-5" >122</div>
        //   <div class="am-u-sm-1 mart17-5" >online</div>
        //   <div class="am-u-sm-3 mart17-5" >At the entrence</div>
        // </div>

        msg += "<div class=\"am-g device-container\" onclick=\'jump2new_page(\"bs_devicemanage_adjust\")\'>";
        msg += "<div class=\"am-u-sm-2 mart17-5\" >" + obj.GAWL[i].NA + "</div>";
        msg += "<div class=\"am-u-sm-2 mart17-5\" >" + obj.GAWL[i].IP + "</div>";
        msg += "<div class=\"am-u-sm-2 mart17-5\" >" + obj.GAWL[i].MAC + "</div>";
        msg += "<div class=\"am-u-sm-2 mart17-5\" >" + obj.GAWL[i].CU + "</div>";
        msg += "<div class=\"am-u-sm-1 mart17-5\" >" + bs_check_gateway_status(obj.GAWL[i].STU) + "</div>";
        msg += "<div class=\"am-u-sm-3 mart17-5\" >" + obj.GAWL[i].DES + "</div>";
        msg += "</div>"
    }

    document.getElementById("devicemanageIndex").innerHTML = msg;                                  
}

/*
* function name: bs_check_gateway_status(stu)
* describe:      check gateway online status
* parameter:     stu:  1:online   0:off-line
*                 
* example:       bs_check_gateway_status(stu)
*/
function bs_check_gateway_status(stu)
{
    if (stu)
    {
        return "online";
    }
    else
    {
        return "off-line";
    }
}



/*
* function name: start_search_device()
* describe:      open network
* parameter:     null
*                 
* example:       start_search_device()
*/
function start_search_device()
{
    document.getElementById("searchButton").innerHTML = "Searching";
    loadNrp("/cgi-bin/luci/admin/zigbee/room/jsonresponse", "ctlNetStatus=1", 999);
    // start timer
    if (bs_onfTimerFlag == 0)
    {
         bs_onfTimerFlag = 1;
         more_function_timer(1, 1000, function(){
            document.getElementById("processBar").style.width = parseInt(timerCount/180*100) + "\%";
            document.getElementById("processBarValue").innerHTML = parseInt(timerCount/180*100) + "\%";

            if (++timerCount > 180)   // 100s end find device
            {
              bs_onfTimerFlag = 0;
              timerCount = 0;

              document.getElementById("searchButton").innerHTML = "Search again";
            }

            if (timerCount % 5 == 0)   // 5s request new device date
            {
                loadNrp("/cgi-bin/luci/admin/zigbee/room/jsonresponse", "loadDeviceList=200", 72);
            }
        })
    }
}


/*
* function name: bs_newfind_device_list(xmlhttp)
* describe:      get server data to show new find device
* parameter:     xmlhttp:     server response flag
*                 
* example:       bs_newfind_device_list(xmlhttp)
*/ 
function bs_newfind_device_list(xmlhttp)
{
    var jsontxt = xmlhttp.responseText;
    var obj = eval("(" + jsontxt + ")");                // json transform JS 
    var msg = "";
    var i = 0;

    for (i=0; i<obj.DEVL.length; i++)
    {
        // real HTML
      //   <div class="am-g bs-newFind-device">
      //     <div class="am-u-sm-1" style="margin-top: 17.5px;">1</div>
      //     <div class="am-u-sm-4" style="margin-top: 15px;">
      //       <img class="mf-img-size30" src="<%=resource%>/icon/RGB_B.png" />
      //       <input type="text" value="RGB Light" style="width: 60%;" /> 
      //     </div>
      //     <div class="am-u-sm-7" style="margin-top: 12px;">
      //       <button type="button" class="am-btn am-btn-success am-radius" style="margin: 0px">Edit</button>
      //     </div>
      // </div>

      msg += "<div id=\""+ obj.DEVL[i].AD +"\" class=\"am-g bs-newFind-device\" onclick='bs_newdevice_identify(id)'>";
      msg += "<div class=\"am-u-sm-1\" style=\"margin-top: 17.5px;\">"+ (i+1) +"</div>";
      msg += "<div class=\"am-u-sm-4\" style=\"margin-top: 15px;\">";
      msg += "<img class=\"mf-img-size30\" src=\"/luci-static/resources/icon/"+ searchIcon(obj.DEVL[i].TY) +"\" />";
      msg += "<input type=\"text\" value=\""+ obj.DEVL[i].NA +"\" style=\"width: 60%;\" />";
      msg += "</div>";
      msg += "<div class=\"am-u-sm-7\" style=\"margin-top: 12px;\">";
      msg += "<button type=\"button\" class=\"am-btn am-btn-success am-radius\" style=\"margin: 0px\">Edit</button>";
      msg += "</div>" + "</div>";
    }

    document.getElementById("newFindDevice").innerHTML = msg;
    document.getElementById("newFindDeviceCount").innerHTML = i;
}


/*
* function name: bs_newdevice_identify(devId)
* describe:      send device identify to server for find device index
* parameter:     devId:     device address
*                 
* example:       bs_newdevice_identify(devId)
*/ 
function bs_newdevice_identify(devId)
{
    var sendMsg = "deviceAddress=" + devId;
    sendMsg += "&deviceIdentify=3";
    loadNrp("/cgi-bin/luci/admin/zigbee/room/jsonresponse", sendMsg, 999);
}


/*
* function name: bs_load_room_list(xmlhttp)
* describe:      load business room list page
* parameter:     xmlhttp:     server response flag
*                 
* example:       bs_load_room_list(xmlhttp)
*/
function bs_load_room_list(xmlhttp)
{
    var jsontxt = xmlhttp.responseText;
    var obj = eval("(" + jsontxt + ")");                // json transform JS 
    var msg = "";

    for (var i=0; i<obj.RML.length; i++)
    {
        // 
        // <div class="am-g line-block">
        //     <div class="am-u-sm-1 mart10">
        //       <img class="mf-img-size40" src="/luci-static/resources/icon/1_B.png" />
        //     </div>
        //     <div class="am-u-sm-2 mart17-5">B2 room</div>
        //     <div class="am-u-sm-2 mart17-5">12</div>
        //     <div class="am-u-sm-6 mart17-5">30 parking spaces</div>
        //     <div class="am-u-sm-1 mart17-5">Delete</div>
        //   </div>

        msg += "<div class=\"am-g line-block\">";
        msg += "<div class=\"am-u-sm-1 mart10\">";
        msg += "<img class=\"mf-img-size40\" src=\"/luci-static/resources/icon/"+ searchIcon(obj.RML[i].IC) +"\" />";
        msg += "</div>";
        msg += "<div class=\"am-u-sm-2 mart17-5\">"+ obj.RML[i].NA +"</div>";
        msg += "<div class=\"am-u-sm-2 mart17-5\">"+ obj.RML[i].CU +"</div>";
        msg += "<div class=\"am-u-sm-6 mart17-5\">"+ obj.RML[i].DES +"</div>";
        msg += "<div class=\"am-u-sm-1 mart17-5\" onclick=\'bs_delete_room("+ obj.RML[i].RID +")\'>Delete</div>";
        msg += "</div>";
    }

    document.getElementById("roomManageList").innerHTML = msg;
}


/*
* function name: bs_delete_room(roomId)
* describe:      request delete room 
* parameter:     roomId:     room ID
*                 
* example:       bs_delete_room(roomId)
*/
function bs_delete_room(roomId)
{
    var sendMsg = "MH=73";
    sendMsg += "&delRoomId=" + roomId;

    layer.open({
        content:"Do you want to delete the room?"
        ,style:'border:none; color:black!important'
        ,btn:['Yes', "No"]
        ,yes:function(index){
            loadNrp('/cgi-bin/luci/admin/zigbee/room/jsonresponse', sendMsg, 999);
            layer.close(index);
        }
    });
}


/*
* function name: bs_select_device_status(objId)
* describe:      select add group device status
* parameter:     objId:     object id
*                 
* example:       bs_select_device_status(objId)
*/
function bs_select_device_status(objId)
{
    var obj = document.getElementById(objId);

    if (obj.src.match("/luci-static/resources/icon/NO_B.png"))
    {
        obj.src = "/luci-static/resources/icon/YES.png";
    }
    else
    {
        obj.src = "/luci-static/resources/icon/NO_B.png";
    }
}


/*
* function name: bs_gateway_device(objAddr)
* describe:      request gateway device
* parameter:     objAddr:     gateway MAC address
*                 
* example:       bs_gateway_device(objAddr)
*/
function bs_gateway_device(objAddr)
{
    document.getElementById(objAddr).style.background = "#8bc34a";    // selected change background color

    var sendMsg = "MH=74";
    sendMsg += "&gwMAC=" + objAddr;
    // request this gateway device data.
    loadNrp('/cgi-bin/luci/admin/zigbee/room/jsonresponse', sendMsg, 74);
}


/*
* function name: bs_load_addgroup_devicelist(xmlhttp)
* describe:      load add group device list on page
* parameter:     xmlhttp:     server response flag
*                 
* example:       bs_load_addgroup_devicelist(xmlhttp)
*/
function bs_load_addgroup_devicelist(xmlhttp)
{
    var jsontxt = xmlhttp.responseText;
    var obj = eval("(" + jsontxt + ")");                // json transform JS 
    bs_deviceGroupMsg = obj;
    var msg = "";

    for (var i=0; i<obj.DEVL.length; i++)
    {
        // real HTML
        // <div class="am-g line-min-block">
        //   <div class="am-u-sm-3 mart10">CCT1</div>
        //     <div class="am-u-sm-3 mart15">
        //       <img class="mf-img-size15" src="/luci-static/resources/icon/CCT_B.png" />
        //     </div>
        //     <div class="am-u-sm-2 mart15 am-u-end">
        //       <img id="imgDeviceAddr" class="mf-img-size15" src="/luci-static/resources/icon/NO_B.png" onclick='bs_select_device_status(id)' />
        //     </div>
        // </div>

        msg += "<div class=\"am-g line-min-block\">";
        msg += "<div class=\"am-u-sm-3 mart10\">"+ obj.DEVL[i].NA +"</div>";
        msg += "<div class=\"am-u-sm-3 mart15\">";
        msg += "<img class=\"mf-img-size15\" src=\"/luci-static/resources/icon/"+ searchIcon(obj.DEVL[i].TY) +"\" />";
        msg += "</div>";
        msg += "<div class=\"am-u-sm-2 mart15 am-u-end\">";
        msg += "<img id=\""+ obj.DEVL[i].AD +"\" class=\"mf-img-size15\" src=\"/luci-static/resources/icon/NO_B.png\" onclick=\'bs_select_device_status(id)\' />"
        msg += "</div>" + "</div>";
    }

    document.getElementById("addGroupDeviceList").innerHTML = msg;
}


/*
* function name: bs_save_newgroup()
* describe:      save new group
* parameter:     null
*                 
* example:       bs_save_newgroup()
*/
function bs_save_newgroup()
{
    var obj;
    var sendMsg = "MH=75";

    sendMsg += "&groupName=" + encodeURI(encodeURI($("#newGroupName").val()));
    sendMsg += "&devList=";

    for (var i=0; i<bs_deviceGroupMsg.DEVL.length; i++)
    {
        obj = document.getElementById(bs_deviceGroupMsg.DEVL[i].AD);

        if (obj.src.match("/luci-static/resources/icon/YES.png"))
        {
            sendMsg += "," + bs_deviceGroupMsg.DEVL[i].AD;
        }
    }

    loadNrp('/cgi-bin/luci/admin/zigbee/room/jsonresponse', sendMsg, 75);

    layer.open({
        type:2
        ,content:"saving"
        ,time: 30    // 90 second close
    });
}


/*
* function name: bs_save_newgroup_success(xmlhttp)
* describe:      save group success and jump to bs_roomadd page.
* parameter:     xmlhttp:     server response flag
*                 
* example:       bs_save_newgroup_success(xmlhttp)
*/
function bs_save_newgroup_success(xmlhttp)
{
    jump2new_page("bs_roomadd");
}


/*
* function name: bs_select_room_icon(num)
* describe:      change room selected icon
* parameter:     num:     icon number
*                 
* example:       bs_select_room_icon(num)
*/
function bs_select_room_icon(num)
{
    var obj = document.getElementById("roomIconId");

    obj.src = "/luci-static/resources/icon/" + num + "_B.png";
    $("#roomIconNumId").val(num);
}



/*
* function name: bs_loadroom_group_list(xmlhttp)
* describe:      load room group list
* parameter:     xmlhttp : server response flag
*                 
* example:       bs_loadroom_group_list(xmlhttp)
*/
function bs_loadroom_group_list(xmlhttp)
{
    var jsontxt = xmlhttp.responseText;
    var obj = eval("(" + jsontxt + ")");                // json transform JS 
    bs_deviceGroupMsg = obj;
    var msg = "";

    for (var i=0; i<obj.GPL.length; i++)
    {
        // real HTML
        // <div class="am-g line-addroom-group-block">
        //     <div class="am-u-sm-4 mart7-5">Group1</div>
        //     <div class="am-u-sm-4 mart7-5">12</div>
        //     <div class="am-u-sm-4 mart12-5">
        //       <img class="mf-img-size15" src="<%=resource%>/icon/NO_B.png" />
        //     </div>
        //   </div>

        msg += "<div class=\"am-g line-addroom-group-block\">";
        msg += "<div class=\"am-u-sm-4 mart7-5\">"+ obj.GPL[i].NA +"</div>";
        msg += "<div class=\"am-u-sm-4 mart7-5\">"+  obj.GPL[i].CU +"</div>";
        msg += "<div class=\"am-u-sm-4 mart12-5\">";
        msg += "<img id=\""+ obj.GPL[i].ID +"\" class=\"mf-img-size15\" src=\"/luci-static/resources/icon/NO_B.png\" onclick='bs_select_device_status(id)'/>";
        msg += "</div>" + "</div>"
    }

    document.getElementById("addRoomGroupList").innerHTML = msg;
}


/*
* function name: bs_save_newroom(xmlhttp)
* describe:      save new room 
* parameter:     null
*                 
* example:       bs_save_newroom(xmlhttp)
*/
function bs_save_newroom()
{
    var sendMsg = "";
    sendMsg += "MH=77";
    sendMsg += "&iconNum=" + $("#roomIconNumId").val();
    sendMsg += "&roomNA=" + encodeURI(encodeURI($("#roomNameId").val()));
    sendMsg += "&desp=" + encodeURI(encodeURI($("#roomDespId").val()));
    sendMsg += "&groupList="

    for (var i=0; i<bs_deviceGroupMsg.GPL.length; i++)
    {
        obj = document.getElementById(bs_deviceGroupMsg.GPL[i].ID);

        if (obj.src.match("/luci-static/resources/icon/YES.png"))
        {
            sendMsg += "," + bs_deviceGroupMsg.GPL[i].ID;
        }
    }

    loadNrp('/cgi-bin/luci/admin/zigbee/room/jsonresponse', sendMsg, 77);

    layer.open({
        type:2
        ,content:"saving"
        ,time: 30    // 90 second close
    });
}

/*
* function name: bs_save_newroom_success(xmlhttp)
* describe:      save room manage success
* parameter:     xmlhttp: server response flag
*                 
* example:       bs_save_newroom_success(xmlhttp)
*/
function bs_save_newroom_success(xmlhttp)
{
    jump2new_page("bs_roommanage");
}


/*
* function name: bs_load_mode_mainpage(xmlhttp)
* describe:      load mode mainly page
* parameter:     xmlhttp: server response flag
*                 
* example:       bs_load_mode_mainpage(xmlhttp)
*/
function bs_load_mode_mainpage(xmlhttp)
{
    var jsontxt = xmlhttp.responseText;
    var obj = eval("(" + jsontxt + ")");                // json transform JS 
    var msg = "";

    for (var i=0; i<obj.RML.length; i++)
    {
        // real HTML
        // <div class="am-g line-max-block">
        //     <div class="am-u-sm-1 mart17-5">1</div>
        //     <div class="am-u-sm-1 mart10">
        //       <img class="mf-img-size40" src="<%=resource%>/icon/3_B.png" />
        //     </div>
        //     <div name="tb" class="am-u-sm-9 mart17-5">1F ShowRoom</div>
        //     <div class="am-u-sm-1 mart15">
        //       <img class="mf-img-size30" src="<%=resource%>/icon/you_B.png" />
        //     </div>
        //   </div>

        msg += "<div class=\"am-g line-max-block\" onclick=\'jump2new_page_carryUrl(\"bs_modesetting_list\", \"RID="+ obj.RML[i].RID +"\")\'>";
        msg += "<div class=\"am-u-sm-1 mart17-5\">"+ (i+1) +"</div>";
        msg += "<div class=\"am-u-sm-1 mart10\">";
        msg += "<img class=\"mf-img-size40\" src=\"/luci-static/resources/icon/"+ searchIcon(obj.RML[i].IC) +"\" />";
        msg += "</div>";
        msg += "<div name=\"tb\" class=\"am-u-sm-9 mart17-5\">"+ obj.RML[i].NA +"</div>";
        msg += "<div class=\"am-u-sm-1 mart15\">";
        msg += "<img class=\"mf-img-size30\" src=\"/luci-static/resources/icon/you_B.png\" />";
        msg += "</div>" + "</div>";
    }

    document.getElementById("roomListContainerId").innerHTML = msg;
}


/*
* function name: bs_load_modeof_selectroom(xmlhttp)
* describe:      jump to new page and carry buf to new page url
* parameter:     pageAddr:  jump to new page address
*                carryBuf:  carry to url buf content
*                 
* example:       bs_load_modeof_selectroom(xmlhttp)
*/
function bs_load_modeof_selectroom(xmlhttp)
{
    var jsontxt = xmlhttp.responseText;
    var obj = eval("(" + jsontxt + ")");                // json transform JS 
    var msg = "";

    for (var i=0; i<obj.MDL.length; i++)
    {
        // real HTML
        // <div class="am-g line-max-block">
        //     <div class="am-u-sm-1 mart17-5">1</div>
        //     <div name="tb" class="am-u-sm-9 mart17-5">Light Height</div>
        //     <div name="tb" class="am-u-sm-1 mart17-5">Delete</div>
        //     <div class="am-u-sm-1 mart15">
        //       <img class="mf-img-size30" src="<%=resource%>/icon/you_B.png" />
        //     </div>
        //   </div>

        msg += "<div class=\"am-g line-max-block\">";
        msg += "<div class=\"am-u-sm-1 mart17-5\">"+ (i+1) +"</div>";
        msg += "<div name=\"tb\" class=\"am-u-sm-9 mart17-5\">"+ obj.MDL[i].NA +"</div>";
        msg += "<div name=\"tb\" class=\"am-u-sm-1 mart17-5\" onclick=\'bs_delete_mode("+ obj.MDL[i].ID +")\' >Delete</div>";
        msg += "<div class=\"am-u-sm-1 mart15\">";
        msg += "<img class=\"mf-img-size30\" src=\"/luci-static/resources/icon/you_B.png\" />";
        msg += "</div>" + "</div>";
    }

   document.getElementById("modeListContainerId").innerHTML = msg; 
}


/*
* function name: bs_delete_mode(objId)
* describe:      delete room mode
* parameter:     objId:   object id
*                 
* example:       bs_delete_mode(objId)
*/
function bs_delete_mode(objId)
{
    var sendMsg = "";
    var roomid = getUrlData("RID");

    sendMsg += "MH=79";
    sendMsg += "&delModeId=" + objId;
    sendMsg += "&delRoomId=" + roomid;

    loadNrp('/cgi-bin/luci/admin/zigbee/room/jsonresponse', sendMsg, 80);

     layer.open({
        type:2
        ,content:"Deleting"
        ,time: 30    // 90 second close
    });
}


/*
* function name: bs_delete_mode_success(xmlhttp)
* describe:      delete mode success response
* parameter:     xmlhttp:  server response index
*                 
* example:       bs_delete_mode_success(xmlhttp)
*/
function bs_delete_mode_success(xmlhttp)
{
    // onload page wait 100ms send request gateway data.
   bs_onfTimerFlag = 1;
   more_function_timer(0, 100, function(){
        loadNrp("/cgi-bin/luci/admin/zigbee/room/jsonresponse", "MH=78", 79);
   });

   layer.closeAll();    // close all pop-up window
}


/*
* function name: getUrlData(strParamName)
* describe:      get url param and return date.
* parameter:     strParamName:   get url param
*                 
* example:       getUrlData(strParamName)
*/
function getUrlData(strParamName)
{
    var strReturn = "";
    // var strHref = window.location.href.toUpperCase();       // toUpperCase()  将字母转换为大写
    var strHref = window.location.href;
    var bFound = false;
    var cmpstring = strParamName + "=";
    var cmplen = cmpstring.length;

    if (strHref.indexOf("?") > -1)
    {
        var strQueryString = strHref.substr(strHref.indexOf("?") + 1);
        var aQueryString = strQueryString.split("&");
        for (var iParam = 0; iParam < aQueryString.length; iParam++)
        {
            if (aQueryString[iParam].substr(0, cmplen) == cmpstring)
            {
                var aParam = aQueryString[iParam].split("=");
                strReturn = aParam[1];
                bFound = true;
                break;
            }
        }
    }
    if (bFound == false) return null;
    strReturn = strReturn.replace(/\+/g, '%20');
    return unescape(strReturn);
}


/*
* function name: bs_move_alone_slide(objId, slideType)
* describe:      move alone slide, it will change showIndex content
* parameter:     objId:       object id
*                slideType:   slide type:    1: Dim  2:CCT  3:RGBW
*                 
* example:       bs_move_alone_slide("2034", 1)
*/
function bs_move_alone_slide(objId, slideType)     //滑动条值发生改变时执行函数
{
    cancelBubble();  // stop bubble

    var objSlide = document.getElementById(objId);
    var showIndex = document.getElementById("show_"+ objId);
    var sendMsg = "MH=85";
    sendMsg += "&GID=" + objId.substr(3);

    // 1: Dim  2:CCT  3:RGBW
    if (slideType == 1)  
    {
      showIndex.innerText = parseInt(objSlide.value/255*100) + '%';
      sendMsg += "&DIM=" + objSlide.value;
    }
    else if (slideType == 2)
    {
      showIndex.innerText = "CCT:" + parseInt(1000000 / (370 - parseInt(objSlide.value))) + 'K';
      sendMsg += "&CCT=" + objSlide.value;
    }
    else if (slideType == 3)
    {
      showIndex.innerText = "HUE:" + objSlide.value;
      sendMsg += "&RGB=" + objSlide.value;
    }

    loadNrp("/cgi-bin/luci/admin/zigbee/room/jsonresponse", sendMsg, 999);
}


/*
* function name: bs_load_room_group_list(xmlhttp)
* describe:      load room group list
* parameter:     xmlhttp:       server response flag
*                 
* example:       bs_load_room_group_list(xmlhttp)
*/
function bs_load_room_group_list(xmlhttp)
{
    var jsontxt = xmlhttp.responseText;
    var obj = eval("(" + jsontxt + ")");                // json transform JS 
    bs_stdJsGather = obj;
    var msg = "";

    for (var i=0; i<obj.GPL.length; i++)
    {
        // real HTML
        switch (obj.GPL[i].TY)
        {
            case 1: msg += bs_real_html_ONFgroup(i, obj.GPL[i]);
                    break;
            case 2: msg += bs_real_html_DIMgroup(i, obj.GPL[i]);
                    break;
            case 3: msg += bs_real_html_CCTgroup(i, obj.GPL[i]);
                    break;
            case 4: msg += bs_real_html_RGBgroup(i, obj.GPL[i]);
                    break;
            default: break;
        }
    }

    document.getElementById("addModeGroupContainerId").innerHTML = msg;
}

/*
* function name: bs_real_html_ONFgroup(num, objMsg)
* describe:      ON/OFF group HTML
* parameter:     num:       list number 
*                objMsg:    include JSON response content
*                 
* example:       bs_real_html_ONFgroup(num, objMsg)
*/
function bs_real_html_ONFgroup(num, objMsg)
{
    // <div class="am-g line-room-group-block">
    //     <div class="am-u-sm-1 mart20">1</div>
    //     <div class="am-u-sm-10 mart20">ONF Light</div>
    //     <div class="am-u-sm-1 am-u-end mart15">
    //       <img id="sw_groupId" class="mf-img-size40" src="/luci-static/resources/icon/002.png" onclick="bs_common_switch(id, 81)" />
    //     </div>
    //   </div> 

    var sendMsg = "";

    sendMsg += "<div class=\"am-g line-room-group-block\">";
    sendMsg += "<div class=\"am-u-sm-1 mart20\">"+ (num + 1) +"</div>";
    sendMsg += "<div class=\"am-u-sm-10 mart20\">"+ objMsg.NA +"</div>";
    sendMsg += "<div class=\"am-u-sm-1 am-u-end mart15\">";
    sendMsg += "<img id=\"sw_"+ objMsg.ID +"\" class=\"mf-img-size40\" src=\"/luci-static/resources/icon/"
               + switchStatus(objMsg.PARA[0]) +"\" onclick=\"bs_common_switch(id, 81)\" />";
    sendMsg += "</div>" + "</div>";

    return sendMsg;
}

/*
* function name: bs_real_html_DIMgroup(num, objMsg)
* describe:      DIM group HTML
* parameter:     num:       list number 
*                objMsg:    include JSON response content
*                 
* example:       bs_real_html_DIMgroup(num, objMsg)
*/
function bs_real_html_DIMgroup(num, objMsg)
{
    // <div class="am-g line-room-group-block">
    //     <div class="am-u-sm-1 mart20">1</div>
    //     <div class="am-u-sm-3 mart20">Dim panel-side</div>
    //     <div class="am-u-sm-5 mart15">
    //       <img class="mf-img-size15"  src="<%=resource%>/icon/bs10.png" />
    //       <input type="range" class="slider-block" id="DIMgroupId1" max="255" min="5" step="1" value="5" onchange="bs_move_alone_slide(id, 1)">
    //       <img class="mf-img-size30 mart5" src="<%=resource%>/icon/bs10.png" />   
    //     </div>
    //     <div id="show_DIMgroupId1" class="am-u-sm-2 mart20">1%</div>
    //     <div class="am-u-sm-1 am-u-end mart15">
    //       <img id="sw_DIMgroupId1" class="mf-img-size40" src="/luci-static/resources/icon/002.png" onclick="bs_common_switch(id,81)" />
    //     </div>
    // </div>

    var sendMsg = "";

    sendMsg += "<div class=\"am-g line-room-group-block\">";
    sendMsg += "<div class=\"am-u-sm-1 mart20\">"+ (num + 1) +"</div>";
    sendMsg += "<div class=\"am-u-sm-3 mart20\">"+ objMsg.NA +"</div>";
    sendMsg += "<div class=\"am-u-sm-5 mart15\">";
    sendMsg += "<img class=\"mf-img-size15\"  src=\"/luci-static/resources/icon/bs10.png\" />";
    sendMsg += "<input type=\"range\" class=\"slider-block\" id=\"DIM"+ objMsg.ID +"\" max=\"255\" min=\"5\" step=\"1\" value=\""
                + objMsg.PARA[1] +"\" onchange=\"bs_move_alone_slide(id, 1)\">";
    sendMsg += "<img class=\"mf-img-size30 mart5\" src=\"/luci-static/resources/icon/bs10.png\" />";
    sendMsg += "</div>";
    sendMsg += "<div id=\"show_DIM"+ objMsg.ID +"\" class=\"am-u-sm-2 mart20\">"+ parseInt(objMsg.PARA[1]/255*100) + '%' +"</div>";
    sendMsg += "<div class=\"am-u-sm-1 am-u-end mart15\">";
    sendMsg += "<img id=\"sw_"+ objMsg.ID +"\" class=\"mf-img-size40\" src=\"/luci-static/resources/icon/"
               + switchStatus(objMsg.PARA[0]) +"\" onclick=\"bs_common_switch(id, 81)\" />";
    sendMsg += "</div>" + "</div>";

    return sendMsg;
}

/*
* function name: bs_real_html_CCTgroup(num, objMsg)
* describe:      CCT group HTML
* parameter:     num:       list number 
*                objMsg:    include JSON response content
*                 
* example:       bs_real_html_CCTgroup(num, objMsg)
*/
function bs_real_html_CCTgroup(num, objMsg)
{
    // <div class="am-g line-room-group-block">
    //     <div class="am-u-sm-1 mart20">2</div>
    //     <div class="am-u-sm-3 mart20">CCT panel‐center</div>
    //     <div class="am-u-sm-5">
    //       <img class="mf-img-size15" src="<%=resource%>/icon/bs10.png" />
    //       <input type="range" class="slider-block" id="DIMgroupId2" max="255" min="5" step="1" value="5" onchange="bs_move_alone_slide(id, 1)">
    //       <img class="mf-img-size30 mart5" src="<%=resource%>/icon/bs10.png" />

    //       <input type="range" class="slider-block-temp" id="CCTgroupId2" style="margin-left: 20px;" max="217" min="1" step="1" value="1" onchange="bs_move_alone_slide(id, 2)">       
    //     </div>
    //     <div class="am-u-sm-2" >
    //       <p id="show_DIMgroupId2" style="margin:5px 0 5px 0;" >1%</p>
    //       <p id="show_CCTgroupId2" style="margin:0px;" >2700K</p>
    //     </div>
    //     <div class="am-u-sm-1 am-u-end mart15">
    //       <img id="sw_groupId2" class="mf-img-size40" src="/luci-static/resources/icon/002.png" onclick="bs_common_switch(id,81)" />
    //     </div>
    //   </div>

    var sendMsg = "";

    sendMsg += "<div class=\"am-g line-room-group-block\">";
    sendMsg += "<div class=\"am-u-sm-1 mart20\">"+ (num + 1) +"</div>";
    sendMsg += "<div class=\"am-u-sm-3 mart20\">"+ objMsg.NA +"</div>";
    sendMsg += "<div class=\"am-u-sm-5\">";
    sendMsg += "<img class=\"mf-img-size15\" src=\"/luci-static/resources/icon/bs10.png\" />";
    sendMsg += "<input type=\"range\" class=\"slider-block\" id=\"DIM"+ objMsg.ID 
               +"\" max=\"255\" min=\"5\" step=\"1\" value=\""+ objMsg.PARA[1] +"\" onchange=\"bs_move_alone_slide(id, 1)\">";
    sendMsg += "<img class=\"mf-img-size30 mart5\" src=\"/luci-static/resources/icon/bs10.png\" />";
    sendMsg += "<input type=\"range\" class=\"slider-block-temp\" id=\"CCT"+ objMsg.ID 
               +"\" style=\"margin-left: 20px;\" max=\"217\" min=\"1\" step=\"1\" value=\""+ objMsg.PARA[2]
               +"\" onchange=\"bs_move_alone_slide(id, 2)\">"+"</div>";
    sendMsg += "<div class=\"am-u-sm-2\">";
    sendMsg += "<p id=\"show_DIM"+ objMsg.ID +"\" style=\"margin:5px 0 5px 0;\" >"+ parseInt(objMsg.PARA[1]/255*100) + '%' +"</p>";
    sendMsg += "<p id=\"show_CCT"+ objMsg.ID +"\" style=\"margin:0px;\" >"+ "CCT:" + parseInt(1000000 / (370 - parseInt(objMsg.PARA[2]))) + 'K' +"</p>";
    sendMsg += "</div>" + "<div class=\"am-u-sm-1 am-u-end mart15\">";
    sendMsg += "<img id=\"sw_"+ objMsg.ID +"\" class=\"mf-img-size40\" src=\"/luci-static/resources/icon/"
               + switchStatus(objMsg.PARA[0]) +"\" onclick=\"bs_common_switch(id,81)\" />";
    sendMsg += "</div>" + "</div>";

    return sendMsg;
}

/*
* function name: bs_real_html_RGBgroup(num, objMsg)
* describe:      RGB group HTML
* parameter:     num:       list number 
*                objMsg:    include JSON response content
*                 
* example:       bs_real_html_RGBgroup(num, objMsg)
*/
function bs_real_html_RGBgroup(num, objMsg)
{
    // <div class="am-g line-room-group-max-block">
    //     <div class="am-u-sm-1 mart40">3</div>
    //     <div class="am-u-sm-3 mart40">RGB panel‐center</div>
    //     <div class="am-u-sm-5">
    //       <img class="mf-img-size15" src="<%=resource%>/icon/bs10.png" />
    //       <input type="range" class="slider-block" id="DIMgroupId3" max="255" min="5" step="1" value="5" onchange="bs_move_alone_slide(id, 1)">
    //       <img class="mf-img-size30 mart5" src="<%=resource%>/icon/bs10.png" />
   
    //       <input type="range" class="slider-block-temp" id="CCTgroupId3" style="margin-left: 20px;" max="217" min="1" step="1" value="1" onchange="bs_move_alone_slide(id, 2)">  

    //       <input type="range" class="slider-block-color" id="RGBgroupId3" style="margin: 8px 0 0 20px;" max="255" min="1" step="1" value="1" onchange="bs_move_alone_slide(id, 3)">     
    //     </div>
    //     <div class="am-u-sm-2" >
    //       <p id="show_DIMgroupId3" style="margin:5px 0 5px 0;"></p>
    //       <p id="show_CCTgroupId3" style="margin:0px;"></p>
    //       <p id="show_RGBgroupId3" style="margin-top:8px;"></p>
    //     </div>
    //     <div class="am-u-sm-1 am-u-end mart35">
    //       <img id="sw_groupId3" class="mf-img-size40" src="/luci-static/resources/icon/002.png" onclick="bs_common_switch(id,81)" />
    //     </div>
    //   </div>

    var sendMsg = "";
    sendMsg += "<div class=\"am-g line-room-group-max-block\">";
    sendMsg += "<div class=\"am-u-sm-1 mart40\">"+ (num + 1) +"</div>";
    sendMsg += "<div class=\"am-u-sm-3 mart40\">"+ objMsg.NA +"</div>";
    sendMsg += "<div class=\"am-u-sm-5\">";
    sendMsg += "<img class=\"mf-img-size15\" src=\"/luci-static/resources/icon/bs10.png\" />";
    sendMsg += "<input type=\"range\" class=\"slider-block\" id=\"DIM"+ objMsg.ID +"\" max=\"255\" min=\"5\" step=\"1\" value=\""
               + objMsg.PARA[1] +"\" onchange=\"bs_move_alone_slide(id, 1)\">";
    sendMsg += "<img class=\"mf-img-size30 mart5\" src=\"/luci-static/resources/icon/bs10.png\" />";
    sendMsg += "<input type=\"range\" class=\"slider-block-temp\" id=\"CCT"+ objMsg.ID 
               +"\" style=\"margin-left: 20px;\" max=\"217\" min=\"1\" step=\"1\" value=\""+ objMsg.PARA[2] 
               +"\" onchange=\"bs_move_alone_slide(id, 2)\">";
    sendMsg += "<input type=\"range\" class=\"slider-block-color\" id=\"RGB"+ objMsg.ID 
                +"\" style=\"margin: 8px 0 0 20px;\" max=\"255\" min=\"1\" step=\"1\" value=\""+ objMsg.PARA[3] 
                +"\" onchange=\"bs_move_alone_slide(id, 3)\">";
    sendMsg += "</div>" + "<div class=\"am-u-sm-2\" >";
    sendMsg += "<p id=\"show_DIM"+ objMsg.ID +"\" style=\"margin:5px 0 5px 0;\">"+ parseInt(objMsg.PARA[1]/255*100) + '%' +"</p>";
    sendMsg += "<p id=\"show_CCT"+ objMsg.ID +"\" style=\"margin:0px;\">"+ parseInt(1000000 / (370 - parseInt(objMsg.PARA[2]))) + 'K' +"</p>";
    sendMsg += "<p id=\"show_RGB"+ objMsg.ID +"\" style=\"margin-top:8px;\">"+ "HUE:" + objMsg.PARA[3] +"</p>";
    sendMsg += "</div>";
    sendMsg += "<div class=\"am-u-sm-1 am-u-end mart35\">";
    sendMsg += "<img id=\"sw_"+ objMsg.ID +"\" class=\"mf-img-size40\" src=\"/luci-static/resources/icon/"+ switchStatus(objMsg.PARA[0]) +"\" onclick=\"bs_common_switch(id,81)\" />";
    sendMsg += "</div>" + "</div>";

    return sendMsg;
}

/*
* function name: bs_save_add_mode()
* describe:      save add mode
* parameter:     null
*                 
* example:       bs_save_add_mode()
*/
function bs_save_add_mode()
{
    var sendMsg = "";
    var sw = "";
    var dim = "";
    var cct = "";
    var rgb = "";

    sendMsg += "MH=82";
    sendMsg += "&sceneNA=" + encodeURI(encodeURI($("#newModeNameId").val()));
    sendMsg += "&roomId=" + getUrlData("RID");

    for (var i=0; i<bs_stdJsGather.GPL.length; i++)
    {
        switch (bs_stdJsGather.GPL[i].TY)
        {
            case 1: 
                sw += "," + bs_check_switch_status("sw_" + bs_stdJsGather.GPL[i].ID);
                dim += ",-1";
                cct += ",-1";
                rgb += ",-1";
                break;
            case 2:
                sw += "," + bs_check_switch_status("sw_" + bs_stdJsGather.GPL[i].ID);
                dim += "," + $("#DIM" + bs_stdJsGather.GPL[i].ID).val();
                cct += ",-1";
                rgb += ",-1";
                break;
            case 3:
                sw += "," + bs_check_switch_status("sw_" + bs_stdJsGather.GPL[i].ID);
                dim += "," + $("#DIM" + bs_stdJsGather.GPL[i].ID).val();
                cct += "," + $("#CCT" + bs_stdJsGather.GPL[i].ID).val();
                rgb += ",-1";
                break;
            case 4:
                sw += "," + bs_check_switch_status("sw_" + bs_stdJsGather.GPL[i].ID);
                dim += "," + $("#DIM" + bs_stdJsGather.GPL[i].ID).val();
                cct += "," + $("#CCT" + bs_stdJsGather.GPL[i].ID).val();
                rgb += "," + $("#RGB" + bs_stdJsGather.GPL[i].ID).val();
                break;
            default:
                break;
        }
    }

    sendMsg += "&SWL=" + sw;
    sendMsg += "&DIML=" + dim;
    sendMsg += "&CCTL=" + cct;
    sendMsg += "&RGBL=" + rgb;

    loadNrp("/cgi-bin/luci/admin/zigbee/room/jsonresponse", sendMsg, 82);

    layer.open({
        type:2
        ,content:"Saving"
        ,time: 30    // 90 second close
    });
}

/*
* function name: bs_save_mode_success(xmlhttp)
* describe:      save add mode success response
* parameter:     xmlhttp:  server response index
*                 
* example:       bs_save_mode_success(xmlhttp)
*/
function bs_save_addmode_success(xmlhttp)
{
   jump2new_page_carryUrl("bs_modesetting_list", "RID="+getUrlData("RID"));

   layer.closeAll();    // close all pop-up window
}


/*
* function name: bs_check_switch_status(obj_id)
* describe:      check object switch img status:  
*                return  0/1   (OFF: 0   ON: 1)
* parameter:     obj_id   object id
*                 
* example:       bs_check_switch_status(obj_id)
*/
function bs_check_switch_status(obj_id)
{
    var e = document.getElementById(obj_id);
    if (e.src.match("/luci-static/resources/icon/001.png"))
    {
        return 0;
    }
    else
    {
        return 1;
    }
}


/*
* function name: bs_load_lightControl_list(xmlhttp)
* describe:      load lightcontrol page
* parameter:     xmlhttp  :    server response flag
*                 
* example:       bs_load_lightControl_list(xmlhttp)
*/
function bs_load_lightControl_list(xmlhttp)
{
    var jsontxt = xmlhttp.responseText;
    var obj = eval("(" + jsontxt + ")");                // json transform JS 
    var msg = "";

    for (var i=0; i<obj.RML.length; i++)
    {
          // real HTML
          //   <div class="am-g line-max-block" onclick='jump2new_page("bs_lightcontrol_child1")'>
          //   <div class="am-u-sm-1 mart17-5" >1</div>
          //   <div class="am-u-sm-1 mart10" >
          //     <img class="mf-img-size40" src="<%=resource%>/icon/1_B.png" />
          //   </div>
          //   <div name="tb" class="am-u-sm-2 mart17-5" >1F ShowRoom</div>
          //   <div class="am-u-sm-2 mart17-5" >HighLight</div>
          //   <div class="am-u-sm-5 mart5">
          //     <img class="mf-img-size30 mart5" src="<%=resource%>/icon/bs10.png" />
          //     <input type="range" class="slider-block mart5" id="slider1" max="255" min="1" step="1" value="1" onchange="moveChange(id)" onclick="cancelBubble()">
          //     <img class="mf-img-size40 mart5" src="<%=resource%>/icon/bs10.png" />
          //   </div>
          //   <div class="am-u-sm-1 mart10" >
          //     <img id="imgslider1" class="mf-img-size40" src="/luci-static/resources/icon/002.png" onclick="bs_common_switch(id)" />
          //   </div>
          // </div>

        msg += "<div class=\"am-g line-max-block\" onclick=\'jump2new_page_carryUrl(\"bs_lightcontrol_child1\", \"RID="+ obj.RML[i].ID + "&SE="+ encodeURI(encodeURI(obj.RML[i].SE)) +"\")\'>";
        msg += "<div class=\"am-u-sm-1 mart17-5\" >"+ (i+1) +"</div>";
        msg += "<div class=\"am-u-sm-1 mart10\" >";
        msg += "<img class=\"mf-img-size40\" src=\"/luci-static/resources/icon/"+ searchIcon(obj.RML[i].IC) +"\" />";
        msg += "</div>";
        msg += "<div name=\"tb\" class=\"am-u-sm-2 mart17-5\" >"+ obj.RML[i].NA +"</div>";
        msg += "<div class=\"am-u-sm-2 mart17-5\" >"+ obj.RML[i].SE +"</div>"
        msg += "<div class=\"am-u-sm-5 mart5\">";
        msg += "<img class=\"mf-img-size30 mart5\" src=\"/luci-static/resources/icon/bs10.png\" />";
        msg += "<input type=\"range\" class=\"slider-block mart5\" id=\"DIM"+ obj.RML[i].NA 
               +"\" max=\"255\" min=\"5\" step=\"1\" value=\""+ obj.RML[i].LEV 
               +"\" onchange=\"bs_move_alone_slide(id, 1)\" onclick=\"cancelBubble()\">";
        msg += "<img class=\"mf-img-size40 mart5\" src=\"/luci-static/resources/icon/bs10.png\" />";
        msg += "</div>";
        msg += "<div class=\"am-u-sm-1 mart10\" >";
        msg += "<img id=\"sw_"+ obj.RML[i].ID +"\" class=\"mf-img-size40\" src=\"/luci-static/resources/icon/"+ switchStatus(obj.RML[i].SW) +"\" onclick=\"bs_common_switch(id)\" />";
        msg += "</div>" + "</div>";
    }

    document.getElementById("roomListContainerId").innerHTML = msg;
}

/*
* function name: bs_load_lightControl_mode(xmlhttp)
* describe:      load light control child page
* parameter:     xmlhttp  :    server response flag
*                 
* example:       bs_load_lightControl_mode(xmlhttp)
*/
function bs_load_lightControl_mode(xmlhttp)
{
    var jsontxt = xmlhttp.responseText;
    var obj = eval("(" + jsontxt + ")");                // json transform JS 
    bs_stdJsGather = obj;
    var modeMsg = "";
    var groupMsg = "";

    for (var i=0; i<obj.SEL.length; i++)
    {
        // real HTML
      //   <div class="am-g line-block">
      //   <div class="am-u-sm-1 mart17-5">1</div>
      //   <div class="am-u-sm-3 mart17-5">High Light</div>
      //   <div class="am-u-sm-3 am-u-end mart20">
      //     <img id="SEL0" class="mf-img-size20" src="/luci-static/resources/icon/NO_B.png" onclick='only_select_lightcontrol(id)' />
      //   </div>
      // </div>

      modeMsg += "<div class=\"am-g line-block\">";
      modeMsg += "<div class=\"am-u-sm-1 mart17-5\">"+ (i+1) +"</div>";
      modeMsg += "<div class=\"am-u-sm-3 mart17-5\">"+ obj.SEL[i] +"</div>";
      modeMsg += "<div class=\"am-u-sm-3 am-u-end mart20\">";
      modeMsg += "<img id=\"SEL"+ i +"\" class=\"mf-img-size20\" src=\"/luci-static/resources/icon/"+ bs_lightcontrol_check_select_status(obj.SEL[i]) +"\" onclick=\'only_select_lightcontrol(id)\' />";
      modeMsg += "</div>" + "</div>";
    }

    for (var i=0; i<obj.GPL.length; i++)
    {
        // real group List HTML
        switch (obj.GPL[i].TY)
        {
            case 1: groupMsg += bs_real_html_ONFgroup(i, obj.GPL[i]);
                    break;
            case 2: groupMsg += bs_real_html_DIMgroup(i, obj.GPL[i]);
                    break;
            case 3: groupMsg += bs_real_html_CCTgroup(i, obj.GPL[i]);
                    break;
            case 4: groupMsg += bs_real_html_RGBgroup(i, obj.GPL[i]);
                    break;
            default: break;
        }
    }

    document.getElementById("ModeListContainerId").innerHTML = modeMsg;
    document.getElementById("ModeGroupListId").innerHTML = groupMsg;
}

/*
* function name: bs_lightcontrol_check_select_status(modeName)
* describe:      accound to url, judge mode selete status
* parameter:     xmlhttp  :    server response flag
*                 
* example:       bs_lightcontrol_check_select_status(modeName)
*/
function bs_lightcontrol_check_select_status(modeName)
{
    if (decodeURI(getUrlData("SE")) == modeName)
    {
        return "YES.png";
    }
    
    return "NO_B.png";
}

/*
* function name: bs_set_search_input_status(objId, tip, tipColor, writeColor)
* describe:      setting input focus and not focus that tip status
* parameter:     objId:       search input id
*                tip:         search input source tip message
*                tipColor:    search input source tip color
*                writeColor:  search input user write content color
*                 
* example:       bs_set_search_input_status(objId, tip, tipColor, writeColor)
*/
function bs_set_search_input_status(objId, tip, tipColor, writeColor)
{
    $("#"+objId).blur(function(){
      if ($("#"+objId).val() == "")
      {
         $("#"+objId).val(tip);
         document.getElementById(objId).style.color = tipColor;
      }
   })

    $("#"+objId).focus(function(){
      document.getElementById(objId).style.color = writeColor;
      if ($("#"+objId).val() == tip)
      {
         $("#"+objId).val("");
      }
   })
}


/*
* function name: bs_load_schedule_list(xmlhttp)
* describe:      load schedele main page.
* parameter:     xmlhttp:   server response flag
*                 
* example:       bs_load_schedule_list(xmlhttp)
*/
function bs_load_schedule_list(xmlhttp)
{
    var jsontxt = xmlhttp.responseText;
    alert(jsontxt);
    var obj = eval("(" + jsontxt + ")");                // json transform JS 
    var msg = "";

    for (var i=0; i<obj.RML.length; i++)
    {
        // real HTML
      //   <div class="am-g line-max-block">
      //   <div class="am-u-sm-1 mart17-5" >1</div>
      //   <div class="am-u-sm-1 mart10">
      //     <img class="mf-img-size40" src="<%=resource%>/icon/1_B.png" />
      //   </div>
      //   <div class="am-u-sm-3 mart17-5" >1F ShowRoom</div>
      //   <div class="am-u-sm-6 mart17-5">Mon Thu</div>
      //   <div class="am-u-sm-1 mart10">
      //     <img id="roomId" class="mf-img-size40" src="<%=resource%>/icon/002.png" onclick='bs_common_switch(id, 86)' />
      //   </div>
      // </div>

      msg += "<div class=\"am-g line-max-block\" onclick='jump2new_page_carryUrl(\"bs_sceneschedule_adjust\", \"RID="+ obj.RML[i].ID + "&REP="+ obj.RML[i].REP +"\")'>";
      msg += "<div class=\"am-u-sm-1 mart17-5\" >"+ (i+1) +"</div>";
      msg += "<div class=\"am-u-sm-1 mart10\">";
      msg += "<img class=\"mf-img-size40\" src=\"/luci-static/resources/icon/"+ searchIcon(obj.RML[i].IC) +"\" />";
      msg += "</div>";
      msg += "<div class=\"am-u-sm-3 mart17-5\" >"+ obj.RML[i].NA +"</div>";
      msg += "<div class=\"am-u-sm-6 mart17-5\">"+ timeRepeat(obj.RML[i].REP) +"</div>";   // zigbee.js function: timeRepeat
      msg += "<div class=\"am-u-sm-1 mart10\">";
      msg += "<img id=\""+ obj.RML[i].ID +"\" class=\"mf-img-size40\" src=\"/luci-static/resources/icon/"+ switchStatus(obj.RML[i].SW) +"\" onclick='bs_common_switch(id, 86)' />";
      msg += "</div>" + "</div>";    
    }

    document.getElementById("sceneScheduleListId").innerHTML = msg;
}


function bs_load_room_schedule_list(xmlhttp)
{
    var jsontxt = xmlhttp.responseText;
    alert(jsontxt);
    // var obj = eval("(" + jsontxt + ")");                // json transform JS 
    var msg = "";

    for (var i=0; i<obj.SCHE.length; i++)
    {
        // real HTML
      //   <div class="am-g line-max-block">    
      //   <div class="am-u-sm-1 mart17-5">
      //     <input id="time_sceneId" type="text" value="12:00" style="width: 90%;" />
      //   </div>
      //   <div class="am-u-sm-3 mart17-5">
      //     <input id="name_sceneId" type="text" value="work" style="width: 80%;" />
      //   </div>
      //   <div class="am-u-sm-5 mart15">
      //     <select data-am-selected="{btnWidth: '60%', btnSize: 'sm', btnStyle: 'success'}" >
      //       <option id="se0sceneId" value="scene1">scene1</option>
      //       <option id="se1sceneId" value="scene2" selected>scene2</option>
      //       <option id="se2sceneId" value="scene3">scene3</option>
      //       <option id="se3sceneId" value="scene4">scene4</option>
      //     </select>
      //   </div>
      //   <div class="am-u-sm-2 mart10">
      //     <img id="sw_sceneId" class="mf-img-size40" src="<%=resource%>/icon/002.png" />
      //   </div>
      //   <div class="am-u-sm-1 mart17-5">Delete</div>
      // </div>

      // msg += "<div class=\"am-g line-max-block\">";
      // msg += "<div class=\"am-u-sm-1 mart17-5\">";
      // msg += "<input id=\"time_"+ obj.SCHE[i].ID +"\" type=\"text\" value=\""+ obj.SCHE[i].TM +"\" style=\"width: 90%;\" />";
      // msg += "</div>";
      // msg += "<div class=\"am-u-sm-3 mart17-5\">";
      // msg += "<input id=\"name_"+ obj.SCHE[i].ID +"\" type=\"text\" value=\""+ obj.SCHE[i].NA +"\" style=\"width: 80%;\" />";
      // msg += "</div>";
      // msg += "<div class=\"am-u-sm-5 mart15\">";
      // msg += "<select data-am-selected=\"{btnWidth: \'60%\', btnSize: \'sm\', btnStyle: \'success\'}\" >";

      // for (var j=0; j<obj.SEG.length; j++)
      // {
      //   msg += "<option id=\"se"+ j + obj.SCHE[i].ID +"\" value=\""+ obj.SEG[j] +"\">"+ obj.SEG[j] +"</option>";
      // }

      // msg += "</select>" + "</div>";
      // msg += "<div class=\"am-u-sm-2 mart10\">";
      // msg += "<img id=\"sw_"+ obj.SCHE[i].ID +"\" class=\"mf-img-size40\" src=\"/luci-static/resources/icon/"+ switchStatus(obj.SCHE[i].SW) +"\" />";
      // msg += "</div>" + "<div class=\"am-u-sm-1 mart17-5\">Delete</div>" + "</div>";
    }

    document.getElementById("oldRoomSceneListId").innerHTML = msg;
}


function bs_load_scene_schedule_repeat()
{
    var repGroup = getUrlData("REP").split(",");

    for (var i=1; i<repGroup.length; i++)
    {
       var obj = document.getElementById(repGroup[i]);   // repGroup[0]  is  empty  ""

       obj.src = "/luci-static/resources/icon/YES.png";
    }
}



/*
*
*
*  FLK：page action API
*
*/

/*
*   function: change switch status API
*/
function bs_conment_switch(objId)
{
    var obj = document.getElementById(objId);

    if (obj.src.match("/luci-static/resources/icon/001.png"))
    {
        obj.src = "/luci-static/resources/icon/002.png";
    }
    else
    {
        obj.src = "/luci-static/resources/icon/001.png";
    }
}


/*
*   function: change select status API
*/
function bs_conment_select_status(objId)
{
    var obj = document.getElementById(objId);

    if (obj.src.match("/luci-static/resources/icon/YES.png"))
    {
        obj.src = "/luci-static/resources/icon/NO_B.png";
    }
    else
    {
        obj.src = "/luci-static/resources/icon/YES.png";
    }
}

/*
*
*
*
*
*/
   

   